# /// script
# requires-python = ">=3.12"
# dependencies = []
# [tool.orcaslicer.plugin]
# name = "PipSpool"
# description = "Spoolman synchronization plugin for OrcaSlicer"
# author = "Donko"
# version = "2.2.19"
# ///

"""PipSpool: synchronize Spoolman inventory into OrcaSlicer presets.

This implementation intentionally has no slicing-pipeline capability. Klipper
and Moonraker remain responsible for real-time Spoolman usage accounting.
"""

from __future__ import annotations

from .artwork import data_uri as _artwork_data_uri
import json
import sys
import http.client
import math
import os
import re
import threading
import base64
import time
import urllib.parse
import webbrowser
from dataclasses import dataclass, field
from datetime import date, datetime
from html import escape
from pathlib import Path
from typing import Any

import orca

# Public default. Configure the Spoolman server address in PipSpool Settings.
DEFAULT_SPOOLMAN_URL = "http://localhost:7912"
DEFAULT_LOW_STOCK_THRESHOLD_GRAMS = 100.0
PLUGIN_VERSION = "2.2.19"
ORCA_PLUGIN_API_BASELINE = "2.5.0-alpha"
COPYRIGHT_YEAR = 2026
FEEDBACK_URL = "https://github.com/Gadonk/pipspool-orcaslicer/issues"
LATEST_RELEASE_API = "https://api.github.com/repos/Gadonk/pipspool-orcaslicer/releases/latest"
UPDATE_CHECK_INTERVAL_SECONDS = 6 * 60 * 60
SETTINGS_FILENAME = "pipspool_settings.json"
LOG_FILENAME = "pipspool.log"
SPOOLMAN_CONNECTION_MESSAGE = (
    "Connection to the Spoolman server was lost or could not be established. "
    "Check that Spoolman is running, then select Refresh."
)
THREAD_PERMISSION_RETRY_MESSAGE = (
    "OrcaSlicer did not allow PipSpool to create a background worker. "
    "Approve the thread permission request, then repeat the action."
)

ORCA_NETWORK_PERMISSION_FIX = "6626377abc177587c7e60da487d69d86b4cc7f62"
NETWORK_PERMISSION_RETRY_MESSAGE = (
    "OrcaSlicer did not grant access for this network operation. "
    "If Orca shows a permission request, approve it only if you trust the target, "
    "then repeat the action. If approved network prompts return after restarting "
    "OrcaSlicer, use a build containing Orca PR #16658 (commit 6626377). "
    "PipSpool cannot save or bypass Orca's permission decisions."
)


class NetworkPermissionError(PermissionError):
    """A denied network operation, distinct from a disconnected Spoolman server."""


# http.client emits ``http.client.connect`` with the target host before opening
# its socket. Do not eagerly request access to Python's IDNA files: Linux
# AppImage mount paths change between launches and such a path cannot be
# remembered. Orca remains responsible for the target-bearing HTTP approval and
# its nested runtime events. PR #16658 records stdlib operation roots and
# persistent event grants in Orca itself. Keep this stdlib call path; do not
# synthesize audit events, modify permission files or automatically replay writes.
class _HttpResponse:
    def __init__(self, url: str, status_code: int, body: bytes):
        self.url = url
        self.status_code = status_code
        self._body = body

    def raise_for_status(self) -> None:
        if 200 <= self.status_code < 400:
            return
        detail = self._body.decode("utf-8", errors="replace").strip()
        if len(detail) > 240:
            detail = detail[:237] + "..."
        suffix = f": {detail}" if detail else ""
        raise RuntimeError(f"HTTP {self.status_code} for {self.url}{suffix}")

    def json(self) -> Any:
        return json.loads(self._body.decode("utf-8"))



class _HttpSession:
    def request(
        self,
        method: str,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any = None,
        headers: dict[str, str] | None = None,
        timeout: float = 10,
    ) -> _HttpResponse:
        if params:
            separator = "&" if urllib.parse.urlsplit(url).query else "?"
            url = f"{url}{separator}{urllib.parse.urlencode(params)}"
        request_headers = dict(headers or {})
        data = None
        if json is not None:
            data = globals()["json"].dumps(json).encode("utf-8")
            request_headers.setdefault("Content-Type", "application/json")
        request_headers.setdefault("Accept", "application/json")
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            raise ValueError(f"Unsupported HTTP URL: {url}")
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        path = urllib.parse.urlunsplit(("", "", parsed.path or "/", parsed.query, ""))
        connection_type = (
            http.client.HTTPSConnection
            if parsed.scheme == "https"
            else http.client.HTTPConnection
        )
        connection = connection_type(parsed.hostname, port, timeout=timeout)
        try:
            connection.request(method.upper(), path, body=data, headers=request_headers)
            response = connection.getresponse()
            return _HttpResponse(url, int(response.status), response.read())
        except PermissionError as exc:
            pause_background_updates()
            # Keep raw audit details in the exception chain for diagnostics, not
            # in the user-facing message (which must not expose credentials).
            raise NetworkPermissionError(NETWORK_PERMISSION_RETRY_MESSAGE) from exc
        finally:
            connection.close()

    def get(self, url: str, **kwargs) -> _HttpResponse:
        return self.request("GET", url, **kwargs)

    def post(self, url: str, **kwargs) -> _HttpResponse:
        return self.request("POST", url, **kwargs)

    def patch(self, url: str, **kwargs) -> _HttpResponse:
        return self.request("PATCH", url, **kwargs)

    def delete(self, url: str, **kwargs) -> _HttpResponse:
        return self.request("DELETE", url, **kwargs)


HTTP_SESSION = _HttpSession()
PROFILE_SUFFIX = " - PipSpool.json"
START_MARKER = "; PipSpool: begin managed spool ID"
END_MARKER = "; PipSpool: end managed spool ID"
LEGACY_START_MARKER = "; Spoolman Bridge: begin managed spool ID"
LEGACY_END_MARKER = "; Spoolman Bridge: end managed spool ID"
ACTIVE_SPOOL_GCODE = "SET_ACTIVE_SPOOL"
LEGACY_SPOOL_GCODE = "SET_SPOOL_ID"
ORCA_FIELD_PREFIX = "orca_"
LIVE_SYSTEM_FILAMENT_PRESETS: dict[str, list[str]] = {}
# Orca's inheritance choice is local preset structure, not data represented by
# Spoolman's Filament, Spool or extra-field API. Startup status checks also lack
# the UI-thread system-preset snapshot used by a real synchronization, so a
# different fallback parent must not be presented as a Spoolman sync change.
PROFILE_STATUS_ORCA_ONLY_KEYS = frozenset({"inherits"})
# These belong to OrcaSlicer's Dependencies tab. PipSpool never infers them;
# they are synchronized only when the user explicitly selects those fields.
ORCA_DEPENDENCY_KEYS = (
    "compatible_printers",
    "compatible_printers_condition",
    "compatible_prints",
    "compatible_prints_condition",
)
ORCA_SETTING_GROUPS = {
    "Filament": (
        "filament_density", "filament_diameter", "filament_cost",
        "filament_max_volumetric_speed", "filament_flow_ratio",
        "filament_shrink", "filament_shrinkage_compensation_z",
        "nozzle_temperature", "nozzle_temperature_initial_layer",
        "hot_plate_temp", "hot_plate_temp_initial_layer",
        "textured_plate_temp", "textured_plate_temp_initial_layer",
        "cool_plate_temp", "cool_plate_temp_initial_layer",
        "textured_cool_plate_temp", "textured_cool_plate_temp_initial_layer",
        "eng_plate_temp", "eng_plate_temp_initial_layer",
        "supertack_plate_temp", "supertack_plate_temp_initial_layer",
    ),
    "Cooling": (
        "close_fan_the_first_x_layers", "full_fan_speed_layer",
        "fan_min_speed", "fan_cooling_layer_time", "fan_max_speed",
        "slow_down_layer_time", "reduce_fan_stop_start_freq",
        "slow_down_for_layer_cooling", "dont_slow_down_outer_wall",
        "slow_down_min_speed", "enable_overhang_bridge_fan",
        "overhang_fan_threshold", "overhang_fan_speed",
        "internal_bridge_fan_speed", "support_material_interface_fan_speed",
        "ironing_fan_speed", "additional_cooling_fan_speed",
        "activate_air_filtration", "activate_air_filtration_during_print",
        "during_print_exhaust_fan_speed", "activate_air_filtration_on_completion",
        "complete_print_exhaust_fan_speed",
    ),
    "Setting Overrides": (
        "filament_retraction_length", "filament_z_hop",
        "filament_z_hop_types", "filament_retract_lift_above",
        "filament_retract_lift_below", "filament_retract_lift_enforce",
        "filament_retraction_speed", "filament_deretraction_speed",
        "filament_retract_restart_extra",
        "filament_retraction_minimum_travel",
        "filament_retract_when_changing_layer", "filament_wipe",
        "filament_wipe_distance", "filament_retract_before_wipe",
        "filament_retract_after_wipe", "filament_long_retractions_when_cut",
        "filament_retraction_distances_when_cut",
        "filament_retract_length_toolchange",
        "filament_retract_restart_extra_toolchange",
        "filament_ironing_flow", "filament_ironing_spacing",
        "filament_ironing_inset", "filament_ironing_speed",
    ),
    "Advanced": (
        "filament_start_gcode", "filament_change_extrusion_role_gcode",
        "filament_end_gcode",
    ),
    "Multimaterial": (
        "filament_minimal_purge_on_wipe_tower",
        "filament_tower_interface_pre_extrusion_dist",
        "filament_tower_interface_pre_extrusion_length",
        "filament_tower_ironing_area", "filament_tower_interface_purge_volume",
        "filament_tower_interface_print_temp", "long_retractions_when_ec",
        "retraction_distances_when_ec", "filament_loading_speed_start",
        "filament_loading_speed", "filament_unloading_speed_start",
        "filament_unloading_speed", "filament_toolchange_delay",
        "filament_cooling_moves", "filament_cooling_initial_speed",
        "filament_cooling_final_speed", "filament_stamping_loading_speed",
        "filament_stamping_distance", "filament_ramming_parameters",
        "filament_multitool_ramming", "filament_multitool_ramming_volume",
        "filament_multitool_ramming_flow", "filament_change_length",
    ),
    "Dependencies": ORCA_DEPENDENCY_KEYS,
    "Notes": ("filament_notes",),
}
ORCA_SETTINGS = tuple(
    setting for settings in ORCA_SETTING_GROUPS.values() for setting in settings
)
ORCA_SETTING_UNITS = {
    "filament_density": "g/cm³",
    "filament_diameter": "mm",
    "filament_cost": "currency/kg",
    "filament_max_volumetric_speed": "mm³/s",
    "filament_shrink": "%",
    "filament_shrinkage_compensation_z": "%",
    "nozzle_temperature": "°C",
    "nozzle_temperature_initial_layer": "°C",
    "hot_plate_temp": "°C",
    "hot_plate_temp_initial_layer": "°C",
    "textured_plate_temp": "°C",
    "textured_plate_temp_initial_layer": "°C",
    "cool_plate_temp": "°C",
    "cool_plate_temp_initial_layer": "°C",
    "textured_cool_plate_temp": "°C",
    "textured_cool_plate_temp_initial_layer": "°C",
    "eng_plate_temp": "°C",
    "eng_plate_temp_initial_layer": "°C",
    "supertack_plate_temp": "°C",
    "supertack_plate_temp_initial_layer": "°C",
    "fan_min_speed": "%",
    "fan_max_speed": "%",
    "overhang_fan_threshold": "%",
    "overhang_fan_speed": "%",
    "internal_bridge_fan_speed": "%",
    "support_material_interface_fan_speed": "%",
    "ironing_fan_speed": "%",
    "additional_cooling_fan_speed": "%",
    "during_print_exhaust_fan_speed": "%",
    "complete_print_exhaust_fan_speed": "%",
    "fan_cooling_layer_time": "s",
    "slow_down_layer_time": "s",
    "slow_down_min_speed": "mm/s",
    "filament_minimal_purge_on_wipe_tower": "mm³",
    "filament_tower_interface_pre_extrusion_dist": "mm",
    "filament_tower_interface_pre_extrusion_length": "mm",
    "filament_tower_ironing_area": "mm²",
    "filament_tower_interface_purge_volume": "mm³",
    "filament_tower_interface_print_temp": "°C",
    "retraction_distances_when_ec": "mm",
    "filament_loading_speed_start": "mm/s",
    "filament_loading_speed": "mm/s",
    "filament_unloading_speed_start": "mm/s",
    "filament_unloading_speed": "mm/s",
    "filament_toolchange_delay": "s",
    "filament_cooling_initial_speed": "mm/s",
    "filament_cooling_final_speed": "mm/s",
    "filament_stamping_loading_speed": "mm/s",
    "filament_stamping_distance": "mm",
    "filament_multitool_ramming_volume": "mm³",
    "filament_multitool_ramming_flow": "mm³/s",
    "filament_change_length": "mm",
    "filament_retraction_length": "mm",
    "filament_z_hop": "mm",
    "filament_retract_lift_above": "mm",
    "filament_retract_lift_below": "mm",
    "filament_retraction_speed": "mm/s",
    "filament_deretraction_speed": "mm/s",
    "filament_retract_restart_extra": "mm",
    "filament_retraction_minimum_travel": "mm",
    "filament_wipe_distance": "mm",
    "filament_retract_before_wipe": "%",
    "filament_retract_after_wipe": "%",
    "filament_retraction_distances_when_cut": "mm",
    "filament_retract_length_toolchange": "mm",
    "filament_retract_restart_extra_toolchange": "mm",
    "filament_ironing_flow": "%",
    "filament_ironing_spacing": "mm",
    "filament_ironing_inset": "mm",
    "filament_ironing_speed": "mm/s",
}
ORCA_INTEGER_SETTINGS = {
    "nozzle_temperature", "nozzle_temperature_initial_layer",
    "hot_plate_temp", "hot_plate_temp_initial_layer",
    "textured_plate_temp", "textured_plate_temp_initial_layer",
    "cool_plate_temp", "cool_plate_temp_initial_layer",
    "textured_cool_plate_temp", "textured_cool_plate_temp_initial_layer",
    "eng_plate_temp", "eng_plate_temp_initial_layer",
    "supertack_plate_temp", "supertack_plate_temp_initial_layer",
    "close_fan_the_first_x_layers", "full_fan_speed_layer",
    "overhang_fan_speed", "internal_bridge_fan_speed",
    "support_material_interface_fan_speed", "ironing_fan_speed",
    "additional_cooling_fan_speed", "during_print_exhaust_fan_speed",
    "complete_print_exhaust_fan_speed", "filament_tower_interface_print_temp",
    "filament_cooling_moves",
}
ORCA_BOOLEAN_SETTINGS = {
    "reduce_fan_stop_start_freq", "slow_down_for_layer_cooling",
    "dont_slow_down_outer_wall", "enable_overhang_bridge_fan",
    "activate_air_filtration", "activate_air_filtration_during_print",
    "activate_air_filtration_on_completion", "long_retractions_when_ec",
    "filament_multitool_ramming",
    "filament_retract_lift_enforce", "filament_retract_when_changing_layer",
    "filament_wipe", "filament_long_retractions_when_cut",
}
ORCA_CHOICE_SETTINGS = {
    "overhang_fan_threshold": ("0%", "10%", "25%", "50%", "75%", "95%"),
}
ORCA_TEXT_SETTINGS = {
    "filament_z_hop_types", "filament_start_gcode",
    "filament_change_extrusion_role_gcode", "filament_end_gcode",
    "compatible_printers", "compatible_printers_condition",
    "compatible_prints", "compatible_prints_condition", "filament_notes",
}
ORCA_LIST_TEXT_SETTINGS = {
    "compatible_printers", "compatible_prints",
}
ORCA_SCALAR_TEXT_SETTINGS = {
    "compatible_printers_condition", "compatible_prints_condition",
}


def orca_setting_field_type(setting: str) -> str:
    """Translate Orca's official config type to the closest Spoolman field."""
    if setting in ORCA_INTEGER_SETTINGS:
        return "integer"
    if setting in ORCA_BOOLEAN_SETTINGS:
        return "boolean"
    if setting in ORCA_CHOICE_SETTINGS:
        return "choice"
    if setting == "filament_ramming_parameters" or setting in ORCA_TEXT_SETTINGS:
        return "text"
    return "float"
FIELD_CONFIG_VERSION = 1
SPOOL_TABLE_COLUMNS = (
    "filament",
    "manufacturer",
    "colour",
    "nozzle",
    "bed",
    "remaining",
    "location",
    "loaded",
    "sync",
)
DEFAULT_SPOOL_TABLE_COLUMNS = (
    "filament", "manufacturer", "colour", "nozzle", "bed", "remaining",
)
SPOOL_TABLE_COLUMN_LABELS = {
    "filament": "Filament",
    "manufacturer": "Manufacturer",
    "colour": "Colour",
    "nozzle": "Nozzle",
    "bed": "Bed",
    "remaining": "Remaining",
    "location": "Location",
    "loaded": "Gate/Toolhead",
    "sync": "Profile status",
}
PIPSPOOL_LOGO_DATA_URI = (
    '5e0267237ddaf167e670155a80a0305491e39330be05827d83856a0653f3c731.webp'
)
PIPSPOOL_PAGE_ICON_SVG = (
    "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'>"
    "<g fill='none' stroke='#fff2d2' stroke-width='4.5' stroke-linecap='round' "
    "stroke-linejoin='round' transform='rotate(7 32 32)'>"
    "<rect x='8' y='13' width='48' height='38' rx='12'/>"
    "<rect x='13' y='18' width='38' height='28' rx='9'/>"
    "<path d='M8 27H4v10h4M56 27h4v10h-4'/>"
    "</g><g fill='none' stroke='#00dce7' stroke-width='4' "
    "stroke-linecap='round' transform='rotate(7 32 32)'>"
    "<circle cx='25' cy='30' r='3'/><circle cx='39' cy='30' r='3'/>"
    "<path d='M26 38q6 6 12 0'/></g></svg>"
)

PIP_HAPPY_DATA_URI = 'a4023b9a26be14c1a7dd9c688307d340ede279810d77341f26fdeb50672ed677.webp'
PIP_SAD_DATA_URI = '436788709571e382eac35e91eedb9451f175d33daf1d91ad935d4b363b631482.webp'

PLUGIN_DIR = Path(__file__).resolve().parent
ORCA_DATA_DIR = next(
    (parent for parent in (PLUGIN_DIR, *PLUGIN_DIR.parents) if parent.name == "OrcaSlicer"),
    PLUGIN_DIR,
)
PERSISTENT_DIR = ORCA_DATA_DIR / "pipspool"
SETTINGS_PATH = PERSISTENT_DIR / SETTINGS_FILENAME
PAGE_ICON_PATH = PERSISTENT_DIR / "pipspool_page_icon.svg"
LOG_PATH = PERSISTENT_DIR / LOG_FILENAME
DEFAULT_SPOOL_ID_COMMAND = "SET_ACTIVE_SPOOL ID={spool_id}"

DEFAULT_PROFILE_NAME_TEMPLATE = "{spool_id} {material} {name} - {vendor}"
PROFILE_NAME_TOKENS = ("spool_id", "material", "name", "vendor")

HOST_CONFIG_KEYS = (
    "shared_filament_settings",
    "spool_id_command_template",
    "profile_name_template",
    "spoolman_url",
    "show_pipspool_page",
    "low_stock_threshold_grams",
)
HOST_USER_SETTINGS: dict[str, Any] = {}
SETTINGS_CAPABILITY = None
_MANUAL_USE_STARTED = False


THEME_DIR = PERSISTENT_DIR / "themes"
THEME_COLORS = {
    "background": "#030914", "surface": "#08264b", "surface_alt": "#061a33",
    "text": "#f5ead8", "muted": "#a9bfd4", "accent": "#168cff",
    "accent_text": "#03101e", "border": "#1767a8", "heading": "#f1dfc7",
    "highlight": "#42e5ea", "good": "#67d39a", "warning": "#f2a43a",
    "danger": "#f07168",
}
BUILTIN_THEMES = {
    "classic": {"name": "PipSpool Classic", "colors": dict(THEME_COLORS)},
    "light": {"name": "Light", "colors": dict(THEME_COLORS, background="#f4f7fb",
        surface="#ffffff", surface_alt="#e7eef6", text="#172b40", muted="#465c72",
        accent="#1269b0", accent_text="#ffffff", border="#879fb6", heading="#172b40",
        highlight="#006777", good="#21643d", warning="#805000", danger="#a62c27")},
    "forest": {"name": "Forest", "colors": dict(THEME_COLORS, background="#101c18",
        surface="#1c3027", surface_alt="#15261e", accent="#8bcca0", accent_text="#102519",
        border="#527461", heading="#e5efd4", highlight="#a8dfbc")},
    "rosewood": {"name": "Rosewood", "colors": dict(THEME_COLORS,
        background="#1c0b0d", surface="#4b1719", surface_alt="#642125",
        text="#f4e8e4", muted="#e1bbb3", accent="#b94040", accent_text="#fff3ea",
        border="#a65350", heading="#f2ddd5", highlight="#f0a099", good="#9bd0b0",
        warning="#e2bd7b", danger="#ff9b94")},

}


# Seasonal backgrounds are embedded so built-ins work in single-file installs.
BUILTIN_THEMES.update({'halloween': {'name': 'Bonus Treat', 'colors': {'background': '#150c21', 'surface': '#25162f', 'surface_alt': '#321e3d', 'text': '#fff1df', 'muted': '#cfb7db', 'accent': '#f58220', 'accent_text': '#231008', 'border': '#795085', 'heading': '#ffe4bb', 'highlight': '#d6afff', 'good': '#9bdc91', 'warning': '#ffcb6b', 'danger': '#ff929c'}, 'background_image': 'halloween.png', 'background_opacity': 0.72}, 'christmas': {'name': 'Christmas', 'colors': {'background': '#091b18', 'surface': '#5a1813', 'surface_alt': '#74251b', 'text': '#faf1df', 'muted': '#edc1ae', 'accent': '#e5ba61', 'accent_text': '#241b09', 'border': '#b15b47', 'heading': '#ffe7ad', 'highlight': '#e9c77d', 'good': '#9fdbac', 'warning': '#ffd47c', 'danger': '#ff9a9f'}, 'background_image': 'christmas.png', 'background_opacity': 0.72}})
BUILTIN_THEME_BACKGROUNDS = {
    "halloween": 'd9c5ebd7e0f17a140bbfb3fc228dd9ff30ba954dcc3e2afe59793eeeeb75b913.webp',
    "christmas": '826be2b4a5aac35ca7b3d82e64967439eb0353e43eda83a5214a25b1949f68ea.webp',
}


BUILTIN_THEMES["newyear"] = {'name': 'New Year’s Eve', 'colors': {'background': '#071222', 'surface': '#101f35', 'surface_alt': '#1b2b43', 'text': '#f8f1df', 'muted': '#becbdf', 'accent': '#f2cc77', 'accent_text': '#21190c', 'border': '#60748f', 'heading': '#ffe5a4', 'highlight': '#f2d58e', 'good': '#98d6b0', 'warning': '#ffcf79', 'danger': '#ff9d9d'}, 'background_image': 'newyear.png', 'background_opacity': 0.7}
BUILTIN_THEME_BACKGROUNDS["newyear"] = '96b71929f3633897d7c902a9672268f91db7c10be79c465dfa7b30645aeffbc1.webp'


BUILTIN_THEME_LOGOS = {
    "halloween": 'ee65a537d3eac0e4b3ed05312fc46d8f3d572152f48545c2030e08a70891bf24.webp',
    "christmas": 'a0848dfcffde49e46a5de1cc4d075745906223122392ff929b298fc0b598e5be.webp',
    "newyear": '78c7f5d6f3955d7c376016a7a46cb3e26bcbe2e7b4e41078a56b72cb29d8d551.webp',
}


BUILTIN_THEME_STATUS_IMAGES = {
    "halloween": {
        "happy_data_uri": '957da9d253bf5d493c696aad37dbce311caa2667d4d2baf06924be5600452ef6.webp',
        "sad_data_uri": '4bf57019badfc263e8c912fef38dcebc7ff246a45b4237734568072ac3b43875.webp',
    },
    "christmas": {
        "happy_data_uri": '645b4d2c89e1213790622c52ed14ee9e19a6fa8c1994e395935abf24cf92bb59.webp',
        "sad_data_uri": '6c5bda4c36a2c61e6d26686f171d486a03a7a9d808a7b8203f1a4c61ee0f4439.webp',
    },
    "newyear": {
        "happy_data_uri": '829497564f7c3f6b59683294d5ab766cfd21dcdf5c9cb1117ddcc5fc634bc8d4.webp',
        "sad_data_uri": 'ee92f5dfc45df0482c6b31f21cf67a01186ee7fb7517b5a8af5275f6b5ef6396.webp',
    },
}



# Year-round winter celebrations: palettes and embedded artwork.
BUILTIN_THEMES['hanukkah'] = {'name': 'Hanukkah', 'colors': {'background': '#080f26', 'surface': '#15233f', 'surface_alt': '#203255', 'text': '#f2f6ff', 'muted': '#becce7', 'accent': '#96caff', 'accent_text': '#0a1930', 'border': '#596f99', 'heading': '#e0ecff', 'highlight': '#a9ddff', 'good': '#a1dfb4', 'warning': '#ffda91', 'danger': '#ffaaaa'}, 'background_image': 'hanukkah.png', 'background_opacity': 0.78}
BUILTIN_THEME_BACKGROUNDS['hanukkah'] = '979806ddaa78896a85eb3a3c1ac85b6876b9d09839e904764d4c311a71d5e170.webp'
BUILTIN_THEME_STATUS_IMAGES['hanukkah'] = {'happy_data_uri': 'daf81ca004165ba3744fc7a6ae678477bc8edd9a7a967d8060e57158ac771af5.webp', 'sad_data_uri': 'a375079d50cc5f4f1acc90dccc23619e0a65535d25d19ea6f55be610cc3cd8cd.webp'}
BUILTIN_THEME_LOGOS['hanukkah'] = '5476ebc0ddc7cee5dc30a2b80ff7262965b6efbbb96322e7db819c1c942890c4.webp'
BUILTIN_THEMES['kwanzaa'] = {'name': 'Kwanzaa', 'colors': {'background': '#130f0d', 'surface': '#27201d', 'surface_alt': '#352b25', 'text': '#fff2da', 'muted': '#d9c4ac', 'accent': '#e5bb69', 'accent_text': '#23190b', 'border': '#806452', 'heading': '#ffe0a1', 'highlight': '#a8dbae', 'good': '#a8dbae', 'warning': '#ffcf82', 'danger': '#ffa39b'}, 'background_image': 'kwanzaa.png', 'background_opacity': 0.78}
BUILTIN_THEME_BACKGROUNDS['kwanzaa'] = 'ee27f8575d3627ea1aeda822641074e52e2a749c618337eeec52d841a16e21fe.webp'
BUILTIN_THEME_STATUS_IMAGES['kwanzaa'] = {'happy_data_uri': 'f102cebd3e22226485cb2194f08f693cd2202f2df5d87140cfbb9195ecaeb6ae.webp', 'sad_data_uri': '2a1eefca7d8906c01607ebd3a18bdf296f9f1a1bdc24026aa1ec69a1ef95b62b.webp'}
BUILTIN_THEME_LOGOS['kwanzaa'] = '6bb137fdb088069f293a9feda1e92f000d6f289143eef1d4140f3ab5975a4df6.webp'
BUILTIN_THEMES['solstice'] = {'name': 'Winter Solstice', 'colors': {'background': '#080f1c', 'surface': '#142735', 'surface_alt': '#203647', 'text': '#edfbff', 'muted': '#b7d4df', 'accent': '#73e3d1', 'accent_text': '#082620', 'border': '#4e8291', 'heading': '#ffdfa3', 'highlight': '#a9baff', 'good': '#a5e7bf', 'warning': '#ffd391', 'danger': '#ffa4b1'}, 'background_image': 'solstice.png', 'background_opacity': 0.78}
BUILTIN_THEME_BACKGROUNDS['solstice'] = '60cbedcdfa8225ab3c26268c49207a165dfc14e8acfd591b353b24b0335460a4.webp'
BUILTIN_THEME_STATUS_IMAGES['solstice'] = {'happy_data_uri': '58145cbfa6d15eeb7ec7b8d10902f0064bbcc4b7ce4dba30a7f39892e1149984.webp', 'sad_data_uri': 'c9601524e1a0cd63b03b34ca9a1b2012db3be065681a693a7c320f8137732842.webp'}
BUILTIN_THEME_LOGOS['solstice'] = '4ccf2f9097fcc1de4fb2a3d09c91100f90190a98df3e50df76cc8cc2b7235c32.webp'

_ARTWORK_READY = False
_ARTWORK_LOCK = threading.Lock()


def load_builtin_artwork() -> None:
    """Resolve packaged image references on first UI use, never at import."""
    global _ARTWORK_READY
    if _ARTWORK_READY:
        return
    with _ARTWORK_LOCK:
        if _ARTWORK_READY:
            return
        def resolve(value):
            if isinstance(value, dict):
                return {key: resolve(item) for key, item in value.items()}
            if isinstance(value, str) and value.endswith(".webp") and len(value) == 69:
                return _artwork_data_uri(value)
            return value
        names = ("PIPSPOOL_LOGO_DATA_URI", "PIP_HAPPY_DATA_URI", "PIP_SAD_DATA_URI",
                 "BUILTIN_THEME_BACKGROUNDS", "BUILTIN_THEME_LOGOS", "BUILTIN_THEME_STATUS_IMAGES")
        # Build replacements first: a denied/failed resource read must not leave
        # half-initialized globals or mark the operation successful.
        resolved = {name: resolve(globals()[name]) for name in names}
        globals().update(resolved)
        _ARTWORK_READY = True


def theme_calendar_month() -> int:
    """Use the Orca computer's local calendar; never contact a time service."""
    return datetime.now().month


def theme_calendar_day() -> int:
    return datetime.now().day


def forced_calendar_theme() -> str | None:
    return "newyear" if theme_calendar_month() == 12 and theme_calendar_day() == 31 else None


def hebrew_new_year_ordinal(year: int) -> int:
    """Fixed Hebrew calendar, expressed as a Gregorian date ordinal."""
    # Integer lunar-month arithmetic, including weekday/year-length postponements.
    def lunar_day(y: int) -> int:
        months = (235 * y - 234) // 19
        day = 29 * months + (12084 + 13753 * months) // 25920
        return day + int((3 * (day + 1)) % 7 < 3)

    previous, current, following = (lunar_day(year + delta) for delta in (-1, 0, 1))
    postpone = 2 if following - current == 356 else 1 if current - previous == 382 else 0
    return -1373427 + current + postpone


def winter_theme_in_season(theme: str, today: date) -> bool:
    """Whole local civil dates; no network, location or sunset lookup needed."""
    if theme == "kwanzaa":
        return (today.month == 12 and today.day >= 26) or (today.month, today.day) == (1, 1)
    if theme == "solstice":
        return today.month == 12  # Available throughout December, like Christmas.
    if theme == "hanukkah":
        # Include the civil opening-evening date through the closing-evening date.
        # The prior festival can extend into January, so inspect both Hebrew years.
        for year in (today.year + 3760, today.year + 3761):
            new_year = hebrew_new_year_ordinal(year)
            year_days = hebrew_new_year_ordinal(year + 1) - new_year
            heshvan_days = 30 if year_days % 10 == 5 else 29
            opening = new_year + 30 + heshvan_days + 23
            if opening <= today.toordinal() <= opening + 8:
                return True
        return False
    return True


def theme_catalog() -> dict[str, dict[str, Any]]:
    """Read bounded, declarative local palettes; never load theme code or URLs."""
    themes = {key: {**value, "colors": dict(value["colors"])}
              for key, value in BUILTIN_THEMES.items()
              if ((key != "christmas" or False or theme_calendar_month() == 12)
                  and (key != "newyear" or False or forced_calendar_theme() == "newyear")
                  and (key not in ("hanukkah", "kwanzaa", "solstice")
                       or False or winter_theme_in_season(key, datetime.now().date())))}
    try:
        THEME_DIR.mkdir(parents=True, exist_ok=True)
        try:
            (THEME_DIR / "images").mkdir(exist_ok=True)
        except OSError:
            pass  # A blocked image folder must not hide otherwise valid palettes.
        example = THEME_DIR / "example.json"
        if not example.exists():
            # Exclusive creation never overwrites a user's existing palette.
            with example.open("x", encoding="utf-8") as stream:
                json.dump({"version": 1, "name": "Example theme", "colors": THEME_COLORS,
                           "background_image": "", "background_opacity": 0.35}, stream, indent=2)
        for path in sorted(THEME_DIR.glob("*.json"))[:100]:
            try:
                if path.is_symlink() or path.stat().st_size > 16384:
                    continue
                if not re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,47}", path.stem):
                    continue
                data = json.loads(path.read_text(encoding="utf-8"))
                if not isinstance(data, dict) or data.get("version") != 1:
                    continue
                name, colors = data.get("name"), data.get("colors")
                if not isinstance(name, str) or not 1 <= len(name.strip()) <= 60:
                    continue
                if not isinstance(colors, dict) or not colors or set(colors) - set(THEME_COLORS):
                    continue
                if any(not isinstance(value, str) or not re.fullmatch(r"#[0-9a-fA-F]{6}", value)
                       for value in colors.values()):
                    continue
                display_name = name.strip()
                if path.name == "example.json" and display_name == "My Theme":
                    display_name = "Example theme"  # Display legacy example clearly without rewriting it.
                theme = {"name": display_name, "filename": path.name,
                         "colors": dict(THEME_COLORS, **colors)}
                image = data.get("background_image")
                opacity = data.get("background_opacity", 0.35)
                if (isinstance(image, str)
                        and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,119}", image)
                        and ".." not in image
                        and Path(image).suffix.lower() in (".png", ".jpg", ".jpeg", ".webp")
                        and isinstance(opacity, (int, float)) and not isinstance(opacity, bool)
                        and math.isfinite(opacity) and 0 <= opacity <= 1):
                    theme["background_image"] = image
                    theme["background_opacity"] = opacity
                themes["custom:" + path.stem] = theme
            except (OSError, ValueError, TypeError):
                continue
    except (OSError, ValueError):
        pass  # Built-ins remain usable when folder access is denied.
    return themes


MAX_THEME_IMAGE_BYTES = 4 * 1024 * 1024


def theme_background_data_uri(filename: str) -> str:
    """Embed a bounded local raster image, never a remote URL or SVG."""
    if (not isinstance(filename, str)
            or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,119}", filename)
            or ".." in filename
            or Path(filename).suffix.lower() not in (".png", ".jpg", ".jpeg", ".webp")):
        return ""
    try:
        image_dir = THEME_DIR / "images"
        path = image_dir / filename
        if (image_dir.is_symlink() or path.is_symlink()
                or not path.resolve().is_relative_to(THEME_DIR.resolve())
                or path.stat().st_size > MAX_THEME_IMAGE_BYTES):
            return ""
        with path.open("rb") as stream:
            content = stream.read(MAX_THEME_IMAGE_BYTES + 1)
        if not content or len(content) > MAX_THEME_IMAGE_BYTES:
            return ""
        extension = path.suffix.lower()
        mime = ""
        if extension == ".png" and content.startswith(b"\x89PNG\r\n\x1a\n"):
            mime = "image/png"
        elif extension in (".jpg", ".jpeg") and content.startswith(b"\xff\xd8\xff"):
            mime = "image/jpeg"
        elif (extension == ".webp" and content[:4] == b"RIFF"
              and content[8:12] == b"WEBP"):
            mime = "image/webp"
        if not mime:
            return ""
        return "data:" + mime + ";base64," + base64.b64encode(content).decode("ascii")
    except (OSError, ValueError):
        return ""


def theme_payload(themes: dict[str, dict[str, Any]], selected: str, include_background: bool = True) -> dict[str, Any]:
    # Only embed the selected image, not every image in the theme folder.
    load_builtin_artwork()
    theme = themes[selected]
    image = theme.get("background_image")
    if image and include_background:
        theme["background_data_uri"] = (BUILTIN_THEME_BACKGROUNDS[selected]
            if selected in BUILTIN_THEME_BACKGROUNDS else theme_background_data_uri(image))
    if include_background and selected in BUILTIN_THEME_STATUS_IMAGES:
        theme.update(BUILTIN_THEME_STATUS_IMAGES[selected])
    if include_background and selected in BUILTIN_THEME_LOGOS:
        theme["logo_data_uri"] = BUILTIN_THEME_LOGOS[selected]
    return {"themes": themes, "selected": selected, "folder": str(THEME_DIR),
            "locked": forced_calendar_theme() == selected}


def theme_state(include_background: bool = True) -> dict[str, Any]:
    themes = theme_catalog()
    selected = forced_calendar_theme() or load_settings().get("theme", "classic")
    if not isinstance(selected, str) or selected not in themes:
        selected = "classic"
    return theme_payload(themes, selected, include_background)


def save_theme(selected: Any) -> dict[str, Any]:
    if forced_calendar_theme():
        return theme_state()  # Temporary calendar override never replaces saved choice.
    themes = theme_catalog()
    if not isinstance(selected, str) or selected not in themes:
        raise ValueError("Theme is unavailable; refresh the page's theme list")
    save_settings({"theme": selected})
    return theme_payload(themes, selected)


THEME_MESSAGE_CHUNK_CHARS = 64 * 1024
THEME_TRANSFER_SERIAL = 0


def theme_transfer_messages(payload: dict[str, Any]):
    """Keep initial HTML and individual bridge messages below host size limits."""
    selected = payload["selected"]
    themes = {key: dict(value) for key, value in payload["themes"].items()}
    assets = [("theme-happy", themes[selected].pop("happy_data_uri", "")),
              ("theme-sad", themes[selected].pop("sad_data_uri", "")),
              ("theme-logo", themes[selected].pop("logo_data_uri", "")),
              ("theme-background", themes[selected].pop("background_data_uri", ""))]
    global THEME_TRANSFER_SERIAL
    THEME_TRANSFER_SERIAL += 1
    token = str(THEME_TRANSFER_SERIAL)
    yield {"type": "theme", "theme_token": token,
           "theme": dict(payload, themes=themes)}
    for kind, image in assets:
        if not image:
            continue
        total = (len(image) + THEME_MESSAGE_CHUNK_CHARS - 1) // THEME_MESSAGE_CHUNK_CHARS
        for index in range(total):
            start = index * THEME_MESSAGE_CHUNK_CHARS
            yield {"type": kind, "theme_token": token,
                   "index": index, "total": total,
                   "chunk": image[start:start + THEME_MESSAGE_CHUNK_CHARS]}


def legacy_settings_paths() -> list[Path]:
    """Find settings stored beside replaceable plugin files by older builds."""
    candidates = {PLUGIN_DIR / SETTINGS_FILENAME}
    plugin_root = ORCA_DATA_DIR / "orca_plugins"
    if plugin_root.is_dir():
        try:
            candidates.update(plugin_root.rglob(SETTINGS_FILENAME))
        except OSError:
            pass
    result = []
    for path in candidates:
        try:
            if path != SETTINGS_PATH and path.is_file():
                result.append(path)
        except OSError:
            continue
    return sorted(result, key=lambda path: path.stat().st_mtime)


def write_settings_payload(payload: dict[str, Any]) -> None:
    SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
    temporary = SETTINGS_PATH.with_suffix(".tmp")
    temporary.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, SETTINGS_PATH)


def log(message: str) -> None:
    try:
        LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with LOG_PATH.open("a", encoding="utf-8") as stream:
            stream.write(f"{message}\n")
    except OSError:
        return


def normalize_url(value: str) -> str:
    value = str(value or "").strip().rstrip("/")
    if not value:
        raise ValueError("Spoolman URL cannot be empty")
    if not value.startswith(("http://", "https://")):
        raise ValueError("Spoolman URL must begin with http:// or https://")
    return value


def load_settings() -> dict[str, Any]:
    settings: dict[str, Any] = {
        "spoolman_url": DEFAULT_SPOOLMAN_URL,
        "show_pipspool_page": True,
        "inject_spool_id_gcode": True,
        "low_stock_threshold_grams": DEFAULT_LOW_STOCK_THRESHOLD_GRAMS,
    }
    migrated = False
    sources = [SETTINGS_PATH] if SETTINGS_PATH.is_file() else legacy_settings_paths()
    for source in sources:
        try:
            stored = json.loads(source.read_text(encoding="utf-8"))
            if isinstance(stored, dict):
                settings.update(stored)
                migrated = source != SETTINGS_PATH
        except (OSError, ValueError, TypeError):
            continue
    if migrated:
        try:
            write_settings_payload(settings)
            log(f"[SETTINGS] Migrated persistent settings to {SETTINGS_PATH}")
        except OSError as exc:
            log(f"[SETTINGS MIGRATION] {exc}")
    # Orca's capability configuration is the durable source for user-entered
    # connection/display settings.  The JSON file still owns synchronization
    # state shared by the other PipSpool capabilities, but must not be able to
    # replace a value that Orca has already restored for this session.
    settings.update(HOST_USER_SETTINGS)
    return settings


def pipspool_page_enabled() -> bool:
    """Read only our visibility preference; never scan or migrate during registration.

    Orca decides which page tabs exist during registration and has no runtime
    visibility API. The exact settings target is declared by the package first.
    The host owns access policy; declaring a target is not an approval bypass.
    """
    if "show_pipspool_page" in HOST_USER_SETTINGS:
        return HOST_USER_SETTINGS["show_pipspool_page"] is not False
    try:
        saved = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
        return not isinstance(saved, dict) or saved.get("show_pipspool_page", True) is not False
    except FileNotFoundError:
        return True
    except PermissionError:
        return False  # Do not register the optional page using an unreadable preference.
    except (OSError, ValueError, TypeError):
        return True


def low_stock_threshold(settings: dict[str, Any] | None = None) -> float:
    value = (settings or load_settings()).get(
        "low_stock_threshold_grams", DEFAULT_LOW_STOCK_THRESHOLD_GRAMS
    )
    threshold = numeric(value)
    if threshold is None or threshold < 0:
        return DEFAULT_LOW_STOCK_THRESHOLD_GRAMS
    return round(threshold, 1)


def spool_id_gcode_enabled(settings: dict[str, Any] | None = None) -> bool:
    return (settings or load_settings()).get("inject_spool_id_gcode", True) is not False


def spool_table_columns(settings: dict[str, Any] | None = None) -> list[str]:
    value = (settings or load_settings()).get("spool_table_columns")
    if not isinstance(value, list):
        return list(DEFAULT_SPOOL_TABLE_COLUMNS)
    return [column for column in SPOOL_TABLE_COLUMNS if column in value]


def restart_required(settings: dict[str, Any] | None = None) -> bool:
    """Keep the notice for this Orca process and clear it on the next launch."""
    current = settings or load_settings()
    return (
        current.get("restart_required") is True
        and current.get("restart_required_process_id") == os.getpid()
    )


def version_numbers(value: Any) -> tuple[int, int, int] | None:
    match = re.match(r"^v?(\d+)\.(\d+)\.(\d+)", str(value or "").strip())
    return tuple(int(part) for part in match.groups()) if match else None


def available_update(settings: dict[str, Any] | None = None) -> str | None:
    latest = str((settings or load_settings()).get("latest_available_version") or "")
    installed_numbers = version_numbers(PLUGIN_VERSION)
    latest_numbers = version_numbers(latest)
    if installed_numbers and latest_numbers and latest_numbers > installed_numbers:
        return latest.lstrip("v")
    return None


def check_for_update(force: bool = False) -> str | None:
    """Refresh the cached public release version without affecting core sync."""
    settings = load_settings()
    checked_at = numeric(settings.get("update_checked_at")) or 0
    if not force and time.time() - checked_at < UPDATE_CHECK_INTERVAL_SECONDS:
        return available_update(settings)
    update = {"update_checked_at": time.time()}
    try:
        response = HTTP_SESSION.get(
            LATEST_RELEASE_API,
            headers={"Accept": "application/vnd.github+json"},
            timeout=4,
        )
        response.raise_for_status()
        tag = str(response.json().get("tag_name") or "").strip()
        if version_numbers(tag):
            update["latest_available_version"] = tag.lstrip("v")
    except Exception as exc:
        log(f"[UPDATE CHECK] {exc}")
    try:
        save_settings(update)
    except Exception as exc:
        log(f"[UPDATE CACHE] {exc}")
    settings.update(update)
    return available_update(settings)


def has_saved_settings() -> bool:
    try:
        if normalize_url(HOST_USER_SETTINGS.get("spoolman_url", "")):
            return True
    except (ValueError, TypeError):
        pass
    try:
        stored = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
        return isinstance(stored, dict) and bool(
            normalize_url(stored.get("spoolman_url", ""))
        )
    except (OSError, ValueError, TypeError):
        return False


def save_settings(settings: dict[str, Any]) -> None:
    payload = load_settings()
    payload.update(settings)
    payload["spoolman_url"] = normalize_url(payload.get("spoolman_url", ""))
    payload.pop("moonraker_url", None)
    payload.pop("moonraker_enabled", None)
    write_settings_payload(payload)


def safe_filename(value: str) -> str:
    cleaned = re.sub(r'[\\/:*?"<>|]', "", str(value)).strip()
    return cleaned or "Unnamed spool"


def spool_id_from_name(filename: str) -> int | None:
    matches = re.findall(r"\(#(\d+)\)", filename)
    return int(matches[0]) if len(matches) == 1 and int(matches[0]) > 0 else None


def managed_spool_id_from_name(filename: str) -> int | None:
    if not filename.endswith((PROFILE_SUFFIX, " - Spoolman.json")):
        return None
    return spool_id_from_name(filename)


def validate_profile_name_template(value: Any) -> str:
    if not isinstance(value, str) or not value.strip() or len(value) > 120:
        raise ValueError("Profile naming must contain 1–120 characters")
    if re.search(r"[\x00-\x1f]", value):
        raise ValueError("Profile naming cannot contain control characters")
    value = value.strip()
    tokens = re.findall(r"\{([^{}]*)\}", value)
    remainder = re.sub(r"\{[^{}]*\}", "", value)
    if (tokens.count("spool_id") != 1 or any(token not in PROFILE_NAME_TOKENS for token in tokens)
            or "{" in remainder or "}" in remainder or "(#" in remainder
            or re.search(r'[\\/:*?"<>|\x00-\x1f]', value)):
        raise ValueError("Use {spool_id} exactly once and only {material}, {name}, {vendor}; avoid filename characters and literal (# markers")
    return value


def profile_name_template(settings: dict[str, Any] | None = None) -> str:
    try:
        return validate_profile_name_template((settings if settings is not None else load_settings()).get(
            "profile_name_template", DEFAULT_PROFILE_NAME_TEMPLATE))
    except ValueError:
        return DEFAULT_PROFILE_NAME_TEMPLATE


def profile_display_name(spool_id: int, material: str, name: str, vendor: str,
                         template: str | None = None) -> str:
    template = validate_profile_name_template(template) if template is not None else profile_name_template()
    def descriptive(value):
        # A data field must never introduce another identity marker or a path.
        return re.sub(r"\s+", " ", re.sub(r"[\x00-\x1f]", "", safe_filename(str(value))).replace("(#", "[#")).strip()
    values = {"spool_id": f"(#{spool_id})", "material": descriptive(material),
              "name": descriptive(name) if name else "", "vendor": descriptive(vendor)}
    rendered = re.sub(r"\{([^{}]+)\}", lambda match: values[match.group(1)], template)
    rendered = re.sub(r"\s+", " ", rendered).strip() + " - PipSpool"
    if len((rendered + ".json").encode("utf-8")) > 240:
        raise ValueError("Profile name is too long; shorten the naming format or filament details")
    return rendered


def decode_extra_value(value: Any) -> Any:
    decoded = value
    for _ in range(2):
        if not isinstance(decoded, str):
            break
        try:
            next_value = json.loads(decoded)
        except (TypeError, ValueError):
            break
        if next_value == decoded:
            break
        decoded = next_value
    return decoded


def validate_spool_id_command_template(value: Any) -> str:
    if not isinstance(value, str) or not value.strip() or len(value) > 200:
        raise ValueError("Spool-ID command must contain 1–200 characters")
    if re.search(r"[\x00-\x1f\x7f]", value):
        raise ValueError("Spool-ID command must be a single line without control characters")
    value = value.strip()
    remainder = value.replace("{spool_id}", "")
    if (value.count("{spool_id}") != 1 or "{" in remainder or "}" in remainder
            or "{spool_id}" not in value.split(";", 1)[0]
            or not re.match(r"^[A-Za-z][A-Za-z0-9_]*\s+", value)):
        raise ValueError("Use one command followed by parameters containing {spool_id} exactly once; no other placeholders are supported")
    return value


def spool_id_command_template(settings: dict[str, Any] | None = None) -> str:
    try:
        return validate_spool_id_command_template(
            (settings if settings is not None else load_settings()).get(
                "spool_id_command_template", DEFAULT_SPOOL_ID_COMMAND))
    except ValueError:
        return DEFAULT_SPOOL_ID_COMMAND


def render_spool_id_command(spool_id: int, template: str | None = None) -> str:
    if isinstance(spool_id, bool) or not isinstance(spool_id, int) or spool_id <= 0:
        raise ValueError("Spool ID must be a positive integer")
    template = spool_id_command_template() if template is None else validate_spool_id_command_template(template)
    return template.replace("{spool_id}", str(spool_id))


def managed_start_gcode(
    existing: Any,
    spool_id: int,
    custom_gcode: Any = None,
    inject_spool_id: bool = True,
    command_template: str | None = None,
) -> list[str]:
    if isinstance(existing, list):
        text = str(existing[0]) if existing else ""
    else:
        text = "" if existing is None else str(existing)

    for begin, end in (
        (START_MARKER, END_MARKER),
        (LEGACY_START_MARKER, LEGACY_END_MARKER),
    ):
        pattern = re.compile(
            rf"(?:\r?\n)?{re.escape(begin)}.*?{re.escape(end)}(?:\r?\n)?",
            re.DOTALL,
        )
        text = pattern.sub("\n", text)

    preserved = text.rstrip()
    custom_text = decode_extra_value(custom_gcode)
    if custom_text is None:
        custom_text = ""
    custom_text = str(custom_text).strip()
    template = spool_id_command_template() if command_template is None else validate_spool_id_command_template(command_template)
    if not inject_spool_id and custom_text:
        command_name = template.split()[0]
        custom_text = "\n".join(
            line for line in custom_text.splitlines()
            if "{spool_id}" not in line and not re.match(
                rf"^\s*(?:{ACTIVE_SPOOL_GCODE}|{LEGACY_SPOOL_GCODE}|{re.escape(command_name)})(?:\s|$)",
                line,
                re.IGNORECASE,
            )
        ).strip()
    # Substitute only the literal token; retain other Orca/Klipper syntax.
    if inject_spool_id:
        custom_text = custom_text.replace("{spool_id}", str(int(spool_id)))
    managed_text = custom_text or (
        render_spool_id_command(spool_id, template) if inject_spool_id else ""
    )
    if not managed_text:
        return [preserved]
    block = f"{START_MARKER}\n{managed_text}\n{END_MARKER}"
    return [f"{preserved}\n\n{block}" if preserved else block]


def support_directory() -> Path | None:
    for parent in (PLUGIN_DIR, *PLUGIN_DIR.parents):
        if parent.name == "OrcaSlicer":
            return parent

    appdata = os.environ.get("APPDATA")
    candidates = [
        Path.home() / "Library" / "Application Support" / "OrcaSlicer",
        Path.home() / ".config" / "OrcaSlicer",
    ]
    if appdata:
        candidates.append(Path(appdata) / "OrcaSlicer")
    return next((path for path in candidates if path.is_dir()), None)


@dataclass
class SyncReport:
    active_spools: int = 0
    created: int = 0
    updated: int = 0
    renamed: int = 0
    removed: int = 0
    unchanged: int = 0
    changes: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    restart_required: bool = False

    @property
    def changed(self) -> bool:
        return bool(self.created or self.updated or self.renamed or self.removed)

    @property
    def changed_spools(self) -> int:
        """Count logical spools, not copies written to Orca profile folders."""
        return len({
            int(match.group(1))
            for change in self.changes
            if (match := re.match(r"^Spool #(\d+):", change))
        })

    def summary(self) -> str:
        details = (
            f"Active spools: {self.active_spools}\n"
            f"Created: {self.created}\nUpdated: {self.updated}\n"
            f"Renamed: {self.renamed}\nRemoved: {self.removed}\n"
            f"Unchanged: {self.unchanged}"
        )
        if self.errors:
            details += f"\nErrors: {len(self.errors)}\n" + "\n".join(self.errors[:5])
        if self.changes:
            details += "\n\nChanges:\n" + "\n".join(
                f"• {change}" for change in self.changes
            )
        return details


class SpoolmanClient:
    def __init__(self, base_url: str):
        self.base_url = normalize_url(base_url)

    def active_spools(self) -> list[dict[str, Any]]:
        response = HTTP_SESSION.get(
            f"{self.base_url}/api/v1/spool",
            params={"allow_archived": "false"},
            timeout=10,
        )
        response.raise_for_status()
        payload = response.json()
        if not isinstance(payload, list):
            raise ValueError("Spoolman returned an unexpected spool response")
        return [
            item
            for item in payload
            if isinstance(item, dict) and not spool_is_archived(item)
        ]

    def ensure_start_gcode_field(self) -> bool:
        response = HTTP_SESSION.get(f"{self.base_url}/api/v1/field/spool", timeout=10)
        response.raise_for_status()
        fields = response.json()
        if not isinstance(fields, list):
            raise ValueError("Spoolman returned an unexpected extra-field response")

        existing = next(
            (field for field in fields if isinstance(field, dict) and field.get("key") == "start_gcode"),
            None,
        )
        if existing is not None:
            if existing.get("field_type") != "text":
                raise ValueError("Spoolman field 'start_gcode' exists but is not a text field")
            return False

        response = HTTP_SESSION.post(
            f"{self.base_url}/api/v1/field/spool/start_gcode",
            json={"name": "Start G-code", "field_type": "text", "order": 0},
            timeout=10,
        )
        response.raise_for_status()
        return True

    def ensure_orca_filament_fields(self, selected_settings=ORCA_SETTINGS, entity="filament") -> int:
        if entity not in ("filament", "spool"):
            raise ValueError("Unsupported advanced field entity")
        response = HTTP_SESSION.get(f"{self.base_url}/api/v1/field/{entity}", timeout=10)
        response.raise_for_status()
        fields = response.json()
        if not isinstance(fields, list):
            raise ValueError("Spoolman returned an unexpected filament-field response")
        existing = {
            field.get("key"): field for field in fields if isinstance(field, dict)
        }
        created = 0
        order = 100
        selected = set(selected_settings)
        for group, settings in ORCA_SETTING_GROUPS.items():
            for setting in settings:
                if setting not in selected:
                    continue
                key = f"{ORCA_FIELD_PREFIX}{setting}"
                label = setting.replace("_", " ").title()
                unit = ORCA_SETTING_UNITS.get(setting)
                field_type = orca_setting_field_type(setting)
                desired = {
                    "name": f"{group}: {label}",
                    "field_type": field_type,
                    "order": order,
                }
                if unit and field_type in {"integer", "float"}:
                    desired["unit"] = unit
                if field_type == "choice":
                    desired["choices"] = list(ORCA_CHOICE_SETTINGS[setting])
                    desired["multi_choice"] = False
                field = existing.get(key)
                if field is not None:
                    if field.get("field_type") != field_type:
                        if entity == "spool":
                            raise ValueError(f"Spool field {key} has an incompatible type; preserved")
                        self._replace_field_definition_safely(
                            setting, key, field, desired
                        )
                        order += 1
                        continue
                    if any(field.get(name) != value for name, value in desired.items()):
                        response = HTTP_SESSION.post(
                            f"{self.base_url}/api/v1/field/{entity}/{key}",
                            json=desired,
                            timeout=10,
                        )
                        response.raise_for_status()
                    order += 1
                    continue
                response = HTTP_SESSION.post(
                    f"{self.base_url}/api/v1/field/{entity}/{key}",
                    json=desired,
                    timeout=10,
                )
                response.raise_for_status()
                created += 1
                order += 1
        return created

    def _validated_field_value_migrations(
        self, setting: str, key: str
    ) -> list[tuple[int, str, str]]:
        """Preflight old Text values before changing a PipSpool field type."""
        response = HTTP_SESSION.get(f"{self.base_url}/api/v1/filament", timeout=10)
        response.raise_for_status()
        filaments = response.json()
        if not isinstance(filaments, list):
            raise ValueError("Spoolman returned an unexpected filament response")
        migrations: list[tuple[int, str, str]] = []
        for filament in filaments:
            if not isinstance(filament, dict):
                continue
            raw = dict(filament.get("extra") or {}).get(key)
            if raw is None:
                continue
            encoded = encode_spoolman_setting_value(setting, decode_extra_value(raw))
            if encoded is None:
                raise ValueError(
                    f"Spoolman field '{key}' contains a value that cannot be "
                    f"converted safely; its type was not changed"
                )
            migrations.append((int(filament["id"]), encoded, raw))
        return migrations

    def _replace_field_definition_safely(
        self,
        setting: str,
        key: str,
        existing: dict[str, Any],
        desired: dict[str, Any],
    ) -> None:
        """Replace an incompatible field and restore the original on failure."""
        migrations = self._validated_field_value_migrations(setting, key)
        original = {
            name: existing[name]
            for name in (
                "name", "field_type", "order", "unit", "default_value",
                "choices", "multi_choice",
            )
            if name in existing and existing[name] is not None
        }
        endpoint = f"{self.base_url}/api/v1/field/filament/{key}"
        deleted = False
        try:
            response = HTTP_SESSION.delete(endpoint, timeout=10)
            response.raise_for_status()
            deleted = True
            response = HTTP_SESSION.post(endpoint, json=desired, timeout=10)
            response.raise_for_status()
            for filament_id, encoded, _original_raw in migrations:
                self.update_filament_extras(filament_id, {key: encoded})
        except Exception as migration_error:
            if not deleted:
                raise
            try:
                # Remove a partially created replacement. A failed creation may
                # legitimately leave no definition, in which case 404 is safe.
                response = HTTP_SESSION.delete(endpoint, timeout=10)
                if getattr(response, "status_code", 200) != 404:
                    response.raise_for_status()
                response = HTTP_SESSION.post(endpoint, json=original, timeout=10)
                response.raise_for_status()
                for filament_id, _encoded, original_raw in migrations:
                    self.update_filament_extras(
                        filament_id, {key: original_raw}
                    )
            except Exception as rollback_error:
                raise RuntimeError(
                    f"Spoolman field '{key}' migration failed and its automatic "
                    f"rollback also failed: {rollback_error}"
                ) from migration_error
            raise RuntimeError(
                f"Spoolman field '{key}' migration failed; its original Text "
                "definition and values were restored"
            ) from migration_error

    def remove_unselected_orca_filament_fields(self, selected_settings) -> int:
        selected_keys = {orca_extra_key(setting) for setting in selected_settings}
        response = HTTP_SESSION.get(f"{self.base_url}/api/v1/field/filament", timeout=10)
        response.raise_for_status()
        fields = response.json()
        if not isinstance(fields, list):
            raise ValueError("Spoolman returned an unexpected filament-field response")
        removed = 0
        for field in fields:
            key = field.get("key") if isinstance(field, dict) else None
            if not isinstance(key, str) or not key.startswith(ORCA_FIELD_PREFIX):
                continue
            if key in selected_keys:
                continue
            response = HTTP_SESSION.delete(
                f"{self.base_url}/api/v1/field/filament/{key}", timeout=10
            )
            response.raise_for_status()
            removed += 1
        return removed

    def update_filament_extras(self, filament_id: int, values: dict[str, str]) -> None:
        response = HTTP_SESSION.patch(
            f"{self.base_url}/api/v1/filament/{int(filament_id)}",
            json={"extra": values},
            timeout=10,
        )
        response.raise_for_status()


    def update_spool_extras(self, spool_id: int, values: dict[str, str]) -> None:
        response = HTTP_SESSION.patch(
            f"{self.base_url}/api/v1/spool/{int(spool_id)}", json={"extra": values}, timeout=10)
        response.raise_for_status()


class OrcaProfiles:
    def __init__(self, root: Path):
        self.root = root
        self.user_root = root / "user"
        self.system_root = root / "system"
        self.system_presets = self._system_preset_index()
        # This is a plain-data copy captured on Orca's host thread. Never keep
        # live preset handles for use by PipSpool's background workers.
        self.live_system_presets = {
            str(name): list(material_types)
            for name, material_types in LIVE_SYSTEM_FILAMENT_PRESETS.items()
        }

    def _system_preset_index(self) -> dict[str, dict[str, Any]]:
        result: dict[str, dict[str, Any]] = {}
        if not self.system_root.is_dir():
            return result
        for path in self.system_root.rglob("*.json"):
            if "filament" not in path.parts:
                continue
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                if not isinstance(data, dict):
                    continue
                # Filenames are only a compatibility fallback. They must never
                # replace an authoritative identity supplied inside another
                # Orca system preset (which can otherwise hide all children).
                result.setdefault(path.stem, data)
                if not path.stem.casefold().endswith("@system"):
                    result.setdefault(f"{path.stem} @System", data)
                aliases = set()
                name = data.get("name")
                if isinstance(name, str) and name.strip():
                    aliases.add(name.strip())
                settings_ids = data.get("filament_settings_id")
                if isinstance(settings_ids, str) and settings_ids.strip():
                    aliases.add(settings_ids.strip())
                elif isinstance(settings_ids, list):
                    aliases.update(
                        value.strip() for value in settings_ids
                        if isinstance(value, str) and value.strip()
                    )
                for alias in tuple(aliases):
                    result[alias] = data
                    if not alias.casefold().endswith("@system"):
                        result[f"{alias} @System"] = data
            except (OSError, ValueError, TypeError):
                continue
        return result

    def user_filament_directories(self) -> list[Path]:
        if not self.user_root.is_dir():
            return []
        directories = []
        for profile_root in self.user_root.iterdir():
            if profile_root.is_dir():
                directories.append(profile_root / "filament")
        return directories

    def parent_for(self, vendor: str, material: str) -> str:
        material_key = material.strip().casefold()

        # Recent Orca builds keep system filament presets in vendor .opc
        # caches. Prefer the host-supplied snapshot when it contains a suitable
        # portable parent, then retain the JSON index as an older-build fallback.
        live_parent = self._parent_from_index(
            vendor, material, self.live_system_presets
        )
        if live_parent is not None:
            return live_parent

        presets_by_type: dict[str, list[str]] = {}
        for name, preset in self.system_presets.items():
            types = preset.get("filament_type") or []
            if isinstance(types, str):
                types = [types]
            for value in types:
                type_key = str(value).strip().casefold()
                if type_key:
                    presets_by_type.setdefault(type_key, []).append(name)

        parent_type = material_key
        matching = presets_by_type.get(parent_type, [])
        if not matching:
            compatible_types = [
                type_key for type_key in presets_by_type
                if material_key.startswith(type_key)
                and len(material_key) > len(type_key)
                and not material_key[len(type_key)].isalnum()
            ]
            if compatible_types:
                parent_type = max(compatible_types, key=len)
                matching = presets_by_type[parent_type]
        if not matching:
            parent_type = "pla"
            matching = presets_by_type.get(parent_type, [])

        exact_generic = f"generic {parent_type} @system"
        for name in matching:
            if name.strip().casefold() == exact_generic:
                return name
        # Never accept a printer-specific preset merely because its name begins
        # with "Generic PETG" (or another material). Orca hides children of that
        # parent whenever a different printer is active.
        return f"Generic {parent_type.upper()} @System"

    @staticmethod
    def _parent_from_index(
        vendor: str,
        material: str,
        presets: dict[str, list[str]],
    ) -> str | None:
        """Select a portable live system parent without retaining host handles."""
        if not presets:
            return None
        material_text = material.strip()
        material_key = material_text.casefold()
        vendor_text = vendor.strip()
        names = {str(name).strip().casefold(): str(name) for name in presets}

        def named_parent(prefix: str, type_name: str) -> str | None:
            candidate = f"{prefix} {type_name} @System".strip()
            return names.get(candidate.casefold())

        if vendor_text:
            found = named_parent(vendor_text, material_text)
            if found:
                return found
        found = named_parent("Generic", material_text)
        if found:
            return found

        type_names: dict[str, str] = {}
        for values in presets.values():
            for value in values:
                type_name = str(value).strip()
                if type_name:
                    type_names.setdefault(type_name.casefold(), type_name)
        compatible = [
            type_key for type_key in type_names
            if material_key.startswith(type_key)
            and len(material_key) > len(type_key)
            and not material_key[len(type_key)].isalnum()
        ]
        if not compatible:
            return None
        type_name = type_names[max(compatible, key=len)]
        if vendor_text:
            found = named_parent(vendor_text, type_name)
            if found:
                return found
        return named_parent("Generic", type_name)

    def effective_preset(self, preset: dict[str, Any]) -> dict[str, Any]:
        chain = []
        current = preset
        visited: set[str] = set()
        while isinstance(current, dict):
            chain.append(current)
            parent_name = current.get("inherits")
            if not isinstance(parent_name, str) or not parent_name or parent_name in visited:
                break
            visited.add(parent_name)
            current = self.system_presets.get(parent_name)
            if current is None:
                break
        resolved: dict[str, Any] = {}
        for item in reversed(chain):
            resolved.update(item)
        return resolved

    def preset_for_spool(self, spool_id: int) -> dict[str, Any]:
        try:
            return next(iter(self.presets_for_spool(spool_id)), {})
        except (OSError, ValueError, TypeError):
            return {}  # Dashboard diagnostics report unreadable copies separately.

    def presets_for_spool(self, spool_id: int) -> list[dict[str, Any]]:
        """Read every saved copy; filesystem enumeration order must not hide edits."""
        presets = []
        for directory in self.user_filament_directories():
            for path in directory.glob("*.json"):
                if managed_spool_id_from_name(path.name) == int(spool_id):
                    preset = json.loads(path.read_text(encoding="utf-8"))
                    if not isinstance(preset, dict):
                        raise ValueError(f"Unreadable spool profile: {path.name}")
                    if managed_spool_id_from_name(str(preset.get("name", "")) + ".json") == int(spool_id):
                        presets.append(preset)
        return presets

    def inherited_start_gcode(self, preset: dict[str, Any]) -> Any:
        visited: set[str] = set()
        parent_name = preset.get("inherits")
        while isinstance(parent_name, str) and parent_name and parent_name not in visited:
            visited.add(parent_name)
            parent = self.system_presets.get(parent_name)
            if not parent:
                break
            if "filament_start_gcode" in parent:
                return parent["filament_start_gcode"]
            parent_name = parent.get("inherits")
        return []


def filament_material(filament: dict[str, Any]) -> str:
    return str(filament.get("material") or "PLA").strip()


def orca_extra_key(setting: str) -> str:
    return f"{ORCA_FIELD_PREFIX}{setting}"


def decoded_orca_overrides(
    filament: dict[str, Any], selected_settings=ORCA_SETTINGS
) -> dict[str, Any]:
    extras = dict(filament.get("extra") or {})
    result = {}
    for setting in selected_settings:
        value = decode_extra_value(extras.get(orca_extra_key(setting)))
        if setting in ORCA_LIST_TEXT_SETTINGS:
            result[setting] = normalized_orca_text_list(value)
            continue
        if value not in (None, ""):
            values = value if isinstance(value, list) else [value]
            converted = [
                orca_serialized_setting_value(setting, item) for item in values
            ]
            converted = [item for item in converted if item is not None]
            if converted:
                result[setting] = (
                    converted[0]
                    if setting in ORCA_SCALAR_TEXT_SETTINGS
                    else converted
                )
    return result


def orca_serialized_setting_value(setting: str, value: Any) -> str | None:
    """Convert a typed Spoolman scalar to Orca's serialized vector element."""
    encoded = encode_spoolman_setting_value(setting, value)
    if encoded is None:
        return None
    native = json.loads(encoded)
    field_type = orca_setting_field_type(setting)
    if field_type == "boolean":
        return "1" if native else "0"
    if field_type == "integer":
        return str(int(native))
    if field_type == "float":
        return format(float(native), ".15g")
    return str(native)


def normalized_orca_text_list(value: Any) -> list[str]:
    """Normalize Orca list fields and discard nested/quoted empty entries."""
    decoded = value
    for _ in range(4):
        if not isinstance(decoded, str):
            break
        stripped = decoded.strip()
        if not stripped:
            return []
        try:
            next_value = json.loads(stripped)
        except (TypeError, ValueError):
            break
        if next_value == decoded:
            break
        decoded = next_value

    items = decoded if isinstance(decoded, (list, tuple)) else [decoded]
    normalized: list[str] = []
    for item in items:
        nested = item
        for _ in range(4):
            if not isinstance(nested, str):
                break
            stripped = nested.strip()
            if not stripped:
                nested = ""
                break
            try:
                next_value = json.loads(stripped)
            except (TypeError, ValueError):
                break
            if next_value == nested:
                break
            nested = next_value
        if isinstance(nested, (list, tuple)):
            normalized.extend(normalized_orca_text_list(nested))
            continue
        text = str(nested).strip() if nested is not None else ""
        if text:
            normalized.append(text)
    return normalized


def malformed_empty_orca_text_list(value: Any) -> bool:
    """Identify the quoted-empty list emitted by PipSpool 2.2.7."""
    decoded = decode_extra_value(value)
    return (
        isinstance(decoded, (list, tuple))
        and bool(decoded)
        and not normalized_orca_text_list(decoded)
    )


def encode_spoolman_setting_value(setting: str, value: Any) -> str | None:
    """Encode one Orca filament value for its semantic Spoolman field type."""
    if setting in ORCA_LIST_TEXT_SETTINGS:
        if value is None:
            return None
        values = normalized_orca_text_list(value)
        serialized_list = json.dumps(
            values,
            separators=(",", ":"),
        )
        # Spoolman decodes an extra value once before validating its field
        # type. Keep Orca's JSON list inside a JSON string so a Text field sees
        # text rather than a raw list; decode_extra_value restores the list.
        return json.dumps(serialized_list, separators=(",", ":"))
    if isinstance(value, (list, tuple)):
        if not value:
            return None
        value = value[0]
    if value is None or value == "":
        return None

    field_type = orca_setting_field_type(setting)
    try:
        if field_type == "boolean":
            if isinstance(value, str):
                normalized = value.strip().casefold()
                if normalized in {"1", "true", "yes", "on"}:
                    value = True
                elif normalized in {"0", "false", "no", "off"}:
                    value = False
                else:
                    return None
            else:
                value = bool(value)
        elif field_type == "integer":
            value = int(float(value))
        elif field_type == "float":
            value = float(value)
        elif field_type == "choice":
            choices = ORCA_CHOICE_SETTINGS[setting]
            if isinstance(value, (int, float)) or str(value).strip().isdigit():
                index = int(value)
                if not 0 <= index < len(choices):
                    return None
                value = choices[index]
            else:
                value = str(value)
                if value not in choices:
                    return None
        else:
            value = str(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return json.dumps(value, separators=(",", ":"))


def numeric(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def spool_is_archived(spool: dict[str, Any]) -> bool:
    value = spool.get("archived", False)
    if isinstance(value, str):
        return value.strip().casefold() in {"1", "true", "yes", "on"}
    return bool(value)


def desired_preset(
    spool: dict[str, Any],
    existing: dict[str, Any],
    profiles: OrcaProfiles,
    selected_settings=ORCA_SETTINGS,
    inject_spool_id: bool = True,
) -> tuple[str, dict[str, Any]]:
    spool_id = int(spool["id"])
    filament = spool.get("filament") or {}
    vendor_data = filament.get("vendor") or {}
    vendor = str(vendor_data.get("name") or "Generic").strip()
    filament_name = str(filament.get("name") or filament_material(filament)).strip()
    material = filament_material(filament)
    material_prefix = re.compile(rf"^{re.escape(material)}(?:\s+|$)", re.IGNORECASE)
    filament_detail = material_prefix.sub("", filament_name, count=1).strip()
    material_and_name = f"{material} {filament_detail}".strip()
    display_name = profile_display_name(spool_id, material, filament_detail, vendor)

    preset = dict(existing)
    dependency_values = {
        key: preset[key]
        for key in ORCA_DEPENDENCY_KEYS
        if key in preset and key not in selected_settings
    }
    desired_parent = profiles.parent_for(vendor, material)
    # Reapply PipSpool's portable base on every sync. This also repairs profiles
    # whose parent was set to a printer-specific preset by an older build.
    preset["inherits"] = desired_parent

    start_gcode = preset.get("filament_start_gcode")
    if start_gcode is None:
        start_gcode = profiles.inherited_start_gcode(preset)

    color = str(filament.get("color_hex") or "FFFFFF").lstrip("#")
    spool_extras = dict(spool.get("extra") or {})
    preset.update(
        {
            "name": display_name,
            "from": "User",
            "version": "2.5.0.0",
            "filament_settings_id": [display_name],
            "filament_vendor": [vendor],
            "filament_type": [material],
            "default_filament_colour": [f"#{color}"],
        }
    )

    nozzle = numeric(filament.get("settings_extruder_temp"))
    if nozzle and nozzle > 0:
        temperature = str(round(nozzle))
        preset["nozzle_temperature"] = [temperature]
        preset["nozzle_temperature_initial_layer"] = [temperature]

    bed = numeric(filament.get("settings_bed_temp"))
    if bed and bed > 0:
        temperature = str(round(bed))
        for plate_key in (
            "supertack_plate_temp",
            "cool_plate_temp",
            "textured_cool_plate_temp",
            "eng_plate_temp",
            "hot_plate_temp",
            "textured_plate_temp",
        ):
            preset[plate_key] = [temperature]
            preset[f"{plate_key}_initial_layer"] = [temperature]

    price = numeric(spool.get("price"))
    if price is None:
        price = numeric(filament.get("price"))
    weight = numeric(filament.get("weight"))
    if price is not None and weight and weight > 0:
        preset["filament_cost"] = [f"{price * 1000 / weight:.2f}"]

    extras = dict(filament.get("extra") or {})
    extras.update(spool_extras)
    max_flow = numeric(decode_extra_value(extras.get("max_volumetric_speed")))
    if max_flow is not None and max_flow > 0:
        preset["filament_max_volumetric_speed"] = [str(max_flow)]

    # Only apply advanced values after synchronize_filament_settings has
    # reconciled both sides. Raw Spoolman data must never win by accident.
    if filament.get("_pipspool_advanced_values_reconciled") is True:
        conflicted = set(filament.get("_pipspool_advanced_conflicts") or ())
        reconciled_settings = tuple(
            setting for setting in selected_settings if setting not in conflicted
        )
        # Selected dependencies are jointly managed. Remove an old local value
        # first so an empty Spoolman value clears a bad Orca restriction.
        for key in ORCA_DEPENDENCY_KEYS:
            if key in reconciled_settings:
                preset.pop(key, None)
        preset.update(decoded_orca_overrides(filament, reconciled_settings))
        # Generated nozzle/bed defaults overlap selected advanced fields.
        # A conflict must preserve the original override (or inheritance), not
        # silently replace it with the ordinary Spoolman temperature.
        for setting in conflicted.intersection(selected_settings):
            if setting in existing:
                preset[setting] = existing[setting]
            else:
                preset.pop(setting, None)

    # Apply identity last so shared advanced Start G-code cannot restore another
    # spool's managed ID or defeat the dashboard off switch.
    preset["filament_start_gcode"] = managed_start_gcode(
        preset.get("filament_start_gcode", start_gcode), spool_id,
        spool_extras.get("start_gcode"), inject_spool_id,
    )

    # Preserve restrictions unless the user explicitly selected that dependency
    # field for synchronization. Unselected compatibility remains Orca-owned.
    preset.update(dependency_values)

    return display_name, preset


def host_filament_preset_snapshot(
    selected_settings=ORCA_SETTINGS,
) -> dict[str, dict[str, Any]]:
    """Copy Orca preset values and system-parent metadata on the host thread."""
    global LIVE_SYSTEM_FILAMENT_PRESETS
    snapshot: dict[str, dict[str, Any]] = {}
    system_presets: dict[str, list[str]] = {}
    try:
        collection = orca.host.preset_bundle().filaments
        for name in collection.preset_names():
            preset = collection.find_preset(name)
            if preset is None:
                continue
            keys = set(preset.config_keys())
            system_flag = getattr(preset, "is_system", False)
            if callable(system_flag):
                system_flag = system_flag()
            if system_flag and "filament_type" in keys:
                material_types = preset.config_value("filament_type")
                if isinstance(material_types, str):
                    material_types = material_types.split(";")
                elif not isinstance(material_types, (list, tuple)):
                    material_types = []
                cleaned_types = [
                    str(value).strip() for value in material_types
                    if str(value).strip()
                ]
                if cleaned_types:
                    system_presets[str(name)] = cleaned_types
            values = {}
            for setting in selected_settings:
                if setting not in keys:
                    continue
                value = preset.config_value(setting)
                if value is not None:
                    values[setting] = value
            if values:
                snapshot[str(name)] = values
        LIVE_SYSTEM_FILAMENT_PRESETS = system_presets
    except Exception as exc:
        log(f"[ORCA PRESET SNAPSHOT] {exc}")
    return snapshot


def shared_filament_settings(settings=None) -> bool:
    return (load_settings() if settings is None else settings).get("shared_filament_settings", True) is not False


def individual_state_key(spool) -> str:
    return f"spool:{int(spool['id'])}:filament:{int(spool['filament']['id'])}"


def individual_settings_spool(spool):
    """Build isolated effective advanced data without modifying shared Filament objects."""
    result = dict(spool)
    filament = dict(spool.get("filament") or {})
    extras = {key: value for key, value in (filament.get("extra") or {}).items()
              if not key.startswith(ORCA_FIELD_PREFIX)}
    extras.update({key: value for key, value in (spool.get("extra") or {}).items()
                   if key.startswith(ORCA_FIELD_PREFIX)})
    filament["extra"] = extras
    result["filament"] = filament
    return result


def ensure_advanced_fields(client, selected, settings):
    if shared_filament_settings(settings):
        return client.ensure_orca_filament_fields(selected)
    return client.ensure_orca_filament_fields(selected, entity="spool")


def reconcile_advanced_settings(spools, profiles, client, settings, **kwargs):
    if shared_filament_settings(settings):
        return synchronize_filament_settings(spools, profiles, client, **kwargs)
    state = kwargs.pop("sync_state", {})
    updated = 0
    for spool in spools:
        if (spool.get("filament") or {}).get("id") is None:
            continue
        prepared = individual_settings_spool(spool)
        key = individual_state_key(spool)
        filament_key = str(prepared["filament"]["id"])
        local_state = {filament_key: dict(state.get(key, {}))}
        class SpoolWriter:
            def update_filament_extras(self, filament_id, values):
                client.update_spool_extras(int(spool["id"]), values)
        updated += synchronize_filament_settings(
            [prepared], profiles, SpoolWriter(), sync_state=local_state, **kwargs)
        state[key] = local_state.get(filament_key, {})
        # Only the private in-memory effective copy is used for profile generation.
        # The server's shared Filament and its fields remain untouched.
        spool["filament"] = prepared["filament"]
        spool["extra"] = dict(spool.get("extra") or {})
        spool["extra"].update({key: value for key, value in prepared["filament"]["extra"].items()
                               if key.startswith(ORCA_FIELD_PREFIX)})
    return updated


def synchronize_filament_settings(
    spools: list[dict[str, Any]],
    profiles: OrcaProfiles,
    client: SpoolmanClient,
    reset: bool = False,
    selected_settings=ORCA_SETTINGS,
    live_preset_values: dict[str, dict[str, Any]] | None = None,
    sync_state: dict[str, dict[str, str]] | None = None,
    change_directions: dict[str, set[int]] | None = None,
    conflict_messages: list[str] | None = None,
) -> int:
    """Reconcile advanced fields using the last successful value as baseline."""
    sync_state = sync_state if isinstance(sync_state, dict) else {}
    if change_directions is not None:
        change_directions.setdefault("orca_to_spoolman", set())
        change_directions.setdefault("spoolman_to_orca", set())
    grouped: dict[int, list[dict[str, Any]]] = {}
    for spool in spools:
        filament = spool.get("filament") or {}
        if filament.get("id") is not None:
            grouped.setdefault(int(filament["id"]), []).append(spool)

    live_preset_values = live_preset_values or {}
    updated = 0
    for filament_id, filament_spools in grouped.items():
        filament = (filament_spools[0].get("filament") or {})
        vendor = str((filament.get("vendor") or {}).get("name") or "Generic").strip()
        material = filament_material(filament)
        resolved_profiles: list[tuple[int, dict[str, Any], dict[str, Any]]] = []
        profile_copies = []
        for spool in filament_spools:
            copies = profiles.presets_for_spool(int(spool["id"])) if isinstance(profiles, OrcaProfiles) else []
            for local in copies or [profiles.preset_for_spool(int(spool["id"]))]:
                profile_copies.append((spool, local))
        for spool, local in profile_copies:
            spool_id = int(spool["id"])
            effective = local
            if not effective:
                parent = profiles.parent_for(vendor, material)
                effective = profiles.system_presets.get(
                    parent, {"inherits": parent}
                )
                local = {}
            effective = profiles.effective_preset(effective)
            # Parent snapshots supply defaults only. They must never mask an
            # explicit value saved in this physical spool's profile.
            for parent_name in (profiles.parent_for(vendor, material),
                                str(effective.get("inherits") or "")):
                for key, value in live_preset_values.get(parent_name, {}).items():
                    if key not in ORCA_DEPENDENCY_KEYS:
                        effective.setdefault(key, value)
            # Only the matching spool profile may override its effective values.
            for key, value in live_preset_values.get(str(local.get("name") or ""), {}).items():
                if key not in ORCA_DEPENDENCY_KEYS:
                    previous = sync_state.get(str(filament_id), {}).get(key)
                    if (previous is not None and key in local
                            and encode_spoolman_setting_value(key, local[key]) != previous
                            and encode_spoolman_setting_value(key, value) == previous):
                        continue  # An unchanged live cache must not mask a saved edit.
                    effective[key] = value
            resolved_profiles.append((spool_id, local, effective))

        extras = dict(filament.get("extra") or {})
        patch_values: dict[str, str] = {}
        conflicted_settings: set[str] = set()
        filament_state = dict(sync_state.get(str(filament_id), {}))
        for stale_setting in set(filament_state) - set(selected_settings):
            filament_state.pop(stale_setting, None)
        for setting in selected_settings:
            key = orca_extra_key(setting)
            current = decode_extra_value(extras.get(key))
            current_encoded = encode_spoolman_setting_value(setting, current)
            baseline = filament_state.get(setting)
            candidates: dict[int, str] = {}
            copy_values: dict[int, set[str]] = {}
            for spool_id, local, effective in resolved_profiles:
                if not local and current_encoded is not None and baseline is not None and not reset:
                    continue  # Missing profiles/defaults are not an explicit Orca edit.
                if setting in ORCA_DEPENDENCY_KEYS and setting not in local:
                    continue
                if setting not in effective:
                    continue
                encoded = encode_spoolman_setting_value(
                    setting, effective[setting]
                )
                if encoded is not None:
                    candidates[spool_id] = encoded
                    copy_values.setdefault(spool_id, set()).add(encoded)
            copy_conflict = False
            for spool_id, values in copy_values.items():
                changed = values - {baseline}
                if len(values) > 1:
                    if baseline is not None and len(changed) == 1:
                        candidates[spool_id] = next(iter(changed))
                        if change_directions is not None:
                            change_directions["spoolman_to_orca"].add(spool_id)
                    else:
                        copy_conflict = True
            if not candidates:
                if current_encoded is not None:
                    filament_state[setting] = current_encoded
                continue

            returning_individual = any(individual_state_key(spool) in sync_state for spool in filament_spools)
            if returning_individual:
                baseline = None  # Require agreement before rejoining independently tuned siblings.
            unique_values = set(candidates.values())
            changed_values: dict[str, set[int]] = {}
            if baseline is not None:
                for spool_id, value in candidates.items():
                    if value != baseline:
                        changed_values.setdefault(value, set()).add(spool_id)

            if copy_conflict or (baseline is None and len(unique_values) > 1) or (
                baseline is not None and len(changed_values) > 1
            ):
                conflicted_settings.add(setting)
                involved = ", ".join(
                    f"#{spool_id}" for spool_id in sorted(candidates)
                )
                message = (
                    f"Shared Filament #{filament_id}: conflicting Orca edits "
                    f"for {setting.replace('_', ' ')} across spool profiles "
                    f"{involved}. No value was synchronized for this field."
                )
                if conflict_messages is not None and message not in conflict_messages:
                    conflict_messages.append(message)
                log(f"[FILAMENT SETTING CONFLICT] {message}")
                continue

            all_spool_ids = {int(spool["id"]) for spool in filament_spools}
            if baseline is None:
                agreed = next(iter(unique_values))
                source_ids = {
                    spool_id for spool_id, value in candidates.items()
                    if value == agreed
                }
                if current_encoded != agreed and change_directions is not None:
                    change_directions["orca_to_spoolman"].update(source_ids)
            elif changed_values:
                agreed, source_ids = next(iter(changed_values.items()))
                if change_directions is not None:
                    change_directions["orca_to_spoolman"].update(source_ids)
                    change_directions["spoolman_to_orca"].update(
                        all_spool_ids - source_ids
                    )
            elif reset:
                agreed = next(iter(unique_values))
                if current_encoded != agreed and change_directions is not None:
                    change_directions["orca_to_spoolman"].update(all_spool_ids)
            elif current_encoded is not None and current_encoded != baseline:
                agreed = current_encoded
                if change_directions is not None:
                    change_directions["spoolman_to_orca"].update(all_spool_ids)
            else:
                agreed = baseline

            if current_encoded != agreed or (
                setting in ORCA_LIST_TEXT_SETTINGS
                and malformed_empty_orca_text_list(extras.get(key))
            ):
                patch_values[key] = agreed
            extras[key] = agreed
            filament_state[setting] = agreed
        if patch_values:
            client.update_filament_extras(filament_id, patch_values)
            updated += 1
        if filament_state:
            sync_state[str(filament_id)] = filament_state
        else:
            sync_state.pop(str(filament_id), None)
        if not conflicted_settings:
            for spool in filament_spools:
                sync_state.pop(individual_state_key(spool), None)
        for spool in filament_spools:
            spool_filament = spool.get("filament") or {}
            spool_filament["extra"] = dict(extras)
            spool_filament["_pipspool_advanced_values_reconciled"] = True
            spool_filament["_pipspool_advanced_conflicts"] = sorted(
                conflicted_settings
            )
    return updated


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def write_json_atomic(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def add_report_change(report: SyncReport, message: str) -> None:
    """Add a user-facing change once, even when Orca has several user folders."""
    if message not in report.changes:
        report.changes.append(message)


def changed_profile_fields(existing: dict[str, Any], desired: dict[str, Any]) -> str:
    """Describe meaningful preset changes in short, human-readable terms."""
    changed = {
        key
        for key in set(existing) | set(desired)
        if existing.get(key) != desired.get(key)
    }
    labels: list[str] = []
    groups = (
        ("profile base", {"inherits"}),
        ("name", {"name", "filament_settings_id"}),
        ("material", {"filament_type"}),
        ("manufacturer", {"filament_vendor"}),
        ("colour", {"default_filament_colour"}),
        ("start G-code", {"filament_start_gcode"}),
        (
            "nozzle temperature",
            {"nozzle_temperature", "nozzle_temperature_initial_layer"},
        ),
        (
            "bed temperature",
            {
                key
                for key in changed
                if key.endswith("_plate_temp")
                or key.endswith("_plate_temp_initial_layer")
            },
        ),
        ("cost", {"filament_cost"}),
        ("maximum volumetric speed", {"filament_max_volumetric_speed"}),
    )
    described: set[str] = {"version", "from"}
    for label, keys in groups:
        matching = changed & keys
        if matching:
            labels.append(label)
            described.update(matching)
    labels.extend(key.replace("_", " ") for key in sorted(changed - described))
    return ", ".join(labels) if labels else "profile data"


def comparable_profile_for_status(profile: dict[str, Any]) -> dict[str, Any]:
    """Exclude Orca-only structure from the Spoolman synchronization status."""
    return {
        key: value
        for key, value in profile.items()
        if key not in PROFILE_STATUS_ORCA_ONLY_KEYS
    }


def sync_profiles(
    spools: list[dict[str, Any]],
    profiles: OrcaProfiles,
    selected_settings=ORCA_SETTINGS,
    change_directions: dict[str, set[int]] | None = None,
    inject_spool_id: bool = True,
    cleanup_archived: bool = True,
) -> SyncReport:
    spools = [spool for spool in spools if not spool_is_archived(spool)]
    report = SyncReport(active_spools=len(spools))
    orca_to_spoolman = (
        change_directions.get("orca_to_spoolman", set())
        if change_directions else set()
    )
    spoolman_to_orca = (
        change_directions.get("spoolman_to_orca", set())
        if change_directions else set()
    )
    active_ids = {int(spool["id"]) for spool in spools if spool.get("id") is not None}
    empty_inventory_warning_added = False

    for directory in profiles.user_filament_directories():
        directory.mkdir(parents=True, exist_ok=True)
        files_by_id: dict[int, list[Path]] = {}
        for path in directory.glob("*.json"):
            spool_id = managed_spool_id_from_name(path.name)
            if spool_id is not None and path.name.endswith((PROFILE_SUFFIX, " - Spoolman.json")):
                files_by_id.setdefault(spool_id, []).append(path)

        for spool in spools:
            try:
                spool_id = int(spool["id"])
                candidates = sorted(files_by_id.get(spool_id, []))
                source = candidates[0] if candidates else None
                existing = read_json(source) if source else {}
                if source is not None and (not existing or managed_spool_id_from_name(str(existing.get("name", "")) + ".json") != spool_id):
                    raise ValueError(f"Unreadable existing profile: {source.name}; file preserved")
                display_name, data = desired_preset(
                    spool, existing, profiles, selected_settings, inject_spool_id
                )
                target = directory / f"{safe_filename(display_name)}.json"
                if target.exists() and (target not in candidates or managed_spool_id_from_name(str(read_json(target).get("name", "")) + ".json") != spool_id):
                    raise ValueError(f"Profile name collision: {target.name}; existing file preserved")

                if source is None:
                    write_json_atomic(target, data)
                    report.created += 1
                    report.restart_required = True
                    add_report_change(
                        report, f"Spool #{spool_id}: created {display_name}."
                    )
                elif source != target:
                    write_json_atomic(target, data)
                    for old_path in candidates:
                        if old_path != target and old_path.exists():
                            old_path.unlink()
                    report.renamed += 1
                    report.restart_required = True
                    add_report_change(
                        report, f"Spool #{spool_id}: renamed to {display_name}."
                    )
                elif existing != data:
                    changed_keys = {
                        key for key in set(existing) | set(data)
                        if existing.get(key) != data.get(key)
                    }
                    changed_fields = changed_profile_fields(existing, data)
                    write_json_atomic(target, data)
                    for duplicate in candidates[1:]:
                        if duplicate.exists():
                            duplicate.unlink()
                    report.updated += 1
                    # An Orca edit exported to Spoolman may also normalize the
                    # preset JSON on disk. Orca already has that live value, so
                    # it must not produce a restart notice. Imports from
                    # Spoolman and all ordinary profile changes still do.
                    exported_from_live_orca = (
                        spool_id in orca_to_spoolman
                        and spool_id not in spoolman_to_orca
                    )
                    if not exported_from_live_orca:
                        report.restart_required = True
                    add_report_change(
                        report, f"Spool #{spool_id}: updated {changed_fields}."
                    )
                else:
                    report.unchanged += 1
            except Exception as exc:
                report.errors.append(f"Spool {spool.get('id', '?')}: {exc}")

        for spool_id, paths in files_by_id.items():
            if not cleanup_archived or spool_id in active_ids:
                continue
            if not active_ids:
                if not empty_inventory_warning_added:
                    report.errors.append(
                        "Profile cleanup skipped because Spoolman returned zero active "
                        "spools. Existing PipSpool profiles were preserved."
                    )
                    empty_inventory_warning_added = True
                continue
            for path in paths:
                try:
                    path.unlink()
                    report.removed += 1
                    report.restart_required = True
                    add_report_change(
                        report, f"Spool #{spool_id}: removed archived profile."
                    )
                except OSError as exc:
                    report.errors.append(f"Remove {path.name}: {exc}")

    return report


LEGACY_PLUGIN_REFS = {
    "spoolman_bridge;;Filament Usage Updater",
    "Spoolman Bridge;3ad590dc-6698-4327-9005-12b977229ed2;Filament Usage Updater",
}


def remove_legacy_pipeline_artifacts(profiles: OrcaProfiles) -> tuple[int, int]:
    removed_processes = 0
    cleaned_presets = 0
    if not profiles.user_root.is_dir():
        return removed_processes, cleaned_presets

    for path in profiles.user_root.rglob("*.json"):
        if path.parent.name == "process" and path.name.endswith(" - SpoolMan.json"):
            path.unlink()
            removed_processes += 1
            continue

        data = read_json(path)
        changed = False
        refs = data.get("plugins")
        if isinstance(refs, list):
            filtered = [ref for ref in refs if ref not in LEGACY_PLUGIN_REFS]
            if filtered != refs:
                changed = True
                if filtered:
                    data["plugins"] = filtered
                else:
                    data.pop("plugins", None)
        elif refs in LEGACY_PLUGIN_REFS:
            data.pop("plugins", None)
            changed = True

        pipeline = data.get("slicing_pipeline_plugin")
        if isinstance(pipeline, list):
            filtered = [name for name in pipeline if name != "Filament Usage Updater"]
            if filtered != pipeline:
                changed = True
                if filtered:
                    data["slicing_pipeline_plugin"] = filtered
                else:
                    data.pop("slicing_pipeline_plugin", None)
        elif pipeline == "Filament Usage Updater":
            data.pop("slicing_pipeline_plugin", None)
            changed = True

        if changed:
            write_json_atomic(path, data)
            cleaned_presets += 1

    return removed_processes, cleaned_presets


def orca_profiles() -> OrcaProfiles:
    root = support_directory()
    if root is None:
        raise RuntimeError("OrcaSlicer profile directory could not be found")
    return OrcaProfiles(root)


def show_message(message: str, title: str = "PipSpool", icon: str = "info") -> None:
    orca.host.ui.message(message, title=title, icon=icon)


def orca_runtime_description() -> str:
    """Describe Orca when its 2.5 host-info API is available."""
    try:
        app_info = getattr(orca.host, "app_info", None)
        info = app_info() if callable(app_info) else None
        if not isinstance(info, dict):
            return ""
        version = str(info.get("version") or "").strip()
        build = str(info.get("build") or "").strip()
        if version and build and build not in version:
            return f"{version} ({build})"
        return version or build
    except Exception as exc:
        # app_info() is absent on older supported Orca builds and may only be
        # called from Orca's UI thread. Compatibility must not depend on it.
        log(f"[ORCA RUNTIME INFO] {exc}")
        return ""


def begin_manual_use() -> None:
    global _MANUAL_USE_STARTED
    _MANUAL_USE_STARTED = True


def pause_background_updates() -> None:
    global _MANUAL_USE_STARTED
    _MANUAL_USE_STARTED = False


def start_background_thread(thread: threading.Thread, operation: str) -> bool:
    """Start work through Orca 2.5's audited thread-permission boundary."""
    begin_manual_use()
    try:
        thread.start()
        return True
    except PermissionError as exc:
        # Orca 2.5 Alpha denies the current start when a permission prompt was
        # queued from a non-UI lifecycle callback. If the user approves it, a
        # later attempt succeeds. Keep the denied attempt recoverable and never
        # try to bypass or pre-seed Orca's permission store.
        pause_background_updates()
        log(f"[THREAD PERMISSION] {operation}: {exc}")
        return False


LIFECYCLE_DEBOUNCE_SECONDS = 1.0
LIFECYCLE_SUPPORTED = getattr(orca, "LifecycleEvent", None) is not None


def lifecycle_event_name(event: Any) -> str:
    """Return a stable event name without importing nightly-only enum members."""
    name = getattr(event, "name", None)
    if name:
        return str(name)
    text = str(event or "")
    if "." in text:
        text = text.rsplit(".", 1)[-1]
    return text.strip(" <>:'\"")


def lifecycle_context_text(context: Any, attribute: str) -> str:
    value = getattr(context, attribute, "")
    return str(value or "").strip()


def host_has_filament_preset(name: str) -> bool:
    """Resolve PresetSaved's missing type from Orca after the callback returns."""
    if not name:
        return False
    try:
        collection = orca.host.preset_bundle().filaments
        return collection.find_preset(name) is not None
    except Exception as exc:
        log(f"[LIFECYCLE PRESET LOOKUP] {exc}")
        return False


class LifecycleCoordinator:
    """Debounce Orca events and refresh PipSpool outside their callbacks."""

    REFRESH_EVENTS = {
        "NewProject",
        "ProjectOpened",
        "DeviceSelected",
        "SlicingJobComplete",
        "UploadFinished",
        "PrintJobFinished",
    }

    def __init__(self):
        self._lock = threading.Lock()
        self._timer: threading.Timer | None = None
        self._page = None
        self._pending_sync_reason = ""
        self._pending_saved_preset = ""
        self._last_event = ""
        self._last_subject = ""
        self._last_source = ""
        self._active_filament = ""
        self._active_printer = ""

    def register_page(self, page: Any) -> None:
        with self._lock:
            self._page = page

    def unregister_page(self, page: Any) -> None:
        with self._lock:
            if self._page is page:
                self._page = None

    def shutdown(self) -> None:
        with self._lock:
            timer, self._timer = self._timer, None
            self._page = None
            self._pending_sync_reason = ""
            self._pending_saved_preset = ""
        if timer is not None:
            timer.cancel()

    def handle(self, event: Any, context: Any) -> None:
        """Record only cheap context data, then debounce all real work."""
        event_name = lifecycle_event_name(event)
        subject = lifecycle_context_text(context, "name")
        source = lifecycle_context_text(context, "msg").casefold()

        if event_name == "PresetSaved":
            # Orca currently sends "new" or "overwrite" in ctx.msg for this
            # event, not the preset type. A future payload may include the
            # type, so reject only an explicit, known non-filament type here.
            if source in {"print", "sla_print", "sla_material", "printer"}:
                return
            reason = ""
        elif event_name == "PresetSelected":
            if source not in {"filament", "printer"}:
                return
            reason = ""
        elif event_name in self.REFRESH_EVENTS:
            reason = ""
        else:
            return

        with self._lock:
            self._last_event = event_name
            self._last_subject = subject
            self._last_source = source
            if event_name == "PresetSelected" and source == "filament":
                self._active_filament = subject
            elif event_name == "PresetSelected" and source == "printer":
                self._active_printer = subject
            if event_name == "PresetSaved":
                self._pending_saved_preset = subject
            if reason:
                self._pending_sync_reason = reason
            if self._timer is not None:
                self._timer.cancel()
            if not _MANUAL_USE_STARTED:
                return  # Remember startup events without spawning a thread/dialog.
            timer = threading.Timer(LIFECYCLE_DEBOUNCE_SECONDS, self._dispatch)
            timer.daemon = True
            self._timer = timer
            if not start_background_thread(timer, "lifecycle refresh"):
                # The permission prompt is already queued by Orca. Skip this
                # one refresh instead of leaking PermissionError through the
                # lifecycle trampoline; the next event will retry normally.
                self._timer = None

    def _dispatch(self) -> None:
        with self._lock:
            self._timer = None
            page = self._page
            saved_preset = self._pending_saved_preset
            self._pending_saved_preset = ""
        if saved_preset:
            if not host_has_filament_preset(saved_preset):
                return
            with self._lock:
                self._pending_sync_reason = (
                    f"Orca filament preset saved: {saved_preset}"
                )
        if page is None:
            return
        try:
            page._refresh_from_lifecycle()
        except Exception as exc:
            log(f"[LIFECYCLE REFRESH ERROR] {exc}")

    def consume_sync_reason(self, synchronization_required: bool) -> str:
        with self._lock:
            reason = self._pending_sync_reason
            self._pending_sync_reason = ""
        return reason if synchronization_required else ""

    def diagnostics(self) -> dict[str, Any]:
        with self._lock:
            return {
                "supported": LIFECYCLE_SUPPORTED,
                "mode": "events" if LIFECYCLE_SUPPORTED else "compatibility",
                "last_event": self._last_event,
                "last_subject": self._last_subject,
                "last_source": self._last_source,
                "active_filament": self._active_filament,
                "active_printer": self._active_printer,
            }


LIFECYCLE_COORDINATOR = LifecycleCoordinator()


def parse_field_config(value: Any) -> tuple[tuple[str, ...], bool]:
    try:
        config = json.loads(value) if isinstance(value, str) else value
    except (TypeError, ValueError):
        config = {}
    if not isinstance(config, dict):
        config = {}
    requested = config.get("selected_fields", [])
    if not isinstance(requested, list):
        requested = []
    selected = tuple(setting for setting in ORCA_SETTINGS if setting in requested)
    return selected, bool(config.get("remove_unselected_fields", False))


def field_config_html() -> str:
    groups = []
    for group, settings in ORCA_SETTING_GROUPS.items():
        options = "".join(
            f'<label><input type="checkbox" value="{escape(setting)}">'
            f'<span>{escape(setting.replace("_", " ").title())}</span></label>'
            for setting in settings
        )
        groups.append(
            f'<section><div class="group"><h2>{escape(group)}</h2>'
            f'<button onclick="setGroup(this,true)">All</button>'
            f'<button onclick="setGroup(this,false)">None</button></div>'
            f'<div class="fields">{options}</div></section>'
        )
    return f"""<!doctype html><html><head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
body{{margin:0;padding:18px;background:#25262a;color:#f4f4f4;font:14px system-ui,sans-serif}}
.intro{{color:#c9cbd0;line-height:1.45;margin:0 0 14px}}section{{border-top:1px solid #444;padding:12px 0}}
.group{{display:flex;align-items:center;gap:7px}}h2{{font-size:15px;margin:0 auto 0 0}}
button{{border:1px solid #62656b;border-radius:5px;background:#36383d;color:#eee;padding:4px 10px}}
.fields{{display:grid;grid-template-columns:repeat(auto-fit,minmax(245px,1fr));gap:7px 16px;margin-top:10px}}
label{{display:flex;align-items:center;gap:8px;min-height:24px}}input{{accent-color:#00a99d}}
.danger{{margin-top:14px;padding:11px;border:1px solid #80534c;border-radius:6px;background:#3b2b29}}
.actions{{position:sticky;bottom:0;display:flex;justify-content:flex-end;padding-top:15px;background:#25262a}}
.save{{background:#008c82;border-color:#00b7aa;padding:7px 18px}}
</style></head><body>
<p class="intro">Choose the Orca filament settings PipSpool may copy to Spoolman. No advanced fields are selected by default. Spool identity, material, colour, temperature, price and spool-ID G-code continue to work normally.</p>
{''.join(groups)}
<label class="danger"><input id="remove" type="checkbox"><span><b>Remove unselected PipSpool fields from Spoolman</b><br>This deletes their saved values for every filament the next time Sync Spoolman Profiles runs.</span></label>
<div class="actions"><button class="save" onclick="save()">Save selection</button></div>
<script>
function setGroup(button,state){{button.closest('section').querySelectorAll('input').forEach(x=>x.checked=state)}}
async function load(){{
 let value=await window.orca.getConfig();
 try{{if(typeof value==='string')value=JSON.parse(value)}}catch(e){{value={{}}}}
 value=value||{{}}; const selected=new Set(value.selected_fields||[]);
 document.querySelectorAll('.fields input').forEach(x=>x.checked=selected.has(x.value));
 document.getElementById('remove').checked=!!value.remove_unselected_fields;
}}
async function save(){{
 const selected=[...document.querySelectorAll('.fields input:checked')].map(x=>x.value);
 await window.orca.saveConfig(JSON.stringify({{selected_fields:selected,remove_unselected_fields:document.getElementById('remove').checked}}));
}}
load();
</script></body></html>"""


def synchronization_scope(spools, spool_id, selected_settings, shared=True):
    """Include siblings when reconciling shared fields; never treat a subset as inventory."""
    if spool_id is None:
        return spools
    if isinstance(spool_id, bool) or not isinstance(spool_id, int) or spool_id <= 0:
        raise ValueError("Spool ID must be a positive integer")
    active = [spool for spool in spools if not spool_is_archived(spool)]
    selected = next((spool for spool in active if int(spool["id"]) == spool_id), None)
    if selected is None:
        raise ValueError(f"Spool #{spool_id} is no longer active. Refresh the dashboard.")
    filament_id = (selected.get("filament") or {}).get("id")
    if not shared or not selected_settings or filament_id is None:
        return [selected]
    return [spool for spool in active
            if str((spool.get("filament") or {}).get("id")) == str(filament_id)]


def sync_with_spoolman(
    selected_settings: tuple[str, ...], remove_unselected: bool = False,
    live_preset_values: dict[str, dict[str, Any]] | None = None,
    spool_id: int | None = None,
) -> tuple[SyncReport, list[dict[str, Any]]]:
    if live_preset_values is None:
        live_preset_values = host_filament_preset_snapshot(selected_settings)
    settings = load_settings()
    sync_state = settings.get("advanced_sync_state")
    if not isinstance(sync_state, dict):
        sync_state = {}
    client = SpoolmanClient(settings["spoolman_url"])
    spools = client.active_spools()
    scoped_spools = synchronization_scope(spools, spool_id, selected_settings, shared=shared_filament_settings(settings))
    if remove_unselected and not shared_filament_settings(settings):
        raise ValueError("Shared field cleanup is unavailable in individual mode; saved fields are preserved")
    if spool_id is not None and remove_unselected:
        raise ValueError("Field cleanup requires full synchronization")
    save_settings({"selected_fields": list(selected_settings)})
    field_warning = None
    try:
        client.ensure_start_gcode_field()
        ensure_advanced_fields(client, selected_settings, settings)
        if remove_unselected:
            client.remove_unselected_orca_filament_fields(selected_settings)
    except PermissionError:
        # Approval can arrive after this worker has already been refused.
        # A deliberate later retry starts from fresh inventory and sync state.
        raise
    except Exception as exc:
        field_warning = f"Spoolman field setup: {exc}"
        log(f"[FIELD SETUP WARNING] {exc}")
    profiles = orca_profiles()
    change_directions: dict[str, set[int]] = {}
    setting_conflicts: list[str] = []
    try:
        reconcile_advanced_settings(
            scoped_spools, profiles, client, settings, selected_settings=selected_settings,
            live_preset_values=live_preset_values,
            sync_state=sync_state,
            change_directions=change_directions,
            conflict_messages=setting_conflicts,
        )
    except PermissionError:
        # Never write profiles from a partially reconciled shared Filament group.
        raise
    except Exception as exc:
        if spool_id is not None:
            raise RuntimeError(f"Shared-Filament checks failed; profiles were preserved: {exc}") from exc
        raise RuntimeError(f"Advanced setting reconciliation failed; profiles were preserved: {exc}") from exc
    report = sync_profiles(
        scoped_spools, profiles, selected_settings,
        change_directions=change_directions,
        inject_spool_id=spool_id_gcode_enabled(settings),
        cleanup_archived=spool_id is None,
    )
    if spool_id is not None:
        ids = ", ".join(f"#{int(spool['id'])}" for spool in scoped_spools)
        add_report_change(report, f"Selected spool #{spool_id}; profiles checked: {ids}.")
        add_report_change(report, ("Shared advanced fields were checked across the related Filament group." if shared_filament_settings(settings) else "Individual advanced settings were checked for this spool only.") + " Unrelated spools and archived profiles were left unchanged; use Synchronize now for inventory cleanup.")
    if field_warning:
        report.errors.insert(0, field_warning)
    if setting_conflicts:
        report.errors[0:0] = setting_conflicts
    report_data = {
        "active_spools": report.active_spools,
        "created": report.created,
        "updated": report.updated,
        "renamed": report.renamed,
        "removed": report.removed,
        "unchanged": report.unchanged,
        "changes": list(report.changes),
        "changed_spools": report.changed_spools,
        "errors": list(report.errors),
        "changed": report.changed,
        "restart_required": report.restart_required,
    }
    saved_state = {
        "last_sync_report": report_data,
        "advanced_sync_state": sync_state,
    }
    if report.restart_required:
        saved_state.update({
            "restart_required": True,
            "restart_required_process_id": os.getpid(),
        })
    save_settings(saved_state)
    log(f"[SYNC] {report.summary().replace(chr(10), '; ')}")
    return report, spools


def save_advanced_field_selection(
    selected_settings: tuple[str, ...],
    live_preset_values: dict[str, dict[str, Any]] | None = None,
) -> tuple[int, int]:
    """Save enabled fields and establish their two-way synchronization state."""
    save_settings({"selected_fields": list(selected_settings)})
    settings = load_settings()
    sync_state = settings.get("advanced_sync_state")
    if not isinstance(sync_state, dict):
        sync_state = {}
    client = SpoolmanClient(settings["spoolman_url"])
    created = ensure_advanced_fields(client, selected_settings, settings)
    spools = client.active_spools()
    populated = reconcile_advanced_settings(
        spools,
        orca_profiles(),
        client, settings,
        selected_settings=selected_settings,
        live_preset_values=live_preset_values,
        sync_state=sync_state,
    )
    save_settings({"advanced_sync_state": sync_state})
    return created, populated


class SyncCapability(orca.script.ScriptPluginCapabilityBase):
    def get_name(self):
        return "Sync Spoolman Profiles"

    def on_load(self):
        mode = "enabled" if LIFECYCLE_SUPPORTED else "compatibility fallback"
        runtime = orca_runtime_description()
        runtime_detail = f"; runtime {runtime}" if runtime else ""
        log(
            f"[LIFECYCLE] Orca lifecycle integration {mode}; "
            f"API baseline {ORCA_PLUGIN_API_BASELINE}{runtime_detail}"
        )

    def on_unload(self):
        LIFECYCLE_COORDINATOR.shutdown()

    def on_lifecycle_event(self, event, context):
        # This callback may run on an Orca worker thread. The coordinator only
        # copies its small payload here and performs refresh work after debounce.
        LIFECYCLE_COORDINATOR.handle(event, context)

    def has_config_ui(self):
        return True

    def get_config_ui(self):
        return field_config_html()

    def get_default_config(self):
        return {"selected_fields": [], "remove_unselected_fields": False}

    def get_config_version(self):
        return FIELD_CONFIG_VERSION

    def execute(self):
        try:
            selected_settings, remove_unselected = parse_field_config(self.get_config())
        except Exception as exc:
            log(f"[FIELD CONFIG WARNING] {exc}")
            selected_settings, remove_unselected = (), False
        cached_fields = load_settings().get("selected_fields", [])
        if not selected_settings and isinstance(cached_fields, list):
            selected_settings = tuple(
                setting for setting in ORCA_SETTINGS if setting in cached_fields
            )
        live_preset_values = host_filament_preset_snapshot(selected_settings)

        def work():
            try:
                report, _spools = sync_with_spoolman(
                    selected_settings, remove_unselected, live_preset_values
                )
                suffix = "\n\nRestart OrcaSlicer to load changed presets." if report.restart_required else ""
                show_message(report.summary() + suffix, icon="warning" if report.errors else "info")
            except Exception as exc:
                log(f"[SYNC ERROR] {exc}")
                show_message(f"Synchronization failed:\n{exc}", icon="error")

        if not start_background_thread(
            threading.Thread(target=work, daemon=True),
            "Spoolman synchronization",
        ):
            return orca.ExecutionResult.failure(
                orca.PluginResult.RecoverableError,
                THREAD_PERMISSION_RETRY_MESSAGE,
            )
        return orca.ExecutionResult.success("PipSpool synchronization started")


class ResetFilamentSettingsCapability(orca.script.ScriptPluginCapabilityBase):
    def get_name(self):
        return "Reset Spoolman Filament Settings from Orca"

    def execute(self):
        settings = load_settings()
        selected_settings = tuple(
            setting for setting in ORCA_SETTINGS
            if setting in settings.get("selected_fields", [])
        )
        live_preset_values = host_filament_preset_snapshot(selected_settings)
        sync_state = settings.get("advanced_sync_state")
        if not isinstance(sync_state, dict):
            sync_state = {}

        def work():
            try:
                client = SpoolmanClient(settings["spoolman_url"])
                ensure_advanced_fields(client, selected_settings, settings)
                spools = client.active_spools()
                profiles = orca_profiles()
                setting_conflicts: list[str] = []
                updated = reconcile_advanced_settings(
                    spools, profiles, client, settings, reset=True,
                    selected_settings=selected_settings,
                    live_preset_values=live_preset_values,
                    sync_state=sync_state,
                    conflict_messages=setting_conflicts,
                )
                save_settings({"advanced_sync_state": sync_state})
                report = sync_profiles(spools, profiles, selected_settings)
                if setting_conflicts:
                    report.errors[0:0] = setting_conflicts
                show_message(
                    f"Reset {updated} Spoolman advanced-setting record(s) from Orca.\n\n"
                    + report.summary()
                )
            except Exception as exc:
                log(f"[FILAMENT RESET ERROR] {exc}")
                show_message(f"Filament setting reset failed:\n{exc}", icon="error")

        if not start_background_thread(
            threading.Thread(target=work, daemon=True),
            "filament setting reset",
        ):
            return orca.ExecutionResult.failure(
                orca.PluginResult.RecoverableError,
                THREAD_PERMISSION_RETRY_MESSAGE,
            )
        return orca.ExecutionResult.success("PipSpool filament setting reset started")


class LegacyCleanupCapability(orca.script.ScriptPluginCapabilityBase):
    def get_name(self):
        return "Remove Legacy Double Profiles"

    def execute(self):
        try:
            removed, cleaned = remove_legacy_pipeline_artifacts(orca_profiles())
            message = (
                f"Removed {removed} legacy process profile(s).\n"
                f"Cleaned {cleaned} legacy preset reference(s).\n\n"
                "Synced PipSpool filament presets were preserved. Restart OrcaSlicer."
            )
            show_message(message)
            return orca.ExecutionResult.success(message)
        except Exception as exc:
            return orca.ExecutionResult.failure(
                orca.PluginResult.RecoverableError,
                f"Legacy cleanup failed: {exc}",
            )


def profile_sync_statuses(
    spools: list[dict[str, Any]],
    profiles: OrcaProfiles,
    selected_settings=ORCA_SETTINGS,
    sync_state: dict[str, dict[str, str]] | None = None,
    inject_spool_id: bool = True,
    shared=True,
) -> dict[int, dict[str, str]]:
    """Compare active spools with disk without claiming Orca's live UI state."""
    if not shared:
        result = {}
        for spool in spools:
            if (spool.get("filament") or {}).get("id") is None:
                continue
            prepared = individual_settings_spool(spool)
            local_state = {str(prepared["filament"]["id"]): (sync_state or {}).get(individual_state_key(spool), {})}
            result.update(profile_sync_statuses([prepared], profiles, selected_settings,
                sync_state=local_state, inject_spool_id=inject_spool_id))
        return result
    directories = profiles.user_filament_directories()
    if not directories:
        return {
            int(spool["id"]): {
                "status": "error",
                "warning": (
                    "PipSpool could not find an Orca user filament directory. "
                    "Check the PipSpool log for details."
                ),
            }
            for spool in spools if spool.get("id") is not None
        }

    indexed: list[dict[int, list[Path]]] = []
    for directory in directories:
        files_by_id: dict[int, list[Path]] = {}
        if directory.is_dir():
            for path in directory.glob("*.json"):
                spool_id = managed_spool_id_from_name(path.name)
                if spool_id is not None and path.name.endswith(
                    (PROFILE_SUFFIX, " - Spoolman.json")
                ):
                    files_by_id.setdefault(spool_id, []).append(path)
        indexed.append(files_by_id)

    read_cache = {}
    def cached_profile(path):
        if path not in read_cache:
            try:
                value = json.loads(path.read_text(encoding="utf-8"))
                if not isinstance(value, dict):
                    raise ValueError("profile root is not an object")
                read_cache[path] = value
            except (OSError, ValueError, TypeError) as exc:
                read_cache[path] = exc
        value = read_cache[path]
        if isinstance(value, Exception):
            raise value
        return value

    def indexed_preset(spool_id):
        # Match preset_for_spool's first-copy display behavior without scanning
        # every account directory again for every selected field.
        for files_by_id in indexed:
            for path in files_by_id.get(spool_id, []):
                try:
                    local = cached_profile(path)
                    if managed_spool_id_from_name(str(local.get("name", "")) + ".json") == spool_id:
                        return local
                except (OSError, ValueError, TypeError):
                    return {}
        return {}

    sync_state = sync_state if isinstance(sync_state, dict) else {}
    conflict_settings: dict[int, set[str]] = {}
    grouped: dict[int, list[dict[str, Any]]] = {}
    for spool in spools:
        filament = spool.get("filament") or {}
        if filament.get("id") is not None:
            grouped.setdefault(int(filament["id"]), []).append(spool)
    for filament_id, filament_spools in grouped.items():
        baseline = sync_state.get(str(filament_id), {})
        for setting in selected_settings:
            candidates: dict[int, str] = {}
            for sibling in filament_spools:
                sibling_id = int(sibling["id"])
                local = indexed_preset(sibling_id)
                if not local:
                    continue
                effective = profiles.effective_preset(local)
                if setting in ORCA_DEPENDENCY_KEYS and setting not in local:
                    continue
                if setting not in effective:
                    continue
                encoded = encode_spoolman_setting_value(
                    setting, effective.get(setting)
                )
                if encoded is not None:
                    candidates[sibling_id] = encoded
            if not candidates:
                continue
            agreed = baseline.get(setting)
            unique_values = set(candidates.values())
            changed_values = {
                value for value in unique_values if agreed is not None and value != agreed
            }
            if (agreed is None and len(unique_values) > 1) or len(changed_values) > 1:
                conflict_settings.setdefault(filament_id, set()).add(setting)

    result: dict[int, dict[str, str]] = {}
    for spool in spools:
        if spool.get("id") is None:
            continue
        spool_id = int(spool["id"])
        missing = False
        update_required = False
        comparison_error = False
        update_reasons: set[str] = set()
        for directory, files_by_id in zip(directories, indexed):
            candidates = sorted(files_by_id.get(spool_id, []))
            if not candidates:
                missing = True
                continue
            source = candidates[0]
            try:
                raw = cached_profile(source)
                if not isinstance(raw, dict):
                    raise ValueError("profile root is not an object")
                filament = spool.get("filament") or {}
                filament_id = int(filament.get("id")) if filament.get("id") is not None else -1
                baseline = sync_state.get(str(filament_id), {})
                conflicts = conflict_settings.get(filament_id, set())
                comparison_spool = spool
                if any(setting in baseline for setting in selected_settings):
                    # A fresh Spoolman fetch does not contain PipSpool's
                    # in-memory reconciliation marker. Restore it from the
                    # persisted baseline before building the desired preset;
                    # otherwise every selected advanced value already written
                    # to Orca is mistaken for a pending removal after restart.
                    comparison_spool = dict(spool)
                    comparison_filament = dict(filament)
                    comparison_filament[
                        "_pipspool_advanced_values_reconciled"
                    ] = True
                    comparison_filament["_pipspool_advanced_conflicts"] = sorted(
                        conflicts
                    )
                    comparison_spool["filament"] = comparison_filament
                display_name, desired = desired_preset(
                    comparison_spool, raw, profiles, selected_settings,
                    inject_spool_id,
                )
                target = directory / f"{safe_filename(display_name)}.json"
                if source != target:
                    update_required = True
                    update_reasons.add("the profile name or filename changed")
                if len(candidates) > 1:
                    update_required = True
                    update_reasons.add("duplicate profile files were found")
                comparable_raw = comparable_profile_for_status(raw)
                comparable_desired = comparable_profile_for_status(desired)
                if comparable_raw != comparable_desired:
                    update_required = True
                    update_reasons.add(
                        "profile fields differ "
                        f"({changed_profile_fields(comparable_raw, comparable_desired)})"
                    )
                extras = filament.get("extra") or {}
                effective = profiles.effective_preset(raw)
                for setting in selected_settings:
                    agreed = baseline.get(setting)
                    if agreed is None or setting not in effective:
                        continue
                    orca_value = encode_spoolman_setting_value(
                        setting, effective.get(setting)
                    )
                    spoolman_value = encode_spoolman_setting_value(
                        setting,
                        decode_extra_value(extras.get(orca_extra_key(setting))),
                    )
                    if (
                        orca_value == agreed
                        and spoolman_value is not None
                        and spoolman_value != agreed
                    ):
                        update_required = True
                        update_reasons.add(
                            f"Spoolman changed {setting.replace('_', ' ')}"
                        )
                        break
            except (OSError, ValueError, TypeError):
                comparison_error = True

        if comparison_error:
            result[spool_id] = {
                "status": "error",
                "warning": (
                    f"PipSpool could not read or compare the Orca profile for "
                    f"spool #{spool_id}. Synchronize again and check the PipSpool "
                    "log if the problem remains."
                ),
            }
        elif missing:
            result[spool_id] = {
                "status": "profile_missing",
                "reason": f"Spool #{spool_id}: Orca profile is missing",
                "warning": (
                    f"The Orca profile for spool #{spool_id} is missing. Select "
                    "Synchronize now, then restart OrcaSlicer."
                ),
            }
        elif update_required:
            reason_text = "; ".join(sorted(update_reasons)) or "profile data differs"
            result[spool_id] = {
                "status": "update_required",
                "reason": f"Spool #{spool_id}: {reason_text}",
                "warning": (
                    f"The Orca profile for spool #{spool_id} needs synchronization: "
                    f"{reason_text}. "
                    "Select Synchronize now, then restart OrcaSlicer."
                ),
            }
        elif conflict_settings.get(
            int((spool.get("filament") or {}).get("id") or -1)
        ):
            conflicts = conflict_settings[
                int((spool.get("filament") or {}).get("id") or -1)
            ]
            fields = ", ".join(
                setting.replace("_", " ") for setting in sorted(conflicts)
            )
            result[spool_id] = {
                "status": "conflict",
                "warning": (
                    f"Orca profiles sharing this Spoolman Filament contain "
                    f"different values for {fields}. PipSpool preserved them; "
                    "make the sibling profiles agree before synchronizing."
                ),
            }
        else:
            result[spool_id] = {"status": "synced", "warning": ""}
    return result


def page_spool_data(
    spool: dict[str, Any], sync_status: dict[str, str] | None = None
) -> dict[str, Any]:
    filament = spool.get("filament") or {}
    vendor = filament.get("vendor") or {}
    remaining = numeric(spool.get("remaining_weight"))
    if remaining is None:
        remaining = numeric(spool.get("initial_weight"))
    initial_weight = numeric(spool.get("initial_weight"))
    if initial_weight is None or initial_weight <= 0:
        initial_weight = numeric(filament.get("weight"))
    remaining_percent = None
    remaining_step = None
    if remaining is not None and initial_weight is not None and initial_weight > 0:
        remaining_percent = max(0.0, min(100.0, remaining / initial_weight * 100.0))
        remaining_step = min(100, int(math.ceil(remaining_percent / 10.0) * 10))
    nozzle_temperature = numeric(filament.get("settings_extruder_temp"))
    bed_temperature = numeric(filament.get("settings_bed_temp"))
    data = {
        "id": spool.get("id"),
        "material": filament_material(filament),
        "name": str(filament.get("name") or "Unnamed filament"),
        "vendor": str(vendor.get("name") or "Generic"),
        "color": f"#{str(filament.get('color_hex') or 'FFFFFF').lstrip('#')}",
        "remaining": None if remaining is None else round(remaining, 1),
        "initial_weight": None if initial_weight is None else round(initial_weight, 1),
        "remaining_percent": None if remaining_percent is None else round(remaining_percent, 1),
        "remaining_step": remaining_step,
        "location": str(spool.get("location") or ""),
        "nozzle_temperature": (
            None if nozzle_temperature is None else round(nozzle_temperature, 1)
        ),
        "bed_temperature": (
            None if bed_temperature is None else round(bed_temperature, 1)
        ),
    }
    assignment = spool_gate_assignment(spool)
    if assignment is None:
        data.update({"loaded": False, "printer": "", "gate": None})
    else:
        printer, gate = assignment
        data.update({"loaded": True, "printer": printer, "gate": gate})
    if sync_status:
        data["sync_status"] = sync_status.get("status", "")
        data["sync_warning"] = sync_status.get("warning", "")
    else:
        data["sync_status"] = ""
        data["sync_warning"] = ""
    return data


def spool_gate_assignment(spool: dict[str, Any]) -> tuple[str, int] | None:
    """Return Spoolman's printer/gate assignment without contacting Moonraker."""
    extras = dict(spool.get("extra") or {})
    printer = str(decode_extra_value(extras.get("printer_name")) or "").strip()
    gate_value = numeric(decode_extra_value(extras.get("mmu_gate_map")))
    if gate_value is None:
        location = str(spool.get("location") or "")
        match = re.match(r"^\s*(.*?)\s*@\s*MMU Gate:\s*(-?\d+)\s*$", location)
        if match:
            printer = printer or match.group(1).strip()
            gate_value = numeric(match.group(2))
    if gate_value is None or gate_value < 0:
        return None
    return printer or "Printer", int(gate_value)


def page_gate_data(
    spool: dict[str, Any], sync_status: dict[str, str] | None = None
) -> dict[str, Any] | None:
    assignment = spool_gate_assignment(spool)
    if assignment is None:
        return None
    printer, gate = assignment
    data = page_spool_data(spool, sync_status)
    data.update({"printer": printer, "gate": gate})
    sync_warning = str(data.get("sync_warning") or "").strip()
    if sync_warning:
        data["warning"] = sync_warning
    return data


def gate_image_data_uri(color: str, gate: int, empty: bool = False) -> str:
    color = str(color or "#FFFFFF")
    if not re.fullmatch(r"#[0-9A-Fa-f]{6}", color):
        color = "#FFFFFF"
    filament_color = "#555b63" if empty else color
    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 72 58">
<path d="M19 10h34l11 10v24l-8 8H16l-8-8V20z" fill="#292d33" stroke="#737983" stroke-width="3" stroke-linejoin="round"/>
<rect x="29" y="3" width="14" height="10" rx="4" fill="#181a1e" stroke="#858b94" stroke-width="2"/>
<path d="M36 5v44" fill="none" stroke="{filament_color}" stroke-width="5" stroke-linecap="round"/>
<path d="M26 25l5-7h10l5 7-3 10-7 4-7-4z" fill="#17191c" stroke="#969ca5" stroke-width="2"/>
<circle cx="36" cy="28" r="11" fill="#17191c" stroke="#969ca5" stroke-width="2"/>
<text x="36" y="33" text-anchor="middle" fill="#f2f3f5" font-family="Segoe UI,Arial,sans-serif" font-size="14" font-weight="700">{int(gate)}</text>
<path d="M30 52h12l-3 5h-6z" fill="#17191c" stroke="#858b94" stroke-width="2" stroke-linejoin="round"/></svg>"""
    encoded = base64.b64encode(svg.encode("utf-8")).decode("ascii")
    return f"data:image/svg+xml;base64,{encoded}"


def page_gate_slots(gates: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, dict[int, list[dict[str, Any]]]] = {}
    for gate in gates:
        grouped.setdefault(gate["printer"], {}).setdefault(gate["gate"], []).append(gate)
    slots = []
    for printer in sorted(grouped, key=str.casefold):
        assigned = grouped[printer]
        highest_gate = max(assigned)
        slot_count = max(8, ((highest_gate // 8) + 1) * 8)
        for gate_number in range(slot_count):
            if gate_number in assigned:
                candidates = sorted(
                    assigned[gate_number], key=lambda item: int(item.get("id") or 0)
                )
                selected = dict(candidates[0])
                if len(candidates) > 1:
                    spool_ids = ", ".join(f"#{candidate.get('id')}" for candidate in candidates)
                    duplicate_warning = (
                        f"Gate {gate_number} on {printer} is assigned to multiple "
                        f"active spools: {spool_ids}. Check the gate assignments in Spoolman."
                    )
                    existing_warning = str(selected.get("warning") or "").strip()
                    selected["warning"] = " ".join(
                        item for item in (existing_warning, duplicate_warning) if item
                    )
                slots.append(selected)
            else:
                slots.append({
                    "printer": printer,
                    "gate": gate_number,
                    "empty": True,
                    "color": "#555B63",
                })
    return slots




def diagnostic_window_html():
    payload = theme_state(include_background=False)
    colors = payload["themes"][payload["selected"]]["colors"]
    variables = ";".join("--" + key.replace("_", "-") + ":" + value for key, value in colors.items())
    return r"""<!doctype html><html><head><meta charset="utf-8"><style>
    :root{VARIABLES}*{box-sizing:border-box}body{margin:0;padding:24px;font:14px system-ui;
    background:var(--background);color:var(--text)}main{background:var(--surface);
    border:1px solid var(--border);border-radius:12px;padding:20px}h1{color:var(--heading);font-size:22px}
    p{color:var(--muted)}pre{background:var(--surface-alt);color:var(--text);border:1px solid var(--border);
    border-radius:8px;padding:16px;max-height:58vh;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere}
    button{background:var(--surface-alt);color:var(--text);border:1px solid var(--border);border-radius:6px;
    padding:10px 14px;margin-right:8px;cursor:pointer}button.primary{background:var(--accent);color:var(--accent-text)}
    button:disabled{opacity:.5;cursor:default}#status{white-space:pre-wrap;overflow-wrap:anywhere}
    input{display:block;width:100%;margin:8px 0 16px;padding:10px;background:var(--surface-alt);
    color:var(--text);border:1px solid var(--border);border-radius:6px}</style></head>
    <body><main><h1>Diagnostic report</h1><p>Review the report before exporting. Nothing is sent automatically.</p>
    <pre id="preview">Collecting diagnostic report…</pre>
    <label for="destination">Save to — full path and .json filename</label>
    <input id="destination" type="text" spellcheck="false" autocomplete="off" aria-describedby="destinationHelp">
    <p id="destinationHelp">Paste your chosen folder path and add a filename, for example pipspool-report.json. The folder must exist. Existing files are preserved.</p>
    <button id="export" class="primary" disabled>Export reviewed report</button>
    <button id="regenerate">Collect again</button><button id="close">Close</button><p id="status" role="status"></p></main>
    <script>
    var token='',parts=[];
    function receive(data){
      if(data.type==='theme'){token=data.theme_token;parts=[];return;}
      if(data.type==='theme-background'&&data.theme_token===token){
        if(data.index!==parts.length)return;parts.push(data.chunk);
        if(parts.length===data.total){var image=parts.join('');
          if(/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(image)){
            document.body.style.backgroundImage='url("'+image+'")';document.body.style.backgroundSize='cover';
            document.body.style.backgroundPosition='center';document.body.style.backgroundAttachment='fixed';}}
        return;}
      if(data.type==='diagnostic-preview'){document.getElementById('preview').textContent=data.text;
        document.getElementById('export').disabled=false;document.getElementById('status').textContent='';}
      if(data.type==='diagnostic-export'||data.type==='error')document.getElementById('status').textContent=data.message;
    }
    function collect(){document.getElementById('export').disabled=true;
      document.getElementById('preview').textContent='Collecting diagnostic report…';
      window.orca.postMessage({action:'diagnostic-preview'});}
    document.getElementById('export').onclick=function(){
      var path=document.getElementById('destination').value.trim();
      if(!path){document.getElementById('status').textContent='Choose a destination path and filename first.';return;}
      window.orca.postMessage({action:'diagnostic-export',path:path});};
    document.getElementById('regenerate').onclick=collect;
    document.getElementById('close').onclick=function(){window.orca.close();};
    function start(){if(!window.orca||!window.orca.onMessage){setTimeout(start,50);return;}
      window.orca.onMessage(receive);window.orca.postMessage({action:'diagnostic-ready'});}
    start();</script></body></html>""".replace("VARIABLES", variables)


def diagnostic_value(value):
    """Only bounded numeric values leave the source; strings/code are omitted."""
    if value is None:
        return {"present": False}
    if isinstance(value, str):
        try:
            decoded = json.loads(value)
            if isinstance(decoded, (list, int, float)):
                value = decoded
        except (ValueError, TypeError):
            pass
    values = value if isinstance(value, list) else [value]
    if len(values) <= 32 and all(
        isinstance(v, (str, int, float)) and not isinstance(v, bool)
        and re.fullmatch(r"-?[0-9]{1,9}(?:\.[0-9]{1,9})?", str(v))
        for v in values
    ):
        return {"present": True, "numeric": [str(v) for v in values]}
    return {"present": True, "content": "omitted"}


def build_diagnostic_report(live_values=None):
    """Read-only, explicit collection. No sync, remote writes or raw logs."""
    settings = load_settings()
    fields = [key for key in ORCA_SETTINGS if key in settings.get("selected_fields", [])]
    report = {"schema": 1, "pipspool": PLUGIN_VERSION,
              "source": "stable release",
              "platform": sys.platform, "python": sys.version.split()[0],
              "created": datetime.now().isoformat(timespec="seconds"),
              "scope": "shared" if shared_filament_settings(settings) else "individual",
              "selected_fields": fields, "spools": [],
              "privacy": "No raw logs, names, IDs, paths, URLs, credentials or code. Numeric selected settings only."}
    try:
        spools = SpoolmanClient(settings["spoolman_url"]).active_spools()
    except Exception as exc:
        report["collection_error"] = type(exc).__name__
        return report
    profiles = orca_profiles()
    aliases = {}
    baselines = settings.get("advanced_sync_state") or {}
    for index, spool in enumerate(spools, 1):
        fid = str(spool.get("filament", {}).get("id"))
        alias = aliases.setdefault(fid, "filament-" + str(len(aliases) + 1))
        row = {"spool": "spool-" + str(index), "filament": alias, "copies": []}
        report["spools"].append(row)
        try:
            copies = profiles.presets_for_spool(spool["id"])
            for copy in copies:
                effective = profiles.effective_preset(copy)
                live = (live_values or {}).get(copy.get("name"), {})
                row["copies"].append({"fields": {
                    key: {"saved": diagnostic_value(copy.get(key)),
                          "effective": diagnostic_value(effective.get(key)),
                          "live": diagnostic_value(live.get(key))} for key in fields}})
            shared = shared_filament_settings(settings)
            entity = spool.get("filament", {}) if shared else spool
            baseline_key = fid if shared else f"spool:{spool['id']}:filament:{fid}"
            baseline = baselines.get(baseline_key) or {}
            row["fields"] = {key: {
                "remote": diagnostic_value((entity.get("extra") or {}).get(orca_extra_key(key))),
                "baseline": diagnostic_value(baseline.get(key))} for key in fields}
        except Exception as exc:
            row["collection_error"] = type(exc).__name__
    return report


def quiet_page_state() -> dict[str, Any]:
    """Local loading shell; the ready message starts the connection."""
    settings = load_settings()
    return {
        "type": "state", "connected": False, "connection_checked": False,
        "url": settings.get("spoolman_url", DEFAULT_SPOOLMAN_URL),
        "detail": "Connecting to Spoolman…",
        "shared_filament_settings": shared_filament_settings(settings),
        "selected_fields": settings.get("selected_fields", []),
        "inject_spool_id_gcode": spool_id_gcode_enabled(settings),
        "low_stock_threshold": low_stock_threshold(settings),
        "spool_table_columns": spool_table_columns(settings),
        "restart_required": restart_required(settings),
        "last_report": settings.get("last_sync_report"), "spools": [], "gates": [],
        "lifecycle_supported": LIFECYCLE_SUPPORTED,
        "lifecycle_mode": "Waiting for first use",
    }


def pipspool_page_state(notice=None, friendly_initial_error=False, on_inventory=None, prefetched_inventory=None) -> dict[str, Any]:
    started_at = time.perf_counter()
    settings = prefetched_inventory[0] if prefetched_inventory is not None else load_settings()
    try:
        spools = (prefetched_inventory[1] if prefetched_inventory is not None
                  else SpoolmanClient(settings["spoolman_url"]).active_spools())
        connected, detail = True, f"Found {len(spools)} active spool(s)."
    except PermissionError as exc:
        spools, connected = [], False
        detail = NETWORK_PERMISSION_RETRY_MESSAGE
        log(f"[PAGE NETWORK PERMISSION] {exc}")
    except Exception as exc:
        spools, connected = [], False
        detail = SPOOLMAN_CONNECTION_MESSAGE
        log(f"[PAGE CONNECTION ERROR] {exc}")
    log(
        f"[PAGE STATE] connected={connected}; url={settings.get('spoolman_url', DEFAULT_SPOOLMAN_URL)}; "
        f"detail={detail}"
    )
    fetched_at = time.perf_counter()
    if connected and on_inventory is not None:
        pending = {int(spool["id"]): {"status": "checking", "warning": "Checking Orca profile…"}
                   for spool in spools if spool.get("id") is not None}
        on_inventory(inventory_page_state(settings, spools, pending, True,
            detail + " Checking Orca profiles…", notice, pending=True))
    inventory_sent_at = time.perf_counter()
    selected_fields = tuple(
        setting for setting in ORCA_SETTINGS
        if setting in settings.get("selected_fields", [])
    )
    try:
        sync_state = settings.get("advanced_sync_state")
        profiles = orca_profiles() if spools else None
        indexed_at = time.perf_counter()
        statuses = profile_sync_statuses(
            spools, profiles, selected_fields,
            sync_state=sync_state if isinstance(sync_state, dict) else {},
            inject_spool_id=spool_id_gcode_enabled(settings),
            shared=shared_filament_settings(settings),
        ) if spools else {}
        log(f"[PAGE TIMING] profile_index={indexed_at - inventory_sent_at:.3f}s; "
            f"profile_compare={time.perf_counter() - indexed_at:.3f}s")
    except Exception as exc:
        log(f"[PROFILE STATUS ERROR] {exc}")
        statuses = {
            int(spool["id"]): {
                "status": "error",
                "warning": "PipSpool could not check this spool's Orca profile.",
            }
            for spool in spools if spool.get("id") is not None
        }
    checked_at = time.perf_counter()
    log(f"[PAGE TIMING] fetch={fetched_at - started_at:.3f}s; "
        f"inventory_delivery={inventory_sent_at - fetched_at:.3f}s; "
        f"profile_checks={checked_at - inventory_sent_at:.3f}s; spools={len(spools)}")
    return inventory_page_state(settings, spools, statuses, connected, detail, notice)


def inventory_page_state(settings, spools, statuses, connected, detail, notice=None, pending=False):
    gates = [
        gate for spool in spools
        if (gate := page_gate_data(spool, statuses.get(int(spool.get("id") or -1))))
    ]
    gates.sort(key=lambda item: (item["printer"].casefold(), item["gate"]))
    synchronization_reasons = [
        str(value.get("reason") or value.get("warning") or "").strip()
        for _, value in sorted(statuses.items())
        if value.get("status") in {"profile_missing", "update_required"}
    ]
    synchronization_required = any(
        value.get("status") in {"profile_missing", "update_required"}
        for value in statuses.values()
    )
    lifecycle_reason = (LIFECYCLE_COORDINATOR.consume_sync_reason(
        synchronization_required
    ) if not pending else None)
    if lifecycle_reason:
        synchronization_reasons.insert(0, lifecycle_reason)
    lifecycle = LIFECYCLE_COORDINATOR.diagnostics()
    return {
        "type": "state",
        "connected": connected,
        "permission_required": not connected and detail == NETWORK_PERMISSION_RETRY_MESSAGE,
        "detail": notice or detail,
        "profiles_pending": pending,
        "url": settings.get("spoolman_url", DEFAULT_SPOOLMAN_URL),
        "shared_filament_settings": shared_filament_settings(settings),
        "selected_fields": settings.get("selected_fields", []),
        "inject_spool_id_gcode": spool_id_gcode_enabled(settings),
        "low_stock_threshold": low_stock_threshold(settings),
        "spool_table_columns": spool_table_columns(settings),
        "restart_required": restart_required(settings),
        "synchronization_required": synchronization_required,
        "synchronization_reasons": synchronization_reasons,
        "lifecycle_supported": lifecycle["supported"],
        "lifecycle_mode": lifecycle["mode"],
        "lifecycle_last_event": lifecycle["last_event"],
        "lifecycle_last_subject": lifecycle["last_subject"],
        "lifecycle_last_source": lifecycle["last_source"],
        "lifecycle_active_filament": lifecycle["active_filament"],
        "lifecycle_active_printer": lifecycle["active_printer"],
        "available_update": available_update(settings),
        "last_report": settings.get("last_sync_report"),
        "spools": [
            page_spool_data(spool, statuses.get(int(spool.get("id") or -1)))
            for spool in spools
        ],
        "gates": page_gate_slots(gates),
    }


def pipspool_page_html(initial_state=None) -> str:
    load_builtin_artwork()
    if initial_state is None:
        initial_state = {
            "type": "state",
            "connected": False,
            "detail": "Connection state unavailable.",
            "selected_fields": [],
            "inject_spool_id_gcode": True,
            "low_stock_threshold": DEFAULT_LOW_STOCK_THRESHOLD_GRAMS,
            "spool_table_columns": list(DEFAULT_SPOOL_TABLE_COLUMNS),
            "last_report": None,
            "spools": [],
        }
    initial_state_json = json.dumps(initial_state).replace("</", "<\\/")
    initial_connected = initial_state.get("connected") is True
    initial_status = "Connection OK" if initial_connected else "Not connected"
    initial_detail = escape(str(initial_state.get("detail") or ""))
    initial_pip = PIP_HAPPY_DATA_URI if initial_connected else PIP_SAD_DATA_URI
    initial_spool_id_gcode = initial_state.get("inject_spool_id_gcode", True) is not False
    initial_spools = initial_state.get("spools") or []
    initial_gates = initial_state.get("gates") or []
    initial_low_stock_threshold = numeric(initial_state.get("low_stock_threshold"))
    if initial_low_stock_threshold is None or initial_low_stock_threshold < 0:
        initial_low_stock_threshold = DEFAULT_LOW_STOCK_THRESHOLD_GRAMS
    initial_table_columns = [
        column for column in SPOOL_TABLE_COLUMNS
        if column in initial_state.get(
            "spool_table_columns", DEFAULT_SPOOL_TABLE_COLUMNS
        )
    ]
    selected_fields = set(initial_state.get("selected_fields") or [])
    initial_report = initial_state.get("last_report")
    initial_restart_required = initial_state.get("restart_required") is True
    initial_synchronization_required = (
        initial_state.get("synchronization_required") is True
    )
    initial_sync_reasons = [
        str(reason) for reason in initial_state.get("synchronization_reasons", [])
        if str(reason).strip()
    ]
    initial_sync_text = "Changes detected — select Synchronize now to reconcile Orca and Spoolman."
    if initial_sync_reasons:
        shown_reasons = initial_sync_reasons[:3]
        remaining_reasons = len(initial_sync_reasons) - len(shown_reasons)
        initial_sync_text = "Synchronization needed — " + " | ".join(shown_reasons)
        if remaining_reasons:
            initial_sync_text += f" | and {remaining_reasons} more"
    initial_available_update = initial_state.get("available_update")
    if isinstance(initial_report, dict):
        initial_active = initial_report.get("active_spools", len(initial_spools))
        initial_change_lines = [
            str(change) for change in initial_report.get("changes", [])
        ]
        initial_changed_ids = {
            int(match.group(1))
            for change in initial_change_lines
            if (match := re.match(r"^Spool #(\d+):", change))
        }
        initial_changed = int(
            initial_report.get("changed_spools", len(initial_changed_ids)) or 0
        )
        initial_errors = initial_report.get("errors") or []
        report_lines = [
            (
                f"{initial_changed} spool profile"
                f"{'s' if initial_changed != 1 else ''} changed."
                if initial_changed else "No spool profiles needed changes."
            )
        ]
        if initial_change_lines:
            report_lines.extend(("", *[f"• {change}" for change in initial_change_lines]))
        if initial_errors:
            report_lines.extend(("", "Errors:", *[f"• {error}" for error in initial_errors]))
        initial_report_text = "\n".join(report_lines)
    else:
        initial_active = len(initial_spools)
        initial_changed = "—"
        initial_errors = []
        initial_report_text = "No synchronization report yet."
    spool_rows = []
    for spool in initial_spools:
        color = str(spool.get("color") or "#FFFFFF")
        if not re.fullmatch(r"#[0-9A-Fa-f]{6}", color):
            color = "#FFFFFF"
        remaining = spool.get("remaining")
        remaining_text = "—" if remaining is None else f"{remaining} g"
        nozzle_temperature = spool.get("nozzle_temperature")
        nozzle_text = (
            "—" if nozzle_temperature is None else f"{nozzle_temperature} °C"
        )
        bed_temperature = spool.get("bed_temperature")
        bed_text = "—" if bed_temperature is None else f"{bed_temperature} °C"
        loaded_text = (
            f"{spool.get('printer') or 'Printer'} · Gate {spool.get('gate')}"
            if spool.get("loaded") and spool.get("gate") is not None else "—"
        )
        sync_status = str(spool.get("sync_status") or "")
        sync_text = {
            "synced": "Synced",
            "checking": "Checking…",
            "profile_missing": "Profile missing",
            "update_required": "Update required",
            "conflict": "Conflict",
            "error": "Error",
        }.get(sync_status, "Unknown")
        sync_warning = escape(str(spool.get("sync_warning") or ""), quote=True)
        remaining_percent = numeric(spool.get("remaining_percent"))
        remaining_step = numeric(spool.get("remaining_step"))
        step = 0 if remaining_step is None else max(0, min(100, remaining_step))
        hue = max(0.0, min(120.0, (step - 10.0) / 90.0 * 120.0))
        remaining_title = (
            "Remaining percentage unavailable" if remaining_percent is None
            else f"{remaining_percent:g}% remaining; gauge shown in 10% steps"
        )
        fill_color = (
            "#31516d" if remaining_step is None else f"hsl({hue:g},46%,30%)"
        )
        remaining_html = (
            f'<span class="table-gauge" title="{escape(remaining_title, quote=True)}">'
            f'<span class="table-gauge-fill" style="width:{step:g}%;background:{fill_color}"></span>'
            f'<span class="table-gauge-copy">{escape(remaining_text)}</span></span>'
        )
        spool_rows.append(
            "<tr>"
            f'<td><button class="spool-link" data-open-spool="{escape(str(spool.get("id", "")), quote=True)}" title="Open this spool in Spoolman">#{escape(str(spool.get("id", "")))} ↗</button> <button data-sync-spool="{escape(str(spool.get("id", "")), quote=True)}" title="Synchronize this spool and its shared Filament group">Sync</button></td>'
            f"<td>{escape(str(spool.get('material') or ''))}</td>"
            f'<td data-column="filament">{escape(str(spool.get("name") or ""))}</td>'
            f'<td data-column="manufacturer">{escape(str(spool.get("vendor") or ""))}</td>'
            f'<td data-column="colour"><span class="swatch" style="background:{color}"></span>{escape(color)}</td>'
            f'<td data-column="nozzle">{escape(nozzle_text)}</td>'
            f'<td data-column="bed">{escape(bed_text)}</td>'
            f'<td data-column="remaining">{remaining_html}</td>'
            f'<td data-column="location">{escape(str(spool.get("location") or "—"))}</td>'
            f'<td data-column="loaded">{escape(loaded_text)}</td>'
            f'<td data-column="sync"><span class="profile-status profile-{escape(sync_status or "unknown", quote=True)}" title="{sync_warning}">{escape(sync_text)}</span></td></tr>'
        )
    spool_rows_html = "".join(spool_rows)
    loadout_cards = []
    for gate in initial_gates:
        color = str(gate.get("color") or "#FFFFFF")
        if not re.fullmatch(r"#[0-9A-Fa-f]{6}", color):
            color = "#FFFFFF"
        is_empty = gate.get("empty") is True
        gate_warning = str(gate.get("warning") or "").strip()
        has_problem = bool(gate_warning) and not is_empty
        remaining = gate.get("remaining")
        is_low = (
            not is_empty
            and initial_low_stock_threshold > 0
            and numeric(remaining) is not None
            and numeric(remaining) <= initial_low_stock_threshold
        )
        status = "Empty" if is_empty else f"Spool #{gate.get('id')}"
        material = "—" if is_empty else str(gate.get("material") or "Unknown")
        remaining_text = "" if is_empty else ("— g" if remaining is None else f"{remaining} g")
        remaining_percent = numeric(gate.get("remaining_percent"))
        remaining_step = numeric(gate.get("remaining_step"))
        gauge_html = ""
        if not is_empty:
            if remaining_step is None:
                fill_style = "width:0%;background:#31516d"
                gauge_title = "Remaining percentage unavailable"
            else:
                hue = max(0.0, min(120.0, (remaining_step - 10.0) / 90.0 * 120.0))
                fill_style = f"width:{remaining_step:g}%;background:hsl({hue:g},46%,30%)"
                gauge_title = f"{remaining_percent:g}% remaining; gauge shown in 10% steps"
            label_html = '<span class="gate-low-label">Low filament</span>' if is_low else ""
            gauge_html = (
                f'<span class="gate-gauge" title="{escape(gauge_title, quote=True)}">'
                f'<span class="gate-gauge-fill" style="{fill_style}"></span>'
                f'<span class="gate-gauge-copy">{label_html}'
                f'<span class="gate-grams">{escape(remaining_text)}</span></span></span>'
            )
        title_attribute = ""
        if has_problem:
            title_attribute = f' title="{escape(gate_warning, quote=True)}"'
        elif is_low:
            low_title = (
                f"Low filament: {remaining_text} remaining "
                f"(warning at {initial_low_stock_threshold:g} g)"
            )
            title_attribute = f' title="{escape(low_title, quote=True)}"'
        loadout_cards.append(
            f'<article class="gate-tile{" empty-gate" if is_empty else ""}{" gate-problem" if has_problem else ""}"'
            f'{title_attribute}>'
            f'<span class="gate-status">{escape(status)}</span>'
            f'<img class="gate-image" src="{gate_image_data_uri(color, int(gate.get("gate", 0)), is_empty)}" alt="Gate {escape(str(gate.get("gate", "")))}">'
            f'<b class="gate-material">{escape(material)}</b>'
            f'<span class="gate-printer">{escape(str(gate.get("printer") or "Printer"))}</span>'
            f'{gauge_html}</article>'
        )
    loadout_cards_html = "".join(loadout_cards)
    field_tabs = []
    field_panels = []
    for group_index, (group, fields) in enumerate(ORCA_SETTING_GROUPS.items()):
        group_count = sum(field in selected_fields for field in fields)
        choices = "".join(
            f'<label class="choice"><input type="checkbox" value="{escape(field)}"'
            f'{" checked" if field in selected_fields else ""}>'
            f'<span>{escape(field.replace("_", " ").title())}</span></label>'
            for field in fields
        )
        active_class = " active" if group_index == 0 else ""
        field_tabs.append(
            f'<button class="field-tab{active_class}" type="button" role="tab" '
            f'aria-selected="{"true" if group_index == 0 else "false"}" '
            f'data-field-tab="{escape(group)}">{escape(group)} '
            f'<span class="tab-count" data-tab-count="{escape(group)}">{group_count}</span></button>'
        )
        field_panels.append(
            f'<section class="field-panel{active_class}" role="tabpanel" '
            f'data-field-panel="{escape(group)}"{"" if group_index == 0 else " hidden"}>'
            f'<div class="field-panel-heading"><div><h3>{escape(group)}</h3>'
            f'<p class="muted">Choose the {escape(group.lower())} settings PipSpool may synchronize with Spoolman.</p></div>'
            f'<div class="group-actions"><button type="button" data-group-action="all">Select all</button>'
            f'<button type="button" data-group-action="none">Clear</button></div></div>'
            f'<div class="choices">{choices}</div></section>'
        )
    page_themes = json.dumps(theme_state(include_background=False)).replace("<", "\\u003c")
    return f"""<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><style>
.pipspool-page{{--orca-bg:#030914;--orca-fg:#f5ead8;--orca-muted:#a9bfd4;--orca-accent:#168cff;--orca-accent-fg:#03101e;--orca-border:#1767a8;--panel:#08264b;--panel2:#061a33;--cyan:#42e5ea;--ivory:#f1dfc7;--amber:#f2a43a;--good:#67d39a;--warn:#f2a43a;--bad:#f07168}}
*{{box-sizing:border-box}}html{{height:100%;margin:0;background:#030914}}body.pipspool-page{{min-height:100%;margin:0;overflow:auto;background:radial-gradient(circle at 50% -220px,#0c407c 0,#061a34 360px,var(--orca-bg) 760px);color:var(--orca-fg);font:14px/1.45 var(--orca-font,system-ui,"Segoe UI",sans-serif)}}main{{max-width:1440px;margin:auto;padding:22px}}header{{display:flex;align-items:center;gap:15px;margin-bottom:18px;padding-bottom:13px;border-bottom:2px solid var(--amber)}}
.logo{{width:58px;height:58px;object-fit:contain}}h1{{font-size:23px;margin:0;color:var(--ivory)}}.sub{{color:var(--orca-muted);margin:2px 0 0}}
.top-actions{{margin-left:auto;display:flex;flex-wrap:wrap;align-items:center;gap:9px}}.theme-label{{display:flex;align-items:center;gap:6px;color:var(--orca-muted)}}body.pipspool-page button{{border:1px solid #277fc5;border-radius:7px;background:#0a315f;color:var(--ivory);padding:8px 13px;cursor:pointer;font-weight:600}}
body.pipspool-page button:hover{{background:#0d4788;border-color:#42a9ff}}body.pipspool-page button:disabled{{opacity:.5;cursor:default}}body.pipspool-page .primary{{background:var(--orca-accent);border-color:#5bb5ff;color:var(--orca-accent-fg);box-shadow:0 0 14px rgba(22,140,255,.28)}}
.grid{{display:grid;grid-template-columns:minmax(0,3fr) minmax(0,1fr);gap:16px}}.card{{background:linear-gradient(145deg,#0a315f,#061c38);border:1px solid #147fd1;border-top-color:#36a7ff;border-radius:12px;padding:17px;box-shadow:0 10px 28px rgba(0,42,91,.32),inset 0 1px rgba(120,198,255,.08)}}
.card h2{{font-size:16px;margin:0 0 12px;color:var(--ivory)}}.status-line{{display:flex;align-items:center;gap:16px;min-height:118px}}.status-pip{{width:116px;height:116px;object-fit:contain;filter:drop-shadow(0 5px 8px rgba(0,0,0,.3))}}.status-copy b{{display:block;font-size:18px;margin-bottom:4px;color:var(--cyan)}}body.pipspool-page input[type=search]{{width:100%;background:#041326;color:var(--orca-fg);border:1px solid #1a6eae;border-radius:7px;padding:9px 11px;outline:none}}
.connection-layout{{display:grid;grid-template-columns:minmax(270px,330px) minmax(0,1fr);gap:20px;align-items:start}}.connection-side{{min-width:0}}.gate-panel{{position:relative;min-width:0;padding-left:20px;border-left:1px solid var(--orca-border)}}.gate-panel h2{{margin-bottom:2px;color:var(--ivory)}}.gate-panel>p{{padding-right:235px}}
.spool-id-control{{position:absolute;top:-4px;right:0;display:flex;align-items:center;gap:10px;padding:7px 10px;border:1px solid #2385cf;border-radius:9px;background:#061a35;color:var(--ivory);cursor:pointer;box-shadow:0 4px 12px rgba(0,0,0,.2)}}.spool-id-control-copy{{display:flex;flex-direction:column;line-height:1.15}}.spool-id-control-copy b{{font-size:12px}}.spool-id-control-copy span{{margin-top:3px;color:var(--orca-muted);font-size:10px}}.switch{{position:relative;width:40px;height:22px;flex:0 0 auto}}.switch input{{position:absolute;opacity:0;pointer-events:none}}.switch-track{{position:absolute;inset:0;border:1px solid #57738d;border-radius:12px;background:#24384b;transition:.18s}}.switch-track:after{{content:"";position:absolute;top:3px;left:3px;width:14px;height:14px;border-radius:50%;background:#d8e3eb;transition:.18s}}.switch input:checked+.switch-track{{border-color:#36a7ff;background:#1177c5;box-shadow:0 0 10px rgba(54,167,255,.28)}}.switch input:checked+.switch-track:after{{transform:translateX(18px);background:white}}.spool-id-control:focus-within{{outline:2px solid var(--cyan);outline-offset:2px}}
body.pipspool-page input:focus{{border-color:var(--cyan);box-shadow:0 0 0 2px rgba(66,229,234,.16)}}.metrics{{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:12px}}.metric{{background:#061a35;border:1px solid #1766a5;border-radius:8px;padding:10px}}.metric b{{display:block;font-size:19px;color:var(--cyan)}}.metric span,.muted{{color:var(--orca-muted);font-size:12px}}
.report{{white-space:pre-wrap;background:#041326;border:1px solid #0d4f85;border-radius:8px;padding:11px;min-height:76px;color:#d7e7f4}}.toolbar{{display:flex;align-items:flex-start;gap:9px;margin-bottom:10px}}.toolbar input[type=search]{{flex:1}}.columns-menu{{position:relative;border:0;padding:0;flex:0 0 auto}}.columns-menu summary{{list-style:none;border:1px solid #277fc5;border-radius:7px;background:#0a315f;color:var(--ivory);padding:8px 13px;font-weight:600}}.columns-menu summary::-webkit-details-marker{{display:none}}.columns-menu[open] summary{{background:#0d4788}}.column-choices{{position:absolute;z-index:5;right:0;top:42px;width:210px;padding:10px;border:1px solid #2385cf;border-radius:9px;background:#061a35;box-shadow:0 10px 26px rgba(0,0,0,.45)}}.column-choices label{{display:flex;align-items:center;gap:8px;padding:5px 3px}}.spool-controls{{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:0 0 11px}}.spool-filters{{display:flex;flex-wrap:wrap;gap:6px}}body.pipspool-page .spool-filter{{padding:5px 9px;border-color:#1d639a;background:#071f3b;color:#a9bfd4;font-size:11px}}body.pipspool-page .spool-filter.active{{border-color:var(--cyan);background:#0a4568;color:#e8ffff;box-shadow:0 0 9px rgba(66,229,234,.16)}}.filter-count{{display:inline-flex;min-width:18px;height:18px;margin-left:5px;padding:0 5px;align-items:center;justify-content:center;border-radius:9px;background:#041326;color:#9dcbed;font-size:10px}}.sort-controls{{display:flex;align-items:center;gap:6px;flex:0 0 auto}}.sort-controls label{{color:var(--orca-muted);font-size:11px}}body.pipspool-page select{{height:31px;border:1px solid #277fc5;border-radius:7px;background:#061a35;color:var(--ivory);padding:4px 28px 4px 8px;outline:none}}body.pipspool-page .sort-direction{{min-width:34px;height:31px;padding:4px 8px;font-size:15px}}
.spool-link{{padding:2px 5px!important;border:0!important;background:transparent!important;color:#8fd0ff!important;font:inherit!important;white-space:nowrap}}.spool-link:hover{{color:var(--cyan)!important;text-decoration:underline}}.table-gauge{{position:relative;display:inline-flex;min-width:88px;min-height:25px;align-items:center;justify-content:center;overflow:hidden;border:1px solid #2789c7;border-radius:9px;background:#06213d}}.table-gauge-fill{{position:absolute;inset:0 auto 0 0}}.table-gauge-copy{{position:relative;z-index:1;font-size:12px;font-weight:650;color:#f4f5f6}}.profile-status{{display:inline-block;padding:3px 7px;border-radius:8px;background:#092746;color:#b9d5ea;white-space:nowrap}}.profile-synced{{color:#9dd8bd}}.profile-profile_missing,.profile-update_required,.profile-conflict,.profile-error{{border:1px solid #d65e58;background:#3a1c20;color:#ffd1cc}}
table{{width:100%;border-collapse:separate;border-spacing:0}}th,td{{padding:9px 8px;border-bottom:1px solid #175486;text-align:left}}th{{color:var(--orca-muted);font-size:12px}}.spool-wrap thead th{{position:sticky;top:0;z-index:2;background:#08264b;box-shadow:0 1px 0 #2385cf}}.swatch{{display:inline-block;width:14px;height:14px;border:1px solid #77a5c8;border-radius:50%;vertical-align:-2px;margin-right:7px}}
.gate-grid{{display:grid;grid-template-columns:repeat(8,minmax(108px,1fr));gap:10px;margin-top:14px}}.gate-tile{{min-width:0;min-height:184px;padding:11px 8px;border:1px solid #2385cf;border-radius:10px;background:linear-gradient(160deg,#0b3970,#061e3f);display:flex;flex-direction:column;align-items:center;text-align:center;box-shadow:0 5px 15px rgba(0,45,95,.28),inset 0 1px rgba(126,204,255,.1)}}.gate-status{{height:21px;color:#8fc8ff;font-size:11px}}.gate-image{{width:72px;height:58px;margin:3px 0 7px;display:block;filter:drop-shadow(0 4px 5px rgba(0,0,0,.32))}}.gate-material{{font-size:14px;line-height:1.2;color:var(--ivory)}}.gate-printer{{max-width:100%;margin-top:3px;color:var(--orca-muted);font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}}.gate-alert{{margin-top:5px;color:#ffd37f;font-size:11px;font-weight:750}}.gate-remaining{{margin-top:auto;padding:3px 8px;border:1px solid #32a8eb;border-radius:10px;background:#08345a;color:var(--cyan);font-size:12px;font-weight:650}}.low-stock{{border-color:var(--amber);background:linear-gradient(160deg,#624014,#261b0c);box-shadow:0 0 0 1px rgba(242,164,58,.22),0 7px 18px rgba(90,52,0,.42),inset 0 1px rgba(255,221,158,.13)}}.low-stock .gate-remaining{{border-color:var(--amber);background:#4b300d;color:#ffe0a1}}.empty-gate{{opacity:.58}}.empty-gate .gate-status{{color:#d3d6da;font-size:13px;font-weight:700}}.empty-gate .gate-remaining{{visibility:hidden}}
.gate-gauge{{position:relative;width:100%;min-height:28px;margin-top:auto;overflow:hidden;border:1px solid #32a8eb;border-radius:10px;background:#041c31;color:#f8fbff;font-size:11px;font-weight:700;box-shadow:inset 0 1px 3px rgba(0,0,0,.4)}}.gate-gauge-fill{{position:absolute;inset:0 auto 0 0;transition:width .2s ease}}.gate-gauge-copy{{position:relative;z-index:1;min-height:26px;padding:2px 5px;display:flex;align-items:center;justify-content:center;gap:4px;line-height:1.05;text-shadow:0 1px 2px #000}}.gate-low-label{{display:block;font-size:9px;color:#fff0dd}}.gate-grams{{white-space:nowrap}}
.gate-problem{{border-color:var(--bad);box-shadow:0 0 0 1px rgba(240,113,104,.3),0 7px 18px rgba(92,17,17,.38),inset 0 1px rgba(255,190,185,.12)}}
.spool-card{{display:flex;flex-direction:column;min-width:0;min-height:0}}.spool-card>h2,.spool-card>.toolbar,.spool-card>.spool-controls,.spool-card>#empty{{flex-shrink:0}}.spool-wrap{{height:420px;flex:1 1 420px;min-height:0;overflow:auto}}.wide{{grid-column:1/-1}}details{{border-top:1px solid var(--orca-border);padding:11px 0}}summary{{cursor:pointer;font-weight:650}}
.field-tabs{{display:flex;min-width:0;align-items:flex-end;gap:24px;margin:17px 0 0;padding:0 4px;border-bottom:1px solid #1d6fae;overflow-x:auto;overflow-y:hidden;overscroll-behavior-inline:contain}}body.pipspool-page .field-tab{{position:relative;flex:0 0 auto;border:0;border-radius:0;background:transparent;color:#8fa9c1;padding:10px 3px 11px;font-size:14px;font-weight:600;box-shadow:none}}body.pipspool-page .field-tab:hover{{border:0;background:transparent;color:var(--ivory)}}body.pipspool-page .field-tab.active{{color:var(--ivory)}}body.pipspool-page .field-tab.active:after{{content:"";position:absolute;left:0;right:0;bottom:-1px;height:3px;border-radius:3px 3px 0 0;background:var(--cyan);box-shadow:0 0 10px rgba(66,229,234,.35)}}.tab-count{{display:inline-flex;min-width:20px;height:20px;margin-left:6px;padding:0 6px;align-items:center;justify-content:center;border:1px solid #246fa9;border-radius:10px;background:#061a35;color:#a9bfd4;font-size:11px}}.field-tab.active .tab-count{{border-color:#2ca9c2;color:var(--cyan)}}
.field-workspace{{min-height:270px;padding:18px 4px 4px}}.field-panel[hidden]{{display:none}}.field-panel-heading{{display:flex;align-items:flex-start;justify-content:space-between;gap:18px;margin-bottom:15px;padding-bottom:12px;border-bottom:1px solid #174f80}}.field-panel-heading h3{{margin:0 0 3px;color:var(--ivory);font-size:15px}}.field-panel-heading p{{margin:0}}.group-actions{{display:flex;flex:0 0 auto;gap:7px}}.group-actions button{{padding:5px 10px;font-size:12px}}.choices{{display:grid;grid-template-columns:repeat(auto-fit,minmax(270px,1fr));gap:7px 18px}}.choice{{display:flex;align-items:center;gap:10px;min-height:34px;padding:5px 8px;border:1px solid transparent;border-radius:6px;color:#dce9f3}}.choice:hover{{border-color:#1767a8;background:#07284d}}.choice input{{flex:0 0 auto}}input[type=checkbox]{{accent-color:var(--orca-accent)}}
.field-footer{{display:flex;justify-content:space-between;align-items:center;margin-top:12px}}.danger-zone{{border-color:#704b47;background:linear-gradient(145deg,#352a29,#2a2222)}}.danger-zone p{{color:#ddbeb8}}.error{{color:var(--bad)}}
.page-footer{{margin-top:18px;padding:14px 10px 10px;border-top:1px solid #174f80;color:var(--orca-muted);font-size:11px;text-align:left}}.page-footer b{{color:var(--ivory);font-weight:650}}.footer-separator{{margin:0 7px;color:#3d7daf}}
.restart-banner{{grid-column:1/-1;display:flex;align-items:center;gap:10px;padding:12px 15px;border:1px solid var(--amber);border-radius:9px;background:#3a280d;color:#ffe4ad;font-weight:650;box-shadow:0 0 16px rgba(242,164,58,.14)}}.restart-banner[hidden]{{display:none}}.restart-symbol{{font-size:18px;color:var(--amber)}}
.sync-banner{{grid-column:1/-1;display:flex;align-items:center;gap:10px;padding:12px 15px;border:1px solid #42a9ff;border-radius:9px;background:#073354;color:#d8f6ff;font-weight:650;box-shadow:0 0 16px rgba(66,169,255,.12)}}.sync-banner[hidden]{{display:none}}.sync-symbol{{font-size:17px;color:var(--cyan)}}
.update-banner{{grid-column:1/-1;display:flex;align-items:center;gap:10px;padding:12px 15px;border:1px solid var(--cyan);border-radius:9px;background:#073354;color:#d8f6ff;font-weight:650;box-shadow:0 0 16px rgba(66,229,234,.12)}}.update-banner[hidden]{{display:none}}.update-symbol{{font-size:17px;color:var(--cyan)}}
@media(max-width:1100px){{.connection-layout{{grid-template-columns:1fr}}.gate-panel{{padding:17px 0 0;border-left:0;border-top:1px solid var(--orca-border)}}.spool-id-control{{top:12px}}.gate-grid{{grid-template-columns:repeat(4,minmax(108px,1fr))}}}}@media(max-width:850px){{.grid{{grid-template-columns:1fr}}.top-actions{{margin-left:0}}header{{flex-wrap:wrap}}.gate-panel>p{{padding-right:0;margin-top:58px}}.spool-id-control{{left:0;right:auto}}.gate-grid{{grid-template-columns:repeat(2,minmax(108px,1fr))}}.spool-controls{{align-items:flex-start;flex-direction:column}}.sort-controls{{width:100%}}.sort-controls select{{flex:1}}}}
body.pipspool-page .top-actions button,body.pipspool-page #themeSelect{{height:38px;min-height:38px;line-height:20px}}body.pipspool-page #themeSelect{{font-weight:600}}
</style><style id="themeStyle"></style></head><body id="pipspoolThemeRoot" class="pipspool-page"><main>
<header><img id="pageLogo" class="logo" src="{PIPSPOOL_LOGO_DATA_URI}" alt="PipSpool"><div><h1>PipSpool</h1><p class="sub">Spoolman synchronization for OrcaSlicer</p></div><div class="top-actions"><label class="theme-label"><select id="themeSelect" aria-label="Dashboard theme"></select></label><button id="settings" type="button">Settings</button><button id="diagnostics">Diagnostics</button><button id="feedback">Feedback</button><button id="refresh">Refresh</button><button id="sync" class="primary">Synchronize now</button></div></header>
<div class="grid"><div id="updateBanner" class="update-banner"{"" if initial_available_update else " hidden"}><span class="update-symbol">↑</span><span id="updateText">PipSpool {escape(str(initial_available_update or ''))} is available — open File → Plugins to update.</span></div><div id="syncBanner" class="sync-banner"{"" if initial_synchronization_required and not initial_restart_required else " hidden"}><span class="sync-symbol">⇄</span><span id="syncText">{escape(initial_sync_text)}</span></div><div id="restartBanner" class="restart-banner"{"" if initial_restart_required else " hidden"}><span class="restart-symbol">↻</span><span>Filament profiles changed — restart OrcaSlicer to load them.</span></div><section class="card wide"><div class="connection-layout"><div class="connection-side"><h2>Connection</h2><div class="status-line"><img id="statusPip" class="status-pip" src="{initial_pip}" alt="Pip connection status"><div class="status-copy"><b id="status">{initial_status}</b><p id="connectionDetail" class="muted">{initial_detail}</p><button id="allowConnection" type="button" hidden>Allow connection</button><p class="muted">Server settings, can be found in the PipSpool plugin settings.</p></div></div></div><div id="loadoutCard" class="gate-panel"><h2>Printer Gates/Toolheads</h2><p class="muted">A quick view of the gate assignments reported by Spoolman.</p><label class="spool-id-control" title="Enable or disable the configured spool-ID command; edit the command in PipSpool Settings"><span class="spool-id-control-copy"><b>Active spool G-code</b><span id="spoolIdState">{"Enabled" if initial_spool_id_gcode else "Disabled"}</span></span><span class="switch"><input id="spoolIdGcode" type="checkbox"{" checked" if initial_spool_id_gcode else ""}><span class="switch-track"></span></span></label><div id="loadout" class="gate-grid">{loadout_cards_html}</div><p id="loadoutEmpty" class="muted"{" hidden" if loadout_cards_html else ""}>No active spools are assigned to a printer gate in Spoolman.</p></div></div></section>
<section class="card spool-card"><h2>Active spools</h2><div class="toolbar"><input id="search" type="search" placeholder="Search by spool number, material, colour, manufacturer, name, location, gate or profile status"><details class="columns-menu"><summary>Columns</summary><div class="column-choices">{''.join(f'<label><input type="checkbox" data-table-column="{column}"{" checked" if column in initial_table_columns else ""}>{SPOOL_TABLE_COLUMN_LABELS[column]}</label>' for column in SPOOL_TABLE_COLUMNS)}</div></details></div><div class="spool-controls"><div class="spool-filters" role="group" aria-label="Filter active spools"><button type="button" class="spool-filter active" data-spool-filter="all" aria-pressed="true">All<span class="filter-count" data-filter-count="all">0</span></button><button type="button" class="spool-filter" data-spool-filter="loaded" aria-pressed="false">Loaded<span class="filter-count" data-filter-count="loaded">0</span></button><button type="button" class="spool-filter" data-spool-filter="low" aria-pressed="false">Low filament<span class="filter-count" data-filter-count="low">0</span></button><button type="button" class="spool-filter" data-spool-filter="sync" aria-pressed="false">Needs synchronization<span class="filter-count" data-filter-count="sync">0</span></button><button type="button" class="spool-filter" data-spool-filter="problems" aria-pressed="false">Profile problems<span class="filter-count" data-filter-count="problems">0</span></button></div><div class="sort-controls"><label for="spoolSort">Sort by</label><select id="spoolSort"><option value="id">Spool number</option><option value="material">Material</option><option value="remaining">Remaining weight</option><option value="vendor">Manufacturer</option><option value="gate">Gate/toolhead</option></select><button id="sortDirection" class="sort-direction" type="button" title="Ascending order" aria-label="Ascending order">↑</button></div></div><div class="spool-wrap"><table><thead><tr><th>Spool</th><th>Material</th><th data-column="filament">Filament</th><th data-column="manufacturer">Manufacturer</th><th data-column="colour">Colour</th><th data-column="nozzle">Nozzle</th><th data-column="bed">Bed</th><th data-column="remaining">Remaining</th><th data-column="location">Location</th><th data-column="loaded">Gate/Toolhead</th><th data-column="sync">Profile status</th></tr></thead><tbody id="spools">{spool_rows_html}</tbody></table></div><p id="empty" class="muted"{" hidden" if initial_spools else ""}>No matching active spools.</p></section>
<section class="card"><h2>Last synchronization</h2><div class="metrics"><div class="metric"><b id="active">{initial_active}</b><span>Active spools</span></div><div class="metric"><b id="changed">{initial_changed}</b><span>Changed spools</span></div><div class="metric"><b id="errors">{len(initial_errors) if isinstance(initial_report, dict) else '—'}</b><span>Errors</span></div></div><pre id="report" class="report">{escape(initial_report_text)}</pre></section>
<section class="card wide"><h2>Advanced field synchronization</h2><p id="settingScopeDescription" class="muted">Each physical spool has its own Orca profile. Selected Advanced values are stored on the shared Spoolman Filament, so changing one profile can update every profile using that Filament. Inventory belongs to the individual spool; ordinary filament temperatures still come from Spoolman.</p><nav class="field-tabs" role="tablist" aria-label="Orca filament setting sections">{''.join(field_tabs)}</nav><div class="field-workspace">{''.join(field_panels)}</div><div class="field-footer"><span id="selectionCount" class="muted">{len(selected_fields)} field{"" if len(selected_fields) == 1 else "s"} selected</span><button id="saveFields">Save field selection</button></div></section>
<section class="card wide danger-zone"><h2>Cleanup</h2><p>Remove every unselected <code>orca_*</code> field from Spoolman. This permanently deletes the saved values in those fields for all filaments.</p><button id="cleanup">Remove unselected fields…</button></section></div>
<footer class="page-footer"><b>PipSpool {escape(PLUGIN_VERSION)}</b><span class="footer-separator">•</span>© {COPYRIGHT_YEAR} Donko<span class="footer-separator">•</span>Spoolman synchronization for OrcaSlicer<br><span>Independent community project; not affiliated with OrcaSlicer or Spoolman.</span></footer>
<script>
function byId(id){{return document.getElementById(id);}}
var state={{spools:[],busy:false,lowStockThreshold:{initial_low_stock_threshold},tableColumns:{json.dumps(initial_table_columns)},spoolFilter:'all',spoolSort:'id',sortDirection:1}};
var bridgeReady=false;
function send(action,extra){{
  if(bridgeReady&&window.orca){{
    var payload={{action:action}};
    var key;
    extra=extra||{{}};
    for(key in extra){{if(Object.prototype.hasOwnProperty.call(extra,key))payload[key]=extra[key];}}
    window.orca.postMessage(payload);
  }}else{{window.setTimeout(function(){{send(action,extra);}},150);}}
}}
function setBusy(value){{
  state.busy=value;
  var rows=document.querySelectorAll('[data-sync-spool]');
  for(var rowIndex=0;rowIndex<rows.length;rowIndex++)rows[rowIndex].disabled=value;
  var ids=['sync','refresh','saveFields','cleanup'];
  var i;
  for(i=0;i<ids.length;i++)byId(ids[i]).disabled=value;
}}
function selectedFields(){{
  var inputs=document.querySelectorAll('.choices input:checked');
  var values=[];
  var i;
  for(i=0;i<inputs.length;i++)values.push(inputs[i].value);
  return values;
}}
function updateCounts(){{
  var sections=document.querySelectorAll('.field-panel');
  var i;
  for(i=0;i<sections.length;i++){{
    var count=sections[i].querySelectorAll('input:checked').length;
    var group=sections[i].getAttribute('data-field-panel');
    var badge=document.querySelector('[data-tab-count="'+group+'"]');
    if(badge)badge.textContent=count;
  }}
  var total=selectedFields().length;
  byId('selectionCount').textContent=total+' field'+(total===1?'':'s')+' selected';
}}
function selectedTableColumns(){{
  var inputs=document.querySelectorAll('[data-table-column]:checked');
  var values=[];
  var i;
  for(i=0;i<inputs.length;i++)values.push(inputs[i].getAttribute('data-table-column'));
  return values;
}}
function applyTableColumns(){{
  var cells=document.querySelectorAll('[data-column]');
  var i;
  for(i=0;i<cells.length;i++)cells[i].style.display=state.tableColumns.indexOf(cells[i].getAttribute('data-column'))===-1?'none':'';
}}
function spoolMatchesFilter(spool,filter){{
  if(filter==='loaded')return spool.loaded===true&&spool.gate!=null;
  if(filter==='low')return state.lowStockThreshold>0&&spool.remaining!=null&&spool.remaining<=state.lowStockThreshold;
  if(filter==='sync')return spool.sync_status==='update_required';
  if(filter==='problems')return spool.sync_status==='profile_missing'||spool.sync_status==='conflict'||spool.sync_status==='error';
  return true;
}}
function updateFilterCounts(){{
  var filters=['all','loaded','low','sync','problems'];
  var i,j,count,badge;
  for(i=0;i<filters.length;i++){{
    count=0;
    for(j=0;j<state.spools.length;j++)if(spoolMatchesFilter(state.spools[j],filters[i]))count++;
    badge=document.querySelector('[data-filter-count="'+filters[i]+'"]');
    if(badge)badge.textContent=count;
  }}
}}
function spoolSortValue(spool,key){{
  if(key==='remaining')return spool.remaining==null?-1:Number(spool.remaining);
  if(key==='gate')return spool.loaded&&spool.gate!=null?(String(spool.printer||'').toLowerCase()+' '+('00000000'+String(spool.gate)).slice(-8)):'\uffff';
  if(key==='id')return Number(spool.id)||0;
  return String(spool[key]||'').toLowerCase();
}}
function compareSpools(left,right){{
  var a=spoolSortValue(left,state.spoolSort),b=spoolSortValue(right,state.spoolSort),result=0;
  if(typeof a==='number'&&typeof b==='number')result=a-b;
  else if(a<b)result=-1;
  else if(a>b)result=1;
  if(result===0)result=(Number(left.id)||0)-(Number(right.id)||0);
  return result*state.sortDirection;
}}
function renderSpools(){{
  var q=byId('search').value.toLowerCase().replace(/^\\s+|\\s+$/g,'');
  var body=byId('spools');
  var count=0;
  var spools=state.spools.slice().sort(compareSpools);
  var i,j;
  while(body.firstChild)body.removeChild(body.firstChild);
  updateFilterCounts();
  for(i=0;i<spools.length;i++){{
    var spool=spools[i];
    if(!spoolMatchesFilter(spool,state.spoolFilter))continue;
    if(JSON.stringify(spool).toLowerCase().indexOf(q)===-1)continue;
    count++;
    var row=document.createElement('tr');
    var loaded=spool.loaded&&spool.gate!=null?(spool.printer||'Printer')+' · Gate '+spool.gate:'—';
    var statusLabels={{checking:'Checking…',synced:'Synced',profile_missing:'Profile missing',update_required:'Update required',conflict:'Conflict',error:'Error'}};
    var columns=['','', 'filament','manufacturer','colour','nozzle','bed','remaining','location','loaded','sync'];
    var values=['#'+spool.id,spool.material,spool.name,spool.vendor,'',spool.nozzle_temperature==null?'—':spool.nozzle_temperature+' °C',spool.bed_temperature==null?'—':spool.bed_temperature+' °C','',spool.location||'—',loaded,statusLabels[spool.sync_status]||'Unknown'];
    for(j=0;j<values.length;j++){{
      var cell=document.createElement('td');
      if(columns[j])cell.setAttribute('data-column',columns[j]);
      if(j===0){{
        var spoolLink=document.createElement('button');spoolLink.className='spool-link';spoolLink.setAttribute('data-open-spool',spool.id);spoolLink.title='Open this spool in Spoolman';spoolLink.textContent='#'+spool.id+' ↗';cell.appendChild(spoolLink);
        var syncButton=document.createElement('button');syncButton.setAttribute('data-sync-spool',spool.id);syncButton.textContent='Sync';syncButton.title='Synchronize this spool and its shared Filament group';syncButton.disabled=state.busy;cell.appendChild(syncButton);
      }}else if(j===4){{
        var swatch=document.createElement('span');
        swatch.className='swatch';
        swatch.style.background=spool.color;
        cell.appendChild(swatch);
        cell.appendChild(document.createTextNode(spool.color));
      }}else if(j===7){{
        var gauge=document.createElement('span');gauge.className='table-gauge';
        var fill=document.createElement('span');fill.className='table-gauge-fill';
        var step=spool.remaining_step==null?0:Math.max(0,Math.min(100,spool.remaining_step));
        var hue=Math.max(0,Math.min(120,(step-10)/90*120));fill.style.width=step+'%';fill.style.background=spool.remaining_step==null?'#31516d':'hsl('+hue+',46%,30%)';
        gauge.title=spool.remaining_percent==null?'Remaining percentage unavailable':spool.remaining_percent+'% remaining; gauge shown in 10% steps';
        var gaugeCopy=document.createElement('span');gaugeCopy.className='table-gauge-copy';gaugeCopy.textContent=spool.remaining==null?'—':spool.remaining+' g';gauge.appendChild(fill);gauge.appendChild(gaugeCopy);cell.appendChild(gauge);
      }}else if(j===10){{
        var profile=document.createElement('span');profile.className='profile-status profile-'+(spool.sync_status||'unknown');profile.textContent=values[j];profile.title=spool.sync_warning||'';cell.appendChild(profile);
      }}else{{cell.textContent=values[j];}}
      row.appendChild(cell);
    }}
    body.appendChild(row);
  }}
  applyTableColumns();
  byId('empty').style.display=count>0?'none':'block';
}}
function gateIconUri(color,gate,empty){{
  if(!/^#[0-9a-fA-F]{{6}}$/.test(color||''))color='#FFFFFF';
  var filament=empty?'#555b63':color;
  var svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 72 58"><path d="M19 10h34l11 10v24l-8 8H16l-8-8V20z" fill="#292d33" stroke="#737983" stroke-width="3" stroke-linejoin="round"/><rect x="29" y="3" width="14" height="10" rx="4" fill="#181a1e" stroke="#858b94" stroke-width="2"/><path d="M36 5v44" fill="none" stroke="'+filament+'" stroke-width="5" stroke-linecap="round"/><path d="M26 25l5-7h10l5 7-3 10-7 4-7-4z" fill="#17191c" stroke="#969ca5" stroke-width="2"/><circle cx="36" cy="28" r="11" fill="#17191c" stroke="#969ca5" stroke-width="2"/><text x="36" y="33" text-anchor="middle" fill="#f2f3f5" font-family="Segoe UI,Arial,sans-serif" font-size="14" font-weight="700">'+gate+'</text><path d="M30 52h12l-3 5h-6z" fill="#17191c" stroke="#858b94" stroke-width="2" stroke-linejoin="round"/></svg>';
  return 'data:image/svg+xml;base64,'+window.btoa(svg);
}}
function renderLoadout(gates){{
  gates=gates||[];
  var body=byId('loadout');
  while(body.firstChild)body.removeChild(body.firstChild);
  var i;
  for(i=0;i<gates.length;i++){{
    var gate=gates[i];
    var empty=gate.empty===true;
    var low=!empty&&state.lowStockThreshold>0&&gate.remaining!=null&&gate.remaining<=state.lowStockThreshold;
    var problem=!empty&&!!gate.warning;
    var tile=document.createElement('article');tile.className='gate-tile'+(empty?' empty-gate':'')+(problem?' gate-problem':'');
    if(problem)tile.title=gate.warning;
    else if(low)tile.title='Low filament: '+gate.remaining+' g remaining (warning at '+state.lowStockThreshold+' g)';
    var status=document.createElement('span');status.className='gate-status';status.textContent=empty?'Empty':'Spool #'+gate.id;
    var image=document.createElement('img');image.className='gate-image';image.src=gateIconUri(gate.color,gate.gate,empty);image.alt='Gate '+gate.gate;
    var material=document.createElement('b');material.className='gate-material';material.textContent=empty?'—':(gate.material||'Unknown');
    var printer=document.createElement('span');printer.className='gate-printer';printer.textContent=gate.printer||'Printer';
    tile.appendChild(status);tile.appendChild(image);tile.appendChild(material);tile.appendChild(printer);
    if(!empty){{
      var gauge=document.createElement('span');gauge.className='gate-gauge';
      var fill=document.createElement('span');fill.className='gate-gauge-fill';
      var step=gate.remaining_step==null?0:Math.max(0,Math.min(100,gate.remaining_step));
      var hue=Math.max(0,Math.min(120,(step-10)/90*120));
      fill.style.width=step+'%';fill.style.background=gate.remaining_step==null?'#31516d':'hsl('+hue+',46%,30%)';
      gauge.title=gate.remaining_percent==null?'Remaining percentage unavailable':gate.remaining_percent+'% remaining; gauge shown in 10% steps';
      var copy=document.createElement('span');copy.className='gate-gauge-copy';
      if(low){{var lowLabel=document.createElement('span');lowLabel.className='gate-low-label';lowLabel.textContent='Low filament';copy.appendChild(lowLabel);}}
      var grams=document.createElement('span');grams.className='gate-grams';grams.textContent=gate.remaining==null?'— g':gate.remaining+' g';copy.appendChild(grams);
      gauge.appendChild(fill);gauge.appendChild(copy);tile.appendChild(gauge);
    }}
    body.appendChild(tile);
  }}
  byId('loadoutEmpty').style.display=gates.length?'none':'block';
}}
function synchronizationBannerText(reasons){{
  reasons=reasons||[];
  if(!reasons.length)return 'Changes detected — select Synchronize now to reconcile Orca and Spoolman.';
  var shown=reasons.slice(0,3);
  var message='Synchronization needed — '+shown.join(' | ');
  if(reasons.length>shown.length)message+=' | and '+(reasons.length-shown.length)+' more';
  return message;
}}
function applyState(data){{
  data=data||{{}};
  state.sharedSettings=data.shared_filament_settings!==false;
  byId('settingScopeDescription').textContent=state.sharedSettings
    ?'Shared mode: selected advanced values are stored on the Spoolman Filament and propagate to its spool profiles. Conflicting sibling edits are preserved.'
    :'Individual mode: selected advanced values are stored on each Spoolman spool. Other spools and shared Filament fields are left unchanged.';
  state.spools=data.spools||[];
  state.lowStockThreshold=data.low_stock_threshold==null?{DEFAULT_LOW_STOCK_THRESHOLD_GRAMS}:data.low_stock_threshold;
  state.tableColumns=data.spool_table_columns||state.tableColumns;
  var spoolIdEnabled=data.inject_spool_id_gcode!==false;
  byId('spoolIdGcode').checked=spoolIdEnabled;
  byId('spoolIdState').textContent=spoolIdEnabled?'Enabled':'Disabled';
  var columnInputs=document.querySelectorAll('[data-table-column]');
  var columnInputIndex;
  for(columnInputIndex=0;columnInputIndex<columnInputs.length;columnInputIndex++)columnInputs[columnInputIndex].checked=state.tableColumns.indexOf(columnInputs[columnInputIndex].getAttribute('data-table-column'))!==-1;
  var connected=data.connected===true;
  byId('allowConnection').hidden=!data.permission_required;
  byId('status').textContent=data.permission_required?'Permission required':data.connection_checked===false?'Connecting…':(connected?'Connection OK':'Not connected');
  state.connected=connected;renderStatusPip();
  byId('connectionDetail').textContent=data.detail||'';
  byId('connectionDetail').className='muted';
  byId('restartBanner').style.display=data.restart_required===true?'flex':'none';
  byId('syncBanner').style.display=data.synchronization_required===true&&data.restart_required!==true?'flex':'none';
  byId('syncText').textContent=synchronizationBannerText(data.synchronization_reasons);
  var availableUpdate=data.available_update||'';
  byId('updateBanner').style.display=availableUpdate?'flex':'none';
  byId('updateText').textContent=availableUpdate?('PipSpool '+availableUpdate+' is available — open File → Plugins to update.'):'';
  var report=data.last_report||null;
  byId('active').textContent=report?report.active_spools:state.spools.length;
  var changedSpools=0;
  if(report){{
    if(report.changed_spools!=null)changedSpools=report.changed_spools;
    else if(report.changes){{
      var changedIds={{}},changeIndex,changeMatch;
      for(changeIndex=0;changeIndex<report.changes.length;changeIndex++){{changeMatch=/^Spool #(\\d+):/.exec(report.changes[changeIndex]);if(changeMatch)changedIds[changeMatch[1]]=true;}}
      changedSpools=Object.keys(changedIds).length;
    }}
  }}
  byId('changed').textContent=report?changedSpools:'—';
  byId('errors').textContent=report?(report.errors||[]).length:'—';
  if(report){{
    var reportText=changedSpools?(changedSpools+' spool profile'+(changedSpools===1?'':'s')+' changed.'):'No spool profiles needed changes.';
    if(report.changes&&report.changes.length)reportText+='\\n\\n• '+report.changes.join('\\n• ');
    if(report.errors&&report.errors.length)reportText+='\\n\\nErrors:\\n• '+report.errors.join('\\n• ');
    byId('report').textContent=reportText;
  }}else{{byId('report').textContent='No synchronization report yet.';}}
  var selected=data.selected_fields||[];
  var inputs=document.querySelectorAll('.choices input');
  var i;
  for(i=0;i<inputs.length;i++)inputs[i].checked=selected.indexOf(inputs[i].value)!==-1;
  updateCounts();
  renderSpools();
  renderLoadout(data.gates);
  setBusy(false);
}}
function hostMessage(data){{
  if(!data)return;
  if(data.type==='theme'){{
    themeTransfer={{token:data.theme_token,assets:{{}},completed:{{}}}};
    applyTheme(data.theme);return;
  }}
  if(data.type==='theme-background'||data.type==='theme-logo'||data.type==='theme-happy'||data.type==='theme-sad'){{
    if(!themeTransfer||data.theme_token!==themeTransfer.token)return;
    var asset={{'theme-logo':'logo_data_uri','theme-happy':'happy_data_uri','theme-sad':'sad_data_uri','theme-background':'background_data_uri'}}[data.type];
    if(themeTransfer.completed[asset])return;
    var transfer=themeTransfer.assets[asset]||(themeTransfer.assets[asset]={{parts:[],total:0}});
    if(data.index!==transfer.parts.length||data.total<1||data.total>100||data.index>=data.total)return;
    if(typeof data.chunk!=='string'||data.chunk.length>65536)return;
    if(transfer.total&&transfer.total!==data.total)return;
    transfer.total=data.total;transfer.parts.push(data.chunk);
    if(transfer.parts.length===data.total){{
      var image=transfer.parts.join('');
      if(/^data:image\\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(image)){{
        themeData.themes[themeData.selected][asset]=image;applyTheme(themeData);
      }}
      themeTransfer.completed[asset]=true;delete themeTransfer.assets[asset];
    }}
    return;
  }}
  if(data.type==='state'||data.type==='sync-result'){{
    applyState(data);
    if(data.page_timing_token){{var timingToken=data.page_timing_token;
      window.requestAnimationFrame(function(){{window.requestAnimationFrame(function(){{send('page-rendered',{{token:timingToken}});}});}});}}
  }}
  else if(data.type==='error'){{setBusy(false);byId('connectionDetail').textContent=data.message;byId('connectionDetail').className='muted error';}}
  else if(data.type==='notice'){{setBusy(false);byId('connectionDetail').textContent=data.message;}}
}}
function startBridge(attempt){{
  attempt=attempt||0;
  if(window.orca&&typeof window.orca.postMessage==='function'&&typeof window.orca.onMessage==='function'){{
    bridgeReady=true;
    window.orca.onMessage(hostMessage);
    window.orca.postMessage({{action:'ready'}});
    return;
  }}
  if(attempt<100)window.setTimeout(function(){{startBridge(attempt+1);}},100);
  else{{byId('connectionDetail').textContent='Live controls unavailable in this Orca page.';byId('connectionDetail').className='muted error';}}
}}
byId('refresh').onclick=function(){{setBusy(true);send('refresh');}};
var defaultPageLogo=byId('pageLogo').src;
var themeTransfer=null;
var themeData={page_themes};
function renderStatusPip(){{
  var theme=themeData&&themeData.themes[themeData.selected]||{{}};
  byId('statusPip').src=state.connected===true?
    (theme.happy_data_uri||{json.dumps(PIP_HAPPY_DATA_URI)}):
    (theme.sad_data_uri||{json.dumps(PIP_SAD_DATA_URI)});
}}
function applyTheme(data){{
  themeData=data;
  var select=byId('themeSelect');
  select.innerHTML='';
  Object.keys(data.themes).forEach(function(id){{
    var option=document.createElement('option');option.value=id;
    var item=data.themes[id];
    option.textContent=item.name+(item.filename?' ('+item.filename+')':'');select.appendChild(option);
  }});
  select.value=data.selected;select.disabled=data.locked===true;
  select.title=data.locked?'A special theme is active today. Your saved theme returns afterwards.':'Custom theme folder: '+data.folder;
  var theme=data.themes[data.selected];
  byId('pageLogo').src=theme.logo_data_uri||defaultPageLogo;
  renderStatusPip();
  var c=theme.colors;
  var vars={{'orca-bg':'background','orca-fg':'text','orca-muted':'muted','orca-accent':'accent','orca-accent-fg':'accent_text','orca-border':'border','panel':'surface','panel2':'surface_alt','ivory':'heading','cyan':'highlight','good':'good','warn':'warning','amber':'warning','bad':'danger'}};
  Object.keys(vars).forEach(function(key){{document.body.style.setProperty('--'+key,c[vars[key]]);}});
  byId('themeStyle').textContent=data.selected==='classic'?'':
    'html,body#pipspoolThemeRoot{{background:'+c.background+'}}'+
    'body#pipspoolThemeRoot .card,body#pipspoolThemeRoot .spool-wrap thead th{{background:'+c.surface+';border-color:'+c.border+'}}'+
    'body#pipspoolThemeRoot button,body#pipspoolThemeRoot select,body#pipspoolThemeRoot input[type=search],body#pipspoolThemeRoot .field-tab,body#pipspoolThemeRoot .column-choices,body#pipspoolThemeRoot .spool-id-control,body#pipspoolThemeRoot .profile-status{{background:'+c.surface_alt+';color:'+c.text+';border-color:'+c.border+'}}'+
    'body#pipspoolThemeRoot .primary,body#pipspoolThemeRoot .field-tab.active,body#pipspoolThemeRoot .spool-filter.active{{background:'+c.accent+';color:'+c.accent_text+'}}'+
    'body#pipspoolThemeRoot .metric,body#pipspoolThemeRoot .report,body#pipspoolThemeRoot .filter-count,body#pipspoolThemeRoot .tab-count,body#pipspoolThemeRoot .columns-menu summary{{background:'+c.surface_alt+';color:'+c.text+';border-color:'+c.border+'}}'+
    'body#pipspoolThemeRoot .gate-tile{{background:'+c.surface_alt+';border-color:'+c.border+';box-shadow:0 4px 12px rgba(0,0,0,.18)}}'+
    'body#pipspoolThemeRoot .gate-status{{color:'+c.highlight+'}}'+
    'body#pipspoolThemeRoot .gate-material{{color:'+c.text+'}}'+
    'body#pipspoolThemeRoot .gate-printer{{color:'+c.muted+'}}'+
    'body#pipspoolThemeRoot .gate-gauge{{border-color:'+c.border+'}}'+
    'body#pipspoolThemeRoot .gate-tile.empty-gate{{background:'+c.surface+';opacity:1}}'+
    'body#pipspoolThemeRoot .empty-gate .gate-image{{opacity:.55}}'+
    'body#pipspoolThemeRoot .empty-gate .gate-status,body#pipspoolThemeRoot .empty-gate .gate-material{{color:'+c.muted+'}}'+
    'body#pipspoolThemeRoot .gate-tile.gate-problem{{border-color:'+c.danger+';box-shadow:0 0 0 1px '+c.danger+'}}'+
    'body#pipspoolThemeRoot .choice,body#pipspoolThemeRoot .danger-zone p{{color:'+c.text+'}}'+
    'body#pipspoolThemeRoot .choice:hover{{background:'+c.surface_alt+'}}'+
    'body#pipspoolThemeRoot .restart-banner,body#pipspoolThemeRoot .sync-banner,body#pipspoolThemeRoot .update-banner{{background:'+c.surface_alt+';color:'+c.text+'}}'+
    'body#pipspoolThemeRoot .profile-synced{{color:'+c.good+'}}'+
    'body#pipspoolThemeRoot .profile-conflict,body#pipspoolThemeRoot .profile-error,body#pipspoolThemeRoot .profile-profile_missing{{color:'+c.danger+';border-color:'+c.danger+'}}'+
    'body#pipspoolThemeRoot td,body#pipspoolThemeRoot th{{border-color:'+c.border+'}}'+
    'body#pipspoolThemeRoot button:hover,body#pipspoolThemeRoot .choice:hover{{background:'+c.surface+';color:'+c.text+';border-color:'+c.accent+'}}'+
    'body#pipspoolThemeRoot .primary:hover,body#pipspoolThemeRoot .field-tab.active:hover,body#pipspoolThemeRoot .spool-filter.active:hover{{background:'+c.accent+';color:'+c.accent_text+'}}'+
    'body#pipspoolThemeRoot select option{{background:'+c.surface_alt+';color:'+c.text+'}}'+
    'body#pipspoolThemeRoot .spool-link{{color:'+c.highlight+'!important}}';
  // Inline background properties beat palette shorthands, and are always cleared
  // when switching back to a theme without an image.
  ['background-image','background-size','background-position','background-attachment','background-repeat'].forEach(function(key){{document.body.style.removeProperty(key);}});
  if(theme.background_data_uri){{
    var rgb=[1,3,5].map(function(i){{return parseInt(c.background.slice(i,i+2),16);}});
    var veil='rgba('+rgb.join(',')+','+(1-theme.background_opacity)+')';
    document.body.style.setProperty('background-image','linear-gradient('+veil+','+veil+'),url("'+theme.background_data_uri+'")');
    document.body.style.setProperty('background-size','cover');
    document.body.style.setProperty('background-position','center');
    document.body.style.setProperty('background-attachment','fixed');
    document.body.style.setProperty('background-repeat','no-repeat');
  }}
}}
applyTheme(themeData);
byId('themeSelect').onchange=function(){{send('set-theme',{{theme:this.value}});}};
function themeCalendarKey(){{
  var now=new Date();return now.getFullYear()+'-'+now.getMonth()+'-'+now.getDate();
}}
var lastThemeCalendarKey=themeCalendarKey();
function checkThemeSeason(){{
  var key=themeCalendarKey();
  if(key!==lastThemeCalendarKey&&bridgeReady){{
    lastThemeCalendarKey=key;send('check-theme-season');
  }}
}}
window.setInterval(checkThemeSeason,60000);
document.addEventListener('visibilitychange',function(){{if(!document.hidden)checkThemeSeason();}});

byId('diagnostics').onclick=function(){{send('open-diagnostics');}};
byId('allowConnection').onclick=function(){{send('allow-connection');}};
byId('settings').onclick=function(){{send('open-settings');}};
byId('feedback').onclick=function(){{send('feedback');}};
byId('sync').onclick=function(){{setBusy(true);send('sync',{{selected_fields:selectedFields()}});}};
byId('spoolIdGcode').onchange=function(){{
  var enabled=this.checked;
  byId('spoolIdState').textContent=enabled?'Enabled':'Disabled';
  send('save-spool-id-gcode',{{enabled:enabled}});
}};
byId('saveFields').onclick=function(){{setBusy(true);send('save-fields',{{selected_fields:selectedFields()}});}};
byId('cleanup').onclick=function(){{if(window.confirm('Permanently delete every unselected PipSpool field and its values from all Spoolman filaments?')){{setBusy(true);send('cleanup',{{selected_fields:selectedFields()}});}}}};
byId('search').oninput=renderSpools;
var spoolFilterButtons=document.querySelectorAll('[data-spool-filter]');
var spoolFilterIndex;
for(spoolFilterIndex=0;spoolFilterIndex<spoolFilterButtons.length;spoolFilterIndex++)spoolFilterButtons[spoolFilterIndex].onclick=function(){{
  state.spoolFilter=this.getAttribute('data-spool-filter')||'all';
  var i;
  for(i=0;i<spoolFilterButtons.length;i++){{
    var active=spoolFilterButtons[i]===this;
    spoolFilterButtons[i].classList.toggle('active',active);
    spoolFilterButtons[i].setAttribute('aria-pressed',active?'true':'false');
  }}
  renderSpools();
}};
byId('spoolSort').onchange=function(){{state.spoolSort=this.value||'id';renderSpools();}};
byId('sortDirection').onclick=function(){{
  state.sortDirection*=-1;
  var ascending=state.sortDirection===1;
  this.textContent=ascending?'↑':'↓';
  this.title=ascending?'Ascending order':'Descending order';
  this.setAttribute('aria-label',this.title);
  renderSpools();
}};
byId('spools').onclick=function(event){{
  var target=event.target;
  if(target&&target.getAttribute&&target.getAttribute('data-sync-spool')){{
    if(state.busy)return;
    var spoolId=Number(target.getAttribute('data-sync-spool'));
    if(window.confirm('Synchronize spool #'+spoolId+'? '+(state.sharedSettings?'With advanced fields enabled, all profiles sharing its Spoolman Filament are reconciled too. ':'Individual advanced settings apply to this spool only. ')+'Unrelated spools and archived profiles are unchanged.')){{setBusy(true);send('sync-spool',{{spool_id:spoolId,selected_fields:selectedFields()}});}}
    return;
  }}
  if(target&&target.getAttribute&&target.getAttribute('data-open-spool'))send('open-spool',{{spool_id:target.getAttribute('data-open-spool')}});
}};
var tableColumnInputs=document.querySelectorAll('[data-table-column]');
var tableColumnIndex;
for(tableColumnIndex=0;tableColumnIndex<tableColumnInputs.length;tableColumnIndex++)tableColumnInputs[tableColumnIndex].onchange=function(){{
  state.tableColumns=selectedTableColumns();
  applyTableColumns();
  send('save-columns',{{spool_table_columns:state.tableColumns}});
}};
var fieldInputs=document.querySelectorAll('.choices input');
var fieldIndex;
for(fieldIndex=0;fieldIndex<fieldInputs.length;fieldIndex++)fieldInputs[fieldIndex].onchange=updateCounts;
var fieldTabs=document.querySelectorAll('[data-field-tab]');
var fieldTabIndex;
for(fieldTabIndex=0;fieldTabIndex<fieldTabs.length;fieldTabIndex++)fieldTabs[fieldTabIndex].onclick=function(){{
  var group=this.getAttribute('data-field-tab');
  var tabIndex,panelIndex;
  for(tabIndex=0;tabIndex<fieldTabs.length;tabIndex++){{
    var selected=fieldTabs[tabIndex]===this;
    fieldTabs[tabIndex].classList.toggle('active',selected);
    fieldTabs[tabIndex].setAttribute('aria-selected',selected?'true':'false');
  }}
  var panels=document.querySelectorAll('[data-field-panel]');
  for(panelIndex=0;panelIndex<panels.length;panelIndex++){{
    var visible=panels[panelIndex].getAttribute('data-field-panel')===group;
    panels[panelIndex].classList.toggle('active',visible);
    panels[panelIndex].hidden=!visible;
  }}
}};
var groupButtons=document.querySelectorAll('[data-group-action]');
var groupIndex;
for(groupIndex=0;groupIndex<groupButtons.length;groupIndex++){{
  groupButtons[groupIndex].onclick=function(){{
    var panel=this.closest('.field-panel');
    var inputs=panel?panel.querySelectorAll('.choices input'):[];
    var checked=this.getAttribute('data-group-action')==='all';
    var i;
    for(i=0;i<inputs.length;i++)inputs[i].checked=checked;
    updateCounts();
  }};
}}
applyState({initial_state_json});
startBridge();
</script></main></body></html>"""


PAGES_BASE = getattr(getattr(orca, "pages", None), "PagesPluginCapabilityBase", None)

if PAGES_BASE is not None:
    class PipSpoolPageCapability(PAGES_BASE):
        def __init__(self):
            super().__init__()
            LIFECYCLE_COORDINATOR.register_page(self)

        def on_unload(self):
            LIFECYCLE_COORDINATOR.unregister_page(self)
            self._diagnostic_identity = None
            self._diagnostic_preview = None
            window = getattr(self, "_diagnostic_window", None)
            self._diagnostic_window = None
            if window is not None and window.is_open():
                window.close()

        def get_name(self):
            return "PipSpool"

        def get_ui(self):
            return pipspool_page_html(
                quiet_page_state()
            )

        def get_icon(self):
            try:
                if (
                    not PAGE_ICON_PATH.exists()
                    or PAGE_ICON_PATH.read_text(encoding="utf-8")
                    != PIPSPOOL_PAGE_ICON_SVG
                ):
                    PAGE_ICON_PATH.parent.mkdir(parents=True, exist_ok=True)
                    PAGE_ICON_PATH.write_text(
                        PIPSPOOL_PAGE_ICON_SVG, encoding="utf-8"
                    )
                return str(PAGE_ICON_PATH)
            except Exception as exc:
                log(f"[PAGE ICON ERROR] {exc}")
                return ""

        def _post_state(self, message_type="state", notice=None, prefetched_inventory=None):
            self._state_generation = getattr(self, "_state_generation", 0) + 1
            generation = self._state_generation
            started = time.perf_counter()
            def deliver(payload, stage):
                if generation != self._state_generation:
                    return
                payload["type"] = message_type
                payload["page_timing_token"] = str(generation) + ":" + stage
                self._page_timings = getattr(self, "_page_timings", {})
                self._page_timings[payload["page_timing_token"]] = time.perf_counter()
                while len(self._page_timings) > 20:
                    self._page_timings.pop(next(iter(self._page_timings)))
                before = time.perf_counter()
                self.post_message(payload)
                log(f"[PAGE TIMING] stage={stage}; build_to_post={before - started:.3f}s; post={time.perf_counter() - before:.3f}s")
            payload = (pipspool_page_state(notice, on_inventory=lambda value: deliver(value, "inventory"), prefetched_inventory=prefetched_inventory)
                       if _MANUAL_USE_STARTED else quiet_page_state())
            if notice:
                payload["detail"] = notice
            if payload.get("permission_required"):
                pause_background_updates()
                self._connection_ready_url = None
            deliver(payload, "profiles")

        def _diagnostic_post(self, payload):
            if hasattr(self, "_diagnostic_window"):
                window = self._diagnostic_window
                if window is not None and window.is_open():
                    window.post(payload)
            else:
                self.post_message(payload)

        def _open_diagnostics_window(self):
            previous = getattr(self, "_diagnostic_window", None)
            if previous is not None and previous.is_open():
                previous.close()
            self._diagnostic_preview = None
            identity = object()
            self._diagnostic_identity = identity
            def closed():
                if self._diagnostic_identity is identity:
                    self._diagnostic_identity = None
                    self._diagnostic_window = None
                    self._diagnostic_preview = None
            def message(data):
                if self._diagnostic_identity is not identity or not isinstance(data, dict):
                    return
                action = data.get("action")
                if action == "diagnostic-ready":
                    for payload in theme_transfer_messages(theme_state()):
                        if payload["type"] in ("theme", "theme-background"):
                            self._diagnostic_post(payload)
                    self.on_message({"action": "diagnostic-preview"})
                elif action in ("diagnostic-preview", "diagnostic-export"):
                    self.on_message(data)
            self._diagnostic_window = orca.host.ui.create_window(
                html=diagnostic_window_html(), title="PipSpool Diagnostics",
                on_message=message, on_close=closed)

        def _post_theme(self, payload, force=False):
            if not force and getattr(self, "_last_theme_payload", None) == payload:
                return
            for message in theme_transfer_messages(payload):
                self.post_message(message)
            # Transfer generation does not mutate the original payload.
            self._last_theme_payload = payload

        def _post_initial_state(self):
            self._connect_from_ui()

        def _connection_permission_state(self):
            pause_background_updates()
            self._connection_ready_url = None
            payload = quiet_page_state()
            payload.update(connection_checked=True, permission_required=True,
                detail="Orca has not approved this connection. Click Allow connection to request access, then approve Orca's prompts. Nothing will be synchronized.")
            self.post_message(payload)

        def _connect_from_ui(self):
            # A genuine read in the host's page callback: alpha can prompt here.
            # Do not fabricate audit events or replay mutations to acquire grants.
            settings = load_settings()
            started = time.perf_counter()
            try:
                spools = SpoolmanClient(settings["spoolman_url"]).active_spools()
            except PermissionError:
                self._connection_permission_state()
                return
            except Exception as exc:
                payload = quiet_page_state()
                payload.update(connection_checked=True, detail=SPOOLMAN_CONNECTION_MESSAGE)
                self.post_message(payload)
                log(f"[PAGE CONNECTION ERROR] {type(exc).__name__}")
                return
            log(f"[PAGE TIMING] ui_connection={time.perf_counter() - started:.3f}s")
            self._connection_ready_url = settings["spoolman_url"]
            pending = {int(item["id"]): {"status": "checking", "warning": "Checking Orca profile…"}
                       for item in spools if item.get("id") is not None}
            self.post_message(inventory_page_state(settings, spools, pending, True,
                f"Found {len(spools)} active spool(s). Checking Orca profiles…", pending=True))
            self._background(lambda: None, prefetched_inventory=(settings, spools))

        def _refresh_from_lifecycle(self):
            # Called by the coordinator's debounce worker, never directly from
            # Orca's lifecycle callback. post_message marshals delivery to UI.
            if _MANUAL_USE_STARTED:
                self._post_state()

        def _background(self, operation, prefetched_inventory=None):
            queued_at = time.perf_counter()
            def work():
                log(f"[PAGE TIMING] worker_queue={time.perf_counter() - queued_at:.3f}s")
                try:
                    notice = operation()
                    self._post_state("sync-result", notice, prefetched_inventory=prefetched_inventory)
                except PermissionError:
                    self._connection_permission_state()
                except Exception as exc:
                    log(f"[PAGE ERROR] {exc}")
                    self.post_message({"type": "error", "message": str(exc)})
            if not start_background_thread(
                threading.Thread(target=work, daemon=True),
                "PipSpool page action",
            ):
                self._connection_permission_state()
                self.post_message({
                    "type": "error",
                    "message": THREAD_PERMISSION_RETRY_MESSAGE,
                })

        def on_message(self, message):
            if not isinstance(message, dict):
                return
            action = message.get("action")
            if action == "page-rendered":
                token = message.get("token")
                sent = getattr(self, "_page_timings", {}).pop(token, None) if isinstance(token, str) else None
                if sent is not None:
                    log(f"[PAGE TIMING] stage={token}; post_to_paint_ack={time.perf_counter() - sent:.3f}s")
                return
            if action in ("ready", "refresh", "sync", "sync-spool", "save-fields", "cleanup"):
                begin_manual_use()
            if action == "ready":
                self._post_initial_state()
            if action in ("ready", "refresh", "check-theme-season"):
                self._post_theme(theme_state(), force=action == "ready")
            if action == "ready":
                pass
            elif action == "open-diagnostics":
                try:
                    self._open_diagnostics_window()
                except Exception as exc:
                    self.post_message({"type": "error", "message": "Could not open Diagnostics: " + type(exc).__name__})
            elif action == "diagnostic-preview":
                self._diagnostic_preview = None
                try:
                    settings = load_settings()
                    fields = tuple(key for key in ORCA_SETTINGS if key in settings.get("selected_fields", []))
                    live = host_filament_preset_snapshot(fields)
                    report = build_diagnostic_report(live)
                    self._diagnostic_preview = json.dumps(report, indent=2, ensure_ascii=True)
                    self._diagnostic_post({"type": "diagnostic-preview", "text": self._diagnostic_preview})
                except Exception as exc:
                    self._diagnostic_post({"type": "error", "message": "Diagnostic collection failed: " + type(exc).__name__})
            elif action == "diagnostic-export":
                try:
                    preview = getattr(self, "_diagnostic_preview", None)
                    if preview is None:
                        raise ValueError("Preview a report first")
                    destination = message.get("path")
                    if not isinstance(destination, str) or not destination.strip():
                        raise ValueError("Choose a destination path and filename first")
                    path = Path(destination.strip()).expanduser()
                    if not path.is_absolute() or path.suffix.lower() != ".json":
                        raise ValueError("Use a full absolute path ending in .json")
                    if not path.parent.is_dir():
                        raise ValueError("The destination folder does not exist")
                    with path.open("x", encoding="utf-8") as stream:
                        stream.write(preview)
                    self._diagnostic_post({"type": "diagnostic-export", "message": "Saved report to " + str(path)})
                except FileExistsError:
                    self._diagnostic_post({"type": "diagnostic-export", "message": "That file already exists. Choose another filename; nothing was overwritten."})
                except ValueError as exc:
                    self._diagnostic_post({"type": "diagnostic-export", "message": str(exc)})
                except PermissionError:
                    self._diagnostic_post({"type": "diagnostic-export", "message": "Access was denied. Approve Orca's file permission request if shown, then retry, or choose another folder."})
                except Exception as exc:
                    self._diagnostic_post({"type": "diagnostic-export", "message": "Could not export report: " + type(exc).__name__})
            elif action == "set-theme":
                try:
                    self._post_theme(save_theme(message.get("theme")))
                except (OSError, ValueError) as exc:
                    self.post_message({"type": "error", "message": str(exc)})
            elif action == "open-settings":
                try:
                    if SETTINGS_CAPABILITY is None:
                        raise RuntimeError("PipSpool Settings is not loaded. Enable it in File → Plugins, then retry.")
                    # Reuse the host-registered instance so capability configuration
                    # keeps its proper identity. Do not construct a new capability.
                    SETTINGS_CAPABILITY._open_settings_window()
                except Exception as exc:
                    self.post_message({"type": "error", "message": f"Could not open PipSpool Settings: {exc}"})
            elif action == "feedback":
                try:
                    if not webbrowser.open_new_tab(FEEDBACK_URL):
                        log("[FEEDBACK] The system browser did not accept the GitHub Issues URL.")
                except Exception as exc:
                    log(f"[FEEDBACK ERROR] {exc}")
            elif action == "open-spool":
                try:
                    spool_id = int(message.get("spool_id"))
                    if spool_id <= 0:
                        raise ValueError("Spool ID must be positive")
                    spoolman_url = normalize_url(
                        load_settings().get("spoolman_url", DEFAULT_SPOOLMAN_URL)
                    )
                    target = f"{spoolman_url}/?sel=spool:{spool_id}"
                    if not webbrowser.open_new_tab(target):
                        log(
                            "[OPEN SPOOL] The system browser did not accept "
                            f"the Spoolman URL for spool #{spool_id}."
                        )
                except (TypeError, ValueError) as exc:
                    log(f"[OPEN SPOOL ERROR] Invalid spool ID: {exc}")
                except Exception as exc:
                    log(f"[OPEN SPOOL ERROR] {exc}")
            elif action == "allow-connection":
                self._connect_from_ui()
            elif action == "refresh":
                settings = load_settings()
                if getattr(self, "_connection_ready_url", None) != settings["spoolman_url"]:
                    self._connect_from_ui()
                else:
                    self._background(lambda: None)
            elif action == "save-fields":
                selected, _remove = parse_field_config({"selected_fields": message.get("selected_fields", [])})
                live_preset_values = host_filament_preset_snapshot(selected)
                def save_fields():
                    created, populated = save_advanced_field_selection(
                        selected, live_preset_values
                    )
                    detail = (
                        f" Filled Orca values for {populated} Spoolman filament(s)."
                        if populated else " All existing values were already populated."
                    )
                    return (
                        f"Saved {len(selected)} selected advanced field(s). "
                        f"Created {created} field(s)." + detail
                    )
                self._background(save_fields)
            elif action == "save-columns":
                columns = message.get("spool_table_columns")
                if not isinstance(columns, list):
                    columns = []
                selected_columns = [
                    column for column in SPOOL_TABLE_COLUMNS if column in columns
                ]
                save_settings({"spool_table_columns": selected_columns})
            elif action == "save-spool-id-gcode":
                enabled = message.get("enabled") is True
                save_settings({"inject_spool_id_gcode": enabled})
                notice = (
                    "Active spool G-code enabled. Synchronize to update filament profiles."
                    if enabled else
                    "Active spool G-code disabled. Synchronize to remove PipSpool's managed command."
                )
                self._post_state("state", notice)
            elif action in ("sync", "sync-spool"):
                selected, _remove = parse_field_config({"selected_fields": message.get("selected_fields", [])})
                live_preset_values = host_filament_preset_snapshot(selected)
                target_spool_id = message.get("spool_id") if action == "sync-spool" else None
                if action == "sync-spool" and (isinstance(target_spool_id, bool) or not isinstance(target_spool_id, int) or target_spool_id <= 0):
                    self.post_message({"type": "error", "message": "Invalid spool ID"})
                    return
                def synchronize():
                    report, _spools = sync_with_spoolman(
                        selected, live_preset_values=live_preset_values,
                        spool_id=target_spool_id,
                    )
                    suffix = " Restart OrcaSlicer to load changed presets." if report.restart_required else ""
                    return ("Synchronization completed with errors. Review Last synchronization." if report.errors else "Synchronization completed.") + suffix
                self._background(synchronize)
            elif action == "cleanup":
                def cleanup():
                    selected, _remove = parse_field_config({"selected_fields": message.get("selected_fields", [])})
                    save_settings({"selected_fields": list(selected)})
                    settings = load_settings()
                    if not shared_filament_settings(settings):
                        raise ValueError("Shared field cleanup is unavailable in individual mode")
                    removed = SpoolmanClient(settings["spoolman_url"]).remove_unselected_orca_filament_fields(selected)
                    return f"Removed {removed} unselected PipSpool field(s)."
                self._background(cleanup)


def settings_window_state() -> dict[str, Any]:
    settings = load_settings()
    lifecycle = LIFECYCLE_COORDINATOR.diagnostics()
    return {
        "type": "settings-state",
        "profile_name_template": profile_name_template(settings),
        "spool_id_command_template": spool_id_command_template(settings),
        "spoolman_url": settings.get("spoolman_url", DEFAULT_SPOOLMAN_URL),
        "shared_filament_settings": shared_filament_settings(settings),
        "show_pipspool_page": settings.get("show_pipspool_page", True) is not False,
        "low_stock_threshold_grams": low_stock_threshold(settings),
        "lifecycle_supported": lifecycle["supported"],
        "lifecycle_mode": lifecycle["mode"],
    }


class SettingsCapability(orca.script.ScriptPluginCapabilityBase):
    def get_name(self):
        return "PipSpool Settings"

    def _restore_host_settings(self) -> bool:
        """Restore user settings from Orca's supported capability config."""
        getter = getattr(self, "get_config", None)
        if not callable(getter):
            return False
        try:
            stored = getter()
            stored = json.loads(stored) if isinstance(stored, str) else stored
            if not isinstance(stored, dict):
                return False
            restored: dict[str, Any] = {}
            if isinstance(stored.get("shared_filament_settings"), bool):
                restored["shared_filament_settings"] = stored["shared_filament_settings"]
            if "spool_id_command_template" in stored:
                restored["spool_id_command_template"] = spool_id_command_template(stored)
            if "profile_name_template" in stored:
                restored["profile_name_template"] = profile_name_template(stored)
            if "spoolman_url" in stored:
                restored["spoolman_url"] = normalize_url(stored["spoolman_url"])
            if isinstance(stored.get("show_pipspool_page"), bool):
                restored["show_pipspool_page"] = stored["show_pipspool_page"]
            threshold = numeric(stored.get("low_stock_threshold_grams"))
            if threshold is not None and threshold >= 0:
                restored["low_stock_threshold_grams"] = round(threshold, 1)
            if not restored:
                return False
            HOST_USER_SETTINGS.clear()
            HOST_USER_SETTINGS.update(restored)
            try:
                save_settings(restored)
            except OSError as exc:
                # The host configuration remains available even if a Linux
                # installation cannot update PipSpool's legacy shared file.
                log(f"[SETTINGS FILE MIRROR] {exc}")
            return "spoolman_url" in restored
        except (OSError, TypeError, ValueError, json.JSONDecodeError) as exc:
            log(f"[HOST SETTINGS LOAD] {exc}")
            return False

    def _save_host_settings(self, update: dict[str, Any]) -> bool:
        """Persist user settings through Orca and refresh the runtime cache."""
        saver = getattr(self, "save_config", None)
        if not callable(saver):
            return False
        current = load_settings()
        host_settings = {
            key: current[key]
            for key in HOST_CONFIG_KEYS
            if key in current
        }
        host_settings.update({key: update[key] for key in HOST_CONFIG_KEYS if key in update})
        try:
            if not saver(json.dumps(host_settings, separators=(",", ":"))):
                return False
        except Exception as exc:
            log(f"[HOST SETTINGS SAVE] {exc}")
            return False
        HOST_USER_SETTINGS.clear()
        HOST_USER_SETTINGS.update(host_settings)
        return True

    def on_load(self):
        restored = self._restore_host_settings()
        if not restored:
            # The host has finished registration and permission approval. Legacy
            # discovery/migration belongs here, before checking whether setup exists.
            load_settings()
        if not restored and has_saved_settings():
            # Migrate existing PipSpool installations into Orca's durable
            # capability configuration without making the user re-enter data.
            migrated_settings = load_settings()
            self._save_host_settings(migrated_settings)
            if migrated_settings.get("show_pipspool_page", True) is False:
                log("[PAGE VISIBILITY] Migrated hidden page preference; reload PipSpool to apply.")
        elif not restored:
            self._open_settings_window()
        global SETTINGS_CAPABILITY
        SETTINGS_CAPABILITY = self

    def on_unload(self):
        global SETTINGS_CAPABILITY
        if SETTINGS_CAPABILITY is self:
            SETTINGS_CAPABILITY = None

    def execute(self):
        self._open_settings_window()
        return orca.ExecutionResult.success("PipSpool settings opened")

    def _open_settings_window(self):
        load_builtin_artwork()
        self._restore_host_settings()
        current_settings = load_settings()
        current_url = current_settings.get("spoolman_url", DEFAULT_SPOOLMAN_URL)
        shared_mode = shared_filament_settings(current_settings)
        show_page = current_settings.get("show_pipspool_page", True) is not False
        current_low_stock_threshold = low_stock_threshold(current_settings)
        safe_current_url = escape(str(current_url), quote=True)
        safe_default_url = escape(DEFAULT_SPOOLMAN_URL, quote=True)
        safe_name_template = escape(profile_name_template(current_settings), quote=True)
        safe_spool_command = escape(spool_id_command_template(current_settings), quote=True)
        show_page_checked = " checked" if show_page else ""
        safe_low_stock_threshold = escape(f"{current_low_stock_threshold:g}", quote=True)
        html = f"""<!doctype html>
<html><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>
:root {{ color-scheme:dark; --page:#202124; --panel:#292a2d; --field:#1f2022;
  --line:#55585d; --text:#f1f3f4; --muted:#aeb4ba; --accent:#37c9da;
  --accent-hover:#51d6e5; }}
* {{ box-sizing:border-box; }}
body {{ margin:0; padding:28px; background:var(--page); color:var(--text);
  font:14px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif; }}
.header {{ display:flex; align-items:center; gap:16px; margin-bottom:20px; }}
.logo {{ width:64px; height:64px; flex:0 0 64px; object-fit:contain;
  filter:drop-shadow(0 4px 8px rgba(0,0,0,.28)); }}
h1 {{ margin:0; font-size:21px; line-height:1.15; }}
.subtitle {{ margin:4px 0 0; color:var(--muted); font-size:13px; }}
.card {{ padding:20px; border:1px solid #3d3f43; border-radius:12px; background:var(--panel); }}
.sync-card,.display-card {{ margin-top:12px; }}
.card-title {{ margin:0 0 5px; font-size:15px; font-weight:650; }}
.help {{ margin:0 0 17px; color:var(--muted); }}
label {{ display:block; margin-bottom:7px; font-weight:600; }}
input {{ width:100%; padding:11px 12px; border:1px solid var(--line); border-radius:7px;
  outline:none; background:var(--field); color:var(--text); font:inherit; }}
input:focus {{ border-color:var(--accent); box-shadow:0 0 0 2px rgba(55,201,218,.18); }}
.toggle {{ display:flex; align-items:flex-start; gap:11px; margin:13px 0 0; font-weight:400; cursor:pointer; }}
.toggle input {{ width:18px; height:18px; margin:2px 0 0; flex:0 0 18px; accent-color:var(--accent); }}
.toggle-copy {{ display:block; }}
.toggle-title {{ display:block; font-weight:650; }}
.toggle-help {{ display:block; margin-top:3px; color:var(--muted); font-size:12px; font-weight:400; }}
.example {{ margin-top:7px; color:var(--muted); font-size:12px; }}
.actions {{ display:flex; align-items:center; justify-content:space-between; gap:10px; margin-top:22px; }}
.right {{ display:flex; gap:9px; }}
button {{ min-height:36px; padding:8px 14px; border:1px solid var(--line); border-radius:7px;
  cursor:pointer; background:transparent; color:var(--text); font:600 13px system-ui,sans-serif; }}
button:hover {{ background:rgba(255,255,255,.06); }}
.primary {{ border-color:var(--accent); background:var(--accent); color:#102326; }}
.primary:hover {{ background:var(--accent-hover); }}
</style></head><body>
<div class="header"><img class="logo" src="{PIPSPOOL_LOGO_DATA_URI}" alt="PipSpool logo"><div><h1>PipSpool settings</h1>
<p class="subtitle">Connect OrcaSlicer to your Spoolman server</p></div></div>
<div class="card"><p class="card-title">Spoolman connection</p>
<p class="help">Enter the address you normally use to open Spoolman.</p>
<label for="url">Server address</label>
<input id="url" type="url" spellcheck="false" autocomplete="off"
 value="{safe_current_url}" placeholder="{safe_default_url}">
<div class="example">Include http:// or https:// and the port, if one is used.</div></div>
<div class="card display-card"><p class="card-title">Profile naming</p>
<label for="profileNameTemplate">Name format</label>
<input id="profileNameTemplate" value="{safe_name_template}" maxlength="120" spellcheck="false">
<div class="example">Reorder {{spool_id}}, {{material}}, {{name}} and {{vendor}}. {{spool_id}} is required exactly once and includes (#42). The suffix “ - PipSpool” is always added.</div>
<div id="namePreview" class="example"></div>
<button type="button" id="resetNameTemplate">Reset to default</button>
<div class="example">Saving does not rename profiles. Synchronize to apply; restart OrcaSlicer after profiles are renamed. Full synchronization applies the format to all active spools.</div></div>
<div class="card display-card"><p class="card-title">Active spool G-code</p>
<label for="spoolIdCommand">Spool-ID command</label>
<input id="spoolIdCommand" value="{safe_spool_command}" maxlength="200" spellcheck="false">
<div class="example">Use {{spool_id}} exactly once. Default: SET_ACTIVE_SPOOL ID={{spool_id}}. Example alternative: M555 S={{spool_id}}.</div>
<div id="spoolCommandPreview" class="example"></div>
<details class="example" style="margin:12px 0"><summary style="cursor:pointer;font-weight:650">Printer / firmware command examples</summary>
<p>The command depends on the installed firmware and macros, rather than the printer brand alone.</p>
<dl style="margin:10px 0;line-height:1.65">
<dt style="font-weight:650">Klipper + Moonraker + Spoolman</dt>
<dd style="margin:2px 0 14px"><code>SET_ACTIVE_SPOOL ID={{spool_id}}</code><br>Default. Requires the SET_ACTIVE_SPOOL macro from Moonraker's Spoolman setup. Spool #42 produces <code>SET_ACTIVE_SPOOL ID=42</code>.</dd>
<dt style="font-weight:650">Anycubic GoKlipper with an M555 Spoolman bridge</dt>
<dd style="margin:2px 0 14px"><code>M555 S={{spool_id}}</code><br>Example reported for issue #16. Use only when your installed firmware or custom macro implements this command. Spool #42 produces <code>M555 S=42</code>; this is not a universal Anycubic command.</dd>
<dt style="font-weight:650">Klipper with a custom SET_SPOOL_ID macro</dt>
<dd style="margin:2px 0 14px"><code>SET_SPOOL_ID ID={{spool_id}}</code><br>Use only if you have defined this exact macro and its ID parameter. It is not Moonraker's documented default.</dd>
<dt style="font-weight:650">Happy Hare / MMU managing the active spool</dt>
<dd style="margin:2px 0 14px">Turn <b>Active spool G-code</b> off on the dashboard if your configured MMU integration already selects the correct active Spoolman spool on tool changes.</dd>
<dt style="font-weight:650">Printer without a compatible Spoolman command</dt>
<dd style="margin:2px 0 0">Turn <b>Active spool G-code</b> off. PipSpool still synchronizes profiles; use your printer's own filament-selection workflow.</dd>
</dl></details>
<button type="button" id="resetSpoolCommand">Reset command to default</button>
<div class="example">The dashboard Active spool G-code switch turns managed spool-ID output off entirely. Unrelated Start G-code stays intact. Per-spool Spoolman start_gcode overrides this command and also accepts {{spool_id}}. Synchronize after saving, then restart OrcaSlicer when prompted.</div></div>
<div class="card sync-card"><p class="card-title">Advanced setting scope</p>
<label for="settingScope">Apply selected advanced settings to</label>
<select id="settingScope" style="width:100%;padding:10px;border:1px solid var(--line);border-radius:6px;background:var(--field);color:var(--text)"><option value="shared" {"selected" if shared_mode else ""}>All spools sharing the same Filament (default)</option><option value="individual" {"" if shared_mode else "selected"}>Each spool independently</option></select>
<p class="help">Shared mode propagates advanced settings to sibling spool profiles. Individual mode stores them on each Spoolman spool; shared Filament fields stay untouched. First individual synchronization starts from your current Orca profiles. Returning to shared mode reports differing sibling values instead of choosing one. Saving this choice does not synchronize anything.</p>
</div><div class="card sync-card"><p class="card-title">Filament setting ownership</p>
<p class="help">Selected advanced fields synchronize in the scope chosen above.
Initial individual values come from your current Orca profiles. Later changes are reconciled against their last agreed values; conflicting saved edits are preserved and reported.</p>
<div class="example">Use “Reset Spoolman Filament Settings from Orca” only when you
want to replace selected PipSpool-managed values from Orca in the chosen scope.</div></div>
<div class="card sync-card"><p class="card-title">Network permissions</p>
<p class="help">OrcaSlicer manages approval for the configured Spoolman server.
After approving a request, repeat the action if Orca refused the current attempt.</p>
<div class="example">If approved prompts return after restarting OrcaSlicer, use
an Orca build containing permission fix #16658 (commit 6626377). The original
2.5.0 Alpha predates this fix. A different host may require its own approval.</div></div>
<div class="card sync-card"><p class="card-title">Orca change detection</p>
<p class="help">New Orca builds notify PipSpool when filament presets are saved.
Older Orca versions continue to use PipSpool's compatibility checks.</p>
<div id="lifecycleStatus" class="example">Checking Orca lifecycle support…</div></div>
<div class="card display-card"><p class="card-title">PipSpool page</p>
<p class="help">Choose whether PipSpool adds its dashboard to OrcaSlicer's top navigation.</p>
<label class="toggle" for="showPage"><input id="showPage" type="checkbox"{show_page_checked}>
<span class="toggle-copy"><span class="toggle-title">Show PipSpool page in OrcaSlicer</span>
<span class="toggle-help">Synchronization and plugin actions keep working when the page is hidden. Restart OrcaSlicer after changing this setting.</span></span></label></div>
<div class="card display-card"><p class="card-title">Low filament warning</p>
<p class="help">Highlight loaded gate/toolhead tiles when their remaining filament reaches this amount.</p>
<label for="lowStockThreshold">Warning threshold (grams)</label>
<input id="lowStockThreshold" type="number" min="0" step="1" value="{safe_low_stock_threshold}">
<div class="example">The default is 100 g. Set the threshold to 0 to disable low-stock warnings.</div></div>
<div class="actions"><button onclick="send('test')">Test connection</button>
<div class="right"><button onclick="send('cancel')">Cancel</button>
<button class="primary" onclick="send('save')">Save settings</button></div></div>
<script>
var spoolCommand = document.getElementById('spoolIdCommand');
function previewSpoolCommand() {{
  document.getElementById('spoolCommandPreview').textContent='Example for spool #42: '+spoolCommand.value.split('{{spool_id}}').join('42');
}}
spoolCommand.oninput=previewSpoolCommand;
document.getElementById('resetSpoolCommand').onclick=function(){{spoolCommand.value={json.dumps(DEFAULT_SPOOL_ID_COMMAND)};previewSpoolCommand();}};
previewSpoolCommand();
var nameTemplate = document.getElementById('profileNameTemplate');
function previewName() {{
  var values={{spool_id:'(#42)',material:'PETG',name:'Galaxy Black',vendor:'Prusament'}};
  var text=nameTemplate.value.replace(/\\{{([^{{}}]+)\\}}/g,function(all,key){{return Object.prototype.hasOwnProperty.call(values,key)?values[key]:all;}});
  document.getElementById('namePreview').textContent='Example: '+text.replace(/\\s+/g,' ').trim()+' - PipSpool';
}}
nameTemplate.oninput=previewName;
document.getElementById('resetNameTemplate').onclick=function(){{nameTemplate.value={json.dumps(DEFAULT_PROFILE_NAME_TEMPLATE)};previewName();}};
previewName();
var url = document.getElementById('url');
var settingScope = document.getElementById('settingScope');
var showPage = document.getElementById('showPage');
var lowStockThreshold = document.getElementById('lowStockThreshold');
var lifecycleStatus = document.getElementById('lifecycleStatus');
function settingsPayload(action) {{
  return {{action:action,shared_filament_settings:settingScope.value!=='individual',spool_id_command_template:spoolCommand.value,profile_name_template:nameTemplate.value,url:url.value,show_pipspool_page:showPage.checked,low_stock_threshold_grams:lowStockThreshold.value}};
}}
function send(action) {{
  if(window.orca&&typeof window.orca.postMessage==='function')window.orca.postMessage(settingsPayload(action));
  else lifecycleStatus.textContent='Settings bridge is not available in this Orca build.';
}}
function applySettingsState(data) {{
  if(!data||data.type!=='settings-state')return;
  spoolCommand.value=data.spool_id_command_template||{json.dumps(DEFAULT_SPOOL_ID_COMMAND)};previewSpoolCommand();
  nameTemplate.value=data.profile_name_template||{json.dumps(DEFAULT_PROFILE_NAME_TEMPLATE)};previewName();
  url.value=data.spoolman_url||{json.dumps(DEFAULT_SPOOLMAN_URL)};
  settingScope.value=data.shared_filament_settings===false?'individual':'shared';
  showPage.checked=data.show_pipspool_page!==false;
  lowStockThreshold.value=data.low_stock_threshold_grams==null?{DEFAULT_LOW_STOCK_THRESHOLD_GRAMS}:data.low_stock_threshold_grams;
  lifecycleStatus.textContent=data.lifecycle_supported===true
    ?'Lifecycle events enabled — saved Orca filament presets trigger a debounced status check.'
    :'Compatibility mode — use Refresh after changing Orca or Spoolman.';
}}
function startSettingsBridge(attempt) {{
  attempt=attempt||0;
  if(window.orca&&typeof window.orca.postMessage==='function'&&typeof window.orca.onMessage==='function'){{
    window.orca.onMessage(applySettingsState);
    window.orca.postMessage({{action:'load-settings'}});
    return;
  }}
  if(attempt<100)window.setTimeout(function(){{startSettingsBridge(attempt+1);}},100);
  else lifecycleStatus.textContent='Settings bridge is not available in this Orca build.';
}}
url.addEventListener('keydown', function(event) {{ if (event.key === 'Enter') send('save'); }});
document.addEventListener('DOMContentLoaded', function() {{ startSettingsBridge(0); }});
</script>
</body></html>"""

        def on_message(data):
            if not isinstance(data, dict):
                return
            action = data.get("action")
            if action == "load-settings":
                post = getattr(window, "post", None)
                if callable(post):
                    post(settings_window_state())
                return
            if action == "cancel":
                window.close()
                return
            if action == "test":
                try:
                    test_url = normalize_url(data.get("url", ""))
                except Exception as exc:
                    show_message(str(exc), title="Connection test", icon="error")
                    return

                def test_connection():
                    try:
                        spools = SpoolmanClient(test_url).active_spools()
                        show_message(
                            f"Connection successful.\n\nSpoolman returned {len(spools)} active spool(s).",
                            title="Connection test",
                        )
                    except Exception as exc:
                        log(f"[CONNECTION TEST ERROR] {exc}")
                        show_message(
                            f"Could not connect to Spoolman.\n\n{exc}",
                            title="Connection test",
                            icon="error",
                        )

                if not start_background_thread(
                    threading.Thread(target=test_connection, daemon=True),
                    "Spoolman connection test",
                ):
                    show_message(
                        THREAD_PERMISSION_RETRY_MESSAGE,
                        title="Connection test",
                        icon="error",
                    )
                return
            if action == "save":
                try:
                    updated_shared = data.get("shared_filament_settings", True)
                    if not isinstance(updated_shared, bool):
                        raise ValueError("Invalid advanced setting scope")
                    updated_show_page = bool(data.get("show_pipspool_page", True))
                    saved_show_page = (
                        load_settings().get("show_pipspool_page", True) is not False
                    )
                    visibility_changed = saved_show_page != updated_show_page
                    updated_low_stock_threshold = numeric(
                        data.get("low_stock_threshold_grams")
                    )
                    if updated_low_stock_threshold is None or updated_low_stock_threshold < 0:
                        raise ValueError("Low-stock warning threshold must be 0 grams or more")
                    updated_name_template = validate_profile_name_template(data.get("profile_name_template", profile_name_template()))
                    naming_changed = updated_name_template != profile_name_template()
                    updated_spool_command = validate_spool_id_command_template(data.get("spool_id_command_template", spool_id_command_template()))
                    spool_command_changed = updated_spool_command != spool_id_command_template()
                    settings_update = {
                        "shared_filament_settings": updated_shared,
                        "spool_id_command_template": updated_spool_command,
                        "profile_name_template": updated_name_template,
                        "spoolman_url": normalize_url(data.get("url", "")),
                        "show_pipspool_page": updated_show_page,
                        "low_stock_threshold_grams": round(updated_low_stock_threshold, 1),
                    }
                    host_saved = self._save_host_settings(settings_update)
                    file_saved = False
                    try:
                        save_settings(settings_update)
                        file_saved = True
                    except OSError as exc:
                        log(f"[SETTINGS FILE SAVE] {exc}")
                    if not host_saved and not file_saved:
                        raise RuntimeError("OrcaSlicer could not save PipSpool settings")
                    window.close()
                    message = "PipSpool settings saved."
                    if spool_command_changed:
                        message += "\n\nSynchronize to apply the spool-ID command. Restart OrcaSlicer after profiles change."
                    if naming_changed:
                        message += "\n\nSynchronize to apply profile naming. Restart OrcaSlicer after profiles are renamed."
                    if visibility_changed:
                        message += "\n\nRestart OrcaSlicer to apply the page visibility change."
                    show_message(message)
                except Exception as exc:
                    show_message(str(exc), icon="error")

        window = orca.host.ui.create_window(
            html=html,
            title="PipSpool Settings",
            on_message=on_message,
        )


def request_startup_permissions() -> None:
    """Declare only the visibility read; defer thread consent until first use."""
    if PAGES_BASE is not None:
        orca.request_permissions(fs_read=[str(SETTINGS_PATH)])


@orca.plugin
class PipSpoolPlugin(orca.base):
    def register_capabilities(self):
        # Approval occurs after this method returns. This declaration documents
        # only the saved visibility read; no startup thread declaration.
        # Migration stays in Settings.on_load; thread grants do not bypass
        # any filesystem/network permission or start work during registration.
        request_startup_permissions()
        if PAGES_BASE is not None and pipspool_page_enabled():
            orca.register_capability(PipSpoolPageCapability)
        orca.register_capability(SyncCapability)
        orca.register_capability(ResetFilamentSettingsCapability)
        orca.register_capability(LegacyCleanupCapability)
        orca.register_capability(SettingsCapability)
