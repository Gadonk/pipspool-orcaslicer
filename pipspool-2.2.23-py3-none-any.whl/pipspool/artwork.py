"""Read bundled artwork without network access or writable caches."""
import base64
from importlib.resources import files

def data_uri(name):
    if len(name) != 69 or not name.endswith(".webp") or any(
        c not in "0123456789abcdef" for c in name[:-5]
    ):
        raise ValueError("Invalid bundled artwork name")
    payload = files(__package__).joinpath("assets", name).read_bytes()
    return "data:image/webp;base64," + base64.b64encode(payload).decode("ascii")
